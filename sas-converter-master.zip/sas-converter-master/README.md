![structure](docs/structure.png)
![overview](docs/overview.png)

DATA steps statements and [Dataset options](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=ledsoptsref&docsetTarget=n03k13diwk36x1n1az3mpixdfbfp.htm&locale=en):
* [SET](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=lestmtsref&docsetTarget=p00hxg3x8lwivcn1f0e9axziw57y.htm&locale=en)
* [MERGE](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=lestmtsref&docsetTarget=n1i8w2bwu1fn5kn1gpxj18xttbb0.htm&locale=en)
* [FORMAT](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=lestmtsref&docsetTarget=n0d5oq7e0oia0wn13nsins0x8nmh.htm&locale=en) - basic
* [KEEP](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=ledsoptsref&docsetTarget=p0vw9lyyxk1cxkn0zzfemrsr3t9a.htm&locale=en) - basic
* [ATTRIB](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=lestmtsref&docsetTarget=n1wxb7p9jkxycin16lz2db7idbnt.htm&locale=en) 

[PROC](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=titlepage.htm&locale=en) steps basic support
* [EXPORT](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n045uxf7ll2p5on1ly4at3vpd47e.htm&locale=en)
* [FORMAT](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=p06ciqes4eaqo6n0zyqtz9p21nfb.htm&locale=en)  
* [IMPORT](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n1qn5sclnu2l9dn1w61ifw8wqhts.htm&locale=en)
* [RANK](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=p0le3p5ngj1zlbn1mh3tistq9t76.htm&locale=en)
* [S3](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n1h9c1jnr8v8nwn1l6g83kyne5ds.htm&locale=en)
* [SORT](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=p1nd17xr6wof4sn19zkmid81p926.htm&locale=en)
* [SQL](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=sqlproc&docsetTarget=n0w2pkrm208upln11i9r4ogwyvow.htm&locale=en) basic support
* [SUMMARY](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=p0aq3hsvflztfzn1xa2wt6s35oy6.htm&locale=en), which is an alias for [MEANS](https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n1qnc9bddfvhzqn105kqitnf29cp.htm&locale=en)




# Macro language

| Feature | Support |
| --- | --- |
| `%LET` | 100% |
| `%MACRO` | 90% |
| `%DO` Iterative | 90% |
| `%LOCAL` | 90% |
| `%GLOBAL` | 50% |
| `%GOTO` | 10% |
| `%IF` | 50% |
| `%DO %WHILE` | 50% |
| `%DO %UNTIL` | 50% |
| `%IF .. %THEN .. %ELSE` | 50% |
| `%GOTO` | none |
| `%label ..` | none |
| `%RETURN` | none |

The following table is used to track completeness of function support:

| Macro function | Support |
| --- | --- |
| `%BQUOTE`, `%NRBQUOTE` | 40% |
| `%EVAL` | no |
| `%INDEX` | no |
| `%LENGTH` | 100% |
| `%QUOTE`, `%NRQUOTE` | no |
| `%SCAN`, `%QSCAN` | no |
| `%STR`, `%NRSTR` | no |
| `%SUBSTR`, `%QSUBSTR` | no |
| `%SUPERQ` | no |
| `%SYMEXIST` | no |
| `%SYMGLOBL` | no |
| `%SYMLOCAL` | no |
| `%SYSEVALF` | no |
| `%SYSFUNC`, `%QSYSFUNC` | 50% |
| `%SYSGET` | no |
| `%SYSMACEXEC` | no |
| `%SYSMACEXIST` | no |
| `%SYSMEXECDEPTH` | no |
| `%SYSMEXECNAME` | no |
| `%SYSPROD` | no |
| `%UNQUOTE` | no |
| `%LOWCASE`, `%QLOWCASE` | 90% |
| `%UPCASE`, `%QUPCASE` | 90% |
