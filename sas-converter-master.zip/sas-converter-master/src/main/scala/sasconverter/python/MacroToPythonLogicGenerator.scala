package sasconverter.python

import fastparse.{Parsed, parse}
import sasconverter.{Code, Context}
import sasconverter.syntax.{Macro, Operators, Syntax}
import sasconverter.syntax.Macro._
import sasconverter.syntax.Syntax.Expr

object MacroToPythonLogicGenerator {
  def translate(macroCode: String, context: Context): String = {
    val code = Code(context)
    parse(macroCode, Macro.main(_), verboseFailures = true) match {
      case Parsed.Success(value, _) => value match {
        case Block(statements) =>
          val notebookWithoutInit = statements.map(statement(_, code)).mkString("\n")
          context.init + notebookWithoutInit
        }
      case f: Parsed.Failure =>
        throw new Exception(f.trace(true).longAggregateMsg)
    }
  }

  def statement(st: Macro.Statement, code: Code): String = st match {
    case Macro.Block(statements) =>
      code.stringChildren(statements.map(statement(_, code)))
    case Macro.Do(Block(statements)) =>
      code.stringChildren(statements.map(statement(_, code)))
    case Macro.Code(text) =>
      // hm... this can be improved, i think
      text //we might call step parser
    case Macro.Let(variable, value) =>
      s"$variable = ${expr(value, code)}"
//    case resolvable: Macro.Resolvable =>
    case Macro.Definition(name, params, Block(statements)) =>
      val args = params.map {
        case Macro.Parameter(name, default: Option[Expr]) =>
          default match {
            case Some(value) => s"$name = ${expr(value, code)}"
            case None => name
          }
      }.mkString(", ")
      s"def $name($args):\n" + code.indented({
        statements.map(statement(_, code))
      })
    case Macro.Local(Syntax.VariableList(vars)) =>
      code.stringChildren(vars.map(v => s"${v.name} = None"))
    case Macro.Global(Syntax.VariableList(vars)) =>
      s"global ${vars.map(_.name).mkString(", ")}"
    case Macro.Variable(name) =>
      // todo: what if interpolated?...
      name
    case Macro.TwoLevelVariable(Variable(v1), Variable(v2)) => s"${v1}.${v2}"
    case Macro.OneLevelVariableInterpolated(Variable(v1),name) => s"${v1}.${name}"
    case Macro.OneLevelVariableSuffix(Variable(v),name) => s"${v}${name}"
    case Macro.Goto(name) =>
      s"return # goto $name"
    case Macro.If(cond, then_, else_) =>
      val clause = s"if ${expr(cond, code)}:\n" +
        code.indented({
          Seq(statement(then_, code))
        })
      else_ match {
        case Some(value) =>
          clause + "\n" +
            code.start +
            "else:\n" +
            code.indented {
              Seq(statement(value, code))
            }
        case None =>
          clause
      }
    case Macro.Comment(text) =>
      s"# $text"
    case value: Macro.Resolvable =>
      resolvable(value, code)
    case unknown: Macro.Statement =>
      throw new MacroException(s"Unknown statement: $unknown", 0)
  }

  def resolvable(value: Macro.Resolvable, code: Code): String = value match {
    case Macro.SysFunc(name, func, args, format) =>
      val res = translateToPython(func, args, code)
      // todo: QFUNC vs FUNC behavior
      res
    case Macro.Bquote(value) =>
      code.context.init += "\ndef sas_bquote(s): return s\n"
      s"sas_bquote(${expr(value, code)})"
    case Macro.Reference(name, args) =>
      reference(name, args, code)
    case Macro.Eval(ev) =>
      expr(ev, code)
    case Macro.StrMacro(str) =>
      s"'$str'"
    case Macro.Put(text) =>
      // todo: import logger
      s"logger.info('$text')"
    case unknown: Macro.Resolvable =>
      throw new MacroException(s"Unknown resolvable: $unknown", 0)
  }

  def translateToPython(name: String, args: Seq[Macro.Argument], code: Code): String = {
    val argString = args.map(_.value).map(expr(_, code)).mkString(", ")
    name.toLowerCase match {
      case "compress" =>
        code.context.init += "\ndef sas_compress(s, replace=' '): return s.replace(replace, '')\n"
        s"sas_compress($argString)"
      case "datetime" =>
        code.context.init += "\ndef sas_datetime(): import time; return time.time()\n"
        s"sas_datetime()"
      case "putn" =>
        code.context.init += "\ndef sas_putn(value, fmt): return str(value) # TODO implement me\n"
        s"sas_putn($argString)"
      case "date" =>
        code.context.init += "\ndef sas_date(): from datetime import date; return date.today()\n"
        s"sas_date()"
      case "exist" =>
        code.context.init += "\ndef sas_exist(t): \n  if (spark._jsparkSession.catalog().tableExists(f'{t}')):\n    " +
          "return 1\n  else:\n    " +
          "return 0\n"
        s"sas_exist($argString)"
      case "notdigit" =>
        code.context.init += "\nimport re\ndef notdigit(t):\n  res = None\n  temp = re.search(r'[a-z]', t, re.I)\n  if temp is not None:\n    res = temp.start()\n  return res \n"
        s"notdigit($argString)"
      case "fileexist" =>
        code.context.init += "\nimport os.path\nfrom os import path\ndef sas_fileexist(p):\n return path.exists(p) \n"
        s"sas_fileexist($argString)"
      case "filename" =>
        code.context.init += "def sas_filename(p):\n return # TODO implement me \n"
        s"sas_filename($argString)"
      case "fdelete" =>
        code.context.init += "def sas_fdelete(p):\n return # TODO implement me \n"
        s"sas_fdelete($argString)"
      case "open" =>
        code.context.init += "def sas_open(p):\n return # TODO implement me \n"
        s"sas_open($argString)"
      case "close" =>
        code.context.init += "def sas_close(p):\n return # TODO implement me \n"
        s"sas_close($argString)"
      case "attrn" =>
        code.context.init += "def sas_attrn(p):\n return # TODO implement me \n"
        s"sas_attrn($argString)"
      case "substr" =>
        code.context.init += "def sas_substr(p,s,u):\n return p[s:u] \n"
        s"sas_substr($argString)"
      case "today" =>
        code.context.init += "def sas_today():\n from datetime import date; return date.today()\n"
        s"sas_today()"
      case "intnx" =>
        code.context.init += "def sas_intnx(interval,start,increment,align=None):\n return # TODO implement me\n"
        s"sas_intnx($argString)"
      case "fexist" =>
        code.context.init += "def sas_fexist(a):\n return # TODO implement me\n"
        s"sas_fexist($argString)"
      case unknown: String =>
        throw new MacroException(s"Unknown sysfunc: $unknown", 0)
    }

  }
  def arg(argument: Macro.Argument, code: Code): String = argument.key match {
    case Some(value) => s"$value = ${expr(argument.value, code)}"
    case None => expr(argument.value, code)
  }

  def expr(value: Expr, code: Code): String = value match {
    case Syntax.Binary(left, symbol, right) =>
      binary(left, symbol, right, code)
    case Syntax.Unary(symbol, right) => symbol match {
      case Operators.UnaryNot =>
        s"not ${expr(right, code)}"
      case Operators.UnaryMinus =>
        s"- ${expr(right, code)}"
      case Operators.UnaryPlus =>
        s"+ ${expr(right, code)}"
      case s: Operators.OperatorSymbol =>
        throw new MacroException(s"Unknown symbol $s", 0)
    }
    case Syntax.Identifier(name) =>
      name
    case const: Syntax.Constant =>
      constant(const, code)
    case value: Macro.Resolvable =>
      resolvable(value, code)
    case Macro.Variable(name) =>
      // TODO: treat differently, when embedded in a string
      name match {
        case "sysjobid" =>
          code.context.init += "\nimport os\n"
          "os.getpid()"
        case _ => name
      }
    case Macro.TwoLevelVariable(Variable(v1), Variable(v2)) => s"${v1}.${v2}"
    case Macro.OneLevelVariableInterpolated(Variable(v),name) => s"${v}.${name}"
    case Macro.OneLevelVariableSuffix(Variable(v),name) => s"${v}${name}"
    case e: Expr =>
      throw new MacroException(s"Unknown expr $e", 0)
  }

  private def reference(name: String, args: Seq[Macro.Argument], code: Code) = {
    s"$name(${args.map(arg(_, code)).mkString(", ")})"
  }

  def constant(const: Syntax.Constant, code: Code): String = const match {
    case numeric: Syntax.SasNumeric => numeric match {
      case Syntax.Integer(v) =>
        v.toString
      case Syntax.Fractional(sign, i, f, exponent) =>
        // todo: exponent handling
        s"$sign$i$f"
    }
    case Syntax.Char(s) =>
      s"'$s'"
    case Syntax.Date(year, month, day) =>
      code.context.importDatetime()
      s"datetime.date($year, $month, $day)"
    case Syntax.Null() =>
      "None"
    case Syntax.ConstantList(cl) =>
      s"(${cl.map(expr(_, code)).mkString(", ")})"
  }

  def binary(left: Expr, symbol: Operators.OperatorSymbol, right: Expr, code: Code): String = symbol match {
    case Operators.Or =>
      s"${expr(left, code)} or ${expr(right, code)}"
    case Operators.And =>
      s"${expr(left, code)} and ${expr(right, code)}"
    case Operators.LessThan =>
      s"${expr(left, code)} < ${expr(right, code)}"
    case Operators.LessEquals =>
      s"${expr(left, code)} <= ${expr(right, code)}"
    case Operators.GreaterThan =>
      s"${expr(left, code)} > ${expr(right, code)}"
    case Operators.GreaterEquals =>
      s"${expr(left, code)} >= ${expr(right, code)}"
    case Operators.Equals =>
      s"${expr(left, code)} == ${expr(right, code)}"
    case Operators.NotEquals =>
      s"${expr(left, code)} != ${expr(right, code)}"
    case Operators.InList =>
      s"${expr(left, code)} in ${expr(right, code)}"
    case Operators.NotIn =>
      s"${expr(left, code)} not in ${expr(right, code)}"
    case Operators.Add =>
      s"${expr(left, code)} + ${expr(right, code)}"
    case Operators.Subtract =>
      s"${expr(left, code)} - ${expr(right, code)}"
    case Operators.Multiply =>
      s"${expr(left, code)} * ${expr(right, code)}"
    case Operators.Divide =>
      s"${expr(left, code)} / ${expr(right, code)}"
    case Operators.Power =>
      s"${expr(left, code)} ** ${expr(right, code)}"
    case Operators.StripAndConcatenate =>
      s"(${expr(left, code)}).trim() + (${expr(right, code)}).trim()"
    case Operators.Concatenate =>
      s"(${expr(left, code)}) + (${expr(right, code)})"
    case Operators.MinOfTwo =>
      s"min(${expr(left, code)}, ${expr(right, code)})"
    case Operators.MaxOfTwo =>
      s"max(${expr(left, code)}, ${expr(right, code)})"
    case s: Operators.OperatorSymbol =>
      throw new MacroException(s"Unknown symbol $s", 0)
  }
}
