package sasconverter

object Main extends App {
  print(Compiler.consumeFile(args(0)))
}
