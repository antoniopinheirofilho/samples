package sasconverter.syntax

import fastparse._
import fastparse.internal.{Logger, Util}
import org.apache.logging.log4j.scala.Logging
import sasconverter.syntax.Macro.logger

import scala.annotation.{switch, tailrec}

object Implicits extends Logging {
  val parseDebug = true

  implicit val parseDebugLogger = Logger(line => if (parseDebug) {
//    println(line)
//    logger.debug(line)
  })

  implicit val whitespace = {implicit ctx: ParsingRun[_] =>
    val input = ctx.input
    val startIndex = ctx.index

    /* TODO: rewrite for proper SAS comment standards...
    Syntax A:
    * Check the variables in the most recently used dataset using the CONTENTS procedure;
    PROC CONTENTS;
    RUN;

    Syntax B:
    /* Print the contents of the most recently used dataset using the PRINT procedure.*/
    PROC PRINT;
    RUN;
     */

    @tailrec def rec(current: Int, state: Int): ParsingRun[Unit] = {
      if (!input.isReachable(current)) {
        if (state == 0 || state == 1) ctx.freshSuccessUnit(current)
        else if(state == 2)  ctx.freshSuccessUnit(current - 1)
        else {
          ctx.cut = true
          val res = ctx.freshFailure(current)
          if (ctx.verboseFailures) ctx.setMsg(startIndex, () => Util.literalize("*/"))
          res
        }
      } else {
        val currentChar = input(current)
        (state: @switch) match{
          case 0 =>
            (currentChar: @switch) match{
              case ' ' | '\t' | '\n' | '\r' => {
                rec(current + 1, state)
              }
              case '/' => {
                rec(current + 1, state = 2)
              }
              case _ => ctx.freshSuccessUnit(current)
            }
          case 1 => rec(current + 1, state = if (currentChar == '\n') 0 else state)
          case 2 => // java comment
            (currentChar: @switch) match{
              case '/' => {
                rec(current + 1, state = 1)
              }
              case '*' => {
                rec(current + 1, state = 3)
              }
              case _ => ctx.freshSuccessUnit(current - 1)
            }
          case 3 => {
            rec(current + 1, state = if (currentChar == '*') 4 else state)
          }
          case 4 =>
            (currentChar: @switch) match{
              case '/' => {
                rec(current + 1, state = 0)
              }
              case '*' => {
                rec(current + 1, state = 4)
              }
              case _ => {
                rec(current + 1, state = 3)
              }
            }
          //            rec(current + 1, state = if (currentChar == '/') 0 else 3)
        }
      }
    }
    if (ctx.misc.contains("repSpace")) {
      ctx.freshSuccessUnit()
    } else {
      rec(current = ctx.index, state = 0)
    }
  }

  implicit class SpaceRep[+T](p0: => P[T]) {
    def repSpace[R](min: Int = 1)(implicit ev: fastparse.Implicits.Repeater[T, R], ctx: P[_]): P[R] = {
      ctx.misc.put("repSpace", true)
      val res = p0.rep[R](min=min, sep=" ".rep, max=Integer.MAX_VALUE, exactly = -1)
      ctx.misc.remove("repSpace")
      res
    }

    def repComma[R](min: Int = 1)(implicit ev: fastparse.Implicits.Repeater[T, R], ctx: P[_]): P[R] = {
      // TODO: sep should include all of whitespace chars - something like CharsWhile(_.isWhitespace)
      p0.rep[R](min=min, sep="," ~ " ".rep, max=Integer.MAX_VALUE, exactly = -1)
    }
  }
}

