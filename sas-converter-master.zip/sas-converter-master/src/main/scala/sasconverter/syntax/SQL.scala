package sasconverter.syntax

import java.text.ParseException

import fastparse._
import sasconverter.Context
import sasconverter.steps.DataStepParser.{compress, drop, rename}
import sasconverter.steps.{Passthrough, Option => Opt}

object SQL {
  import Implicits._
  import Syntax._

  sealed trait SqlExpr extends Expr {
    override def sql(context: Context): String = ???
  }
  case class Assign(column: Column, expr: Expr) extends SqlExpr
  sealed trait Clause extends SqlExpr
  case class Query(clauses: Seq[Clause]) extends SqlExpr with Table
  case class QueryUnion(left: Table, how: SetOperator, right: Table) extends Table
  case class Select(items: Seq[Expr]) extends Clause
  case class SelectDistinct(items: Seq[Expr]) extends Clause
  case class From(tables: Seq[Table]) extends Clause
  case class Where(expr: Expr) extends Clause
  case class GroupBy(exprs: Seq[Expr]) extends Clause
  case class Having(expr: Expr) extends Clause
  case class OrderBy(items: Seq[Ordering]) extends Clause
  case class Join(how: Set[HowToJoin], right: Table, expr: Option[Expr]) extends Clause
  case class SetClause(items: Seq[Assign]) extends Clause
  sealed trait Col extends SqlExpr
  case class Asterisk(table: String = null) extends Col
  case class Column(n: String) extends Col
  case class Alias(expr: Expr, alias: String) extends Col
  case class TableColumn(table: String, n: String) extends Col
  case class AliasModifiers(alias: Alias, m: Seq[Modifier]) extends Col
  case class ExprModifiers(alias: Expr, m: Seq[Modifier]) extends Col
  sealed trait Modifier extends Passthrough
  case class InformatModifier(inf: Informat) extends Modifier with Passthrough
  case class FormatModifier(inf: Informat) extends Modifier with Passthrough
  case class Label(v: String) extends Modifier with Passthrough
  case class Length(v: Int) extends Modifier with Passthrough
  case class Transcode(yes: Boolean) extends Modifier with Passthrough
  case class When(when: Expr, _then: Expr)
  case class Case(operand: Option[Expr], when: Seq[When], _else: Option[Expr]) extends Col
  case class Into(seq: Seq[IntoVar]) extends Clause
  case class SeparatedBy(by: String, notrim: Boolean = false) extends Modifier
  case class Trimmed() extends Modifier
  case class Notrim() extends Modifier
  case class IntoVar(value: String, modifier: Option[Modifier] = None)
  sealed trait Table extends SqlExpr
  case class TableRef(n: Table, opts:Seq[Opt] ) extends Table
  case class Pathname(path: String) extends Table
  case class SimpleName(name: String, opts: Seq[Opt]) extends Table
  case class TwolevelName(libref: String, name: String,opts: Seq[Opt]) extends Table
  case class AliasedTable(table: Table, alias: String) extends Table
  case class TableVariable(value: Variable,opts: Seq[Opt]) extends Table
  case class TableInterpolatedVariable(value: Variable, rest: String,opts: Seq[Opt]) extends Table
  case class TwoLevelTableInterpolatedVariable(value: Variable, rest: Variable,opts: Seq[Opt]) extends Table
  /*case class TwoLevelTableInterpolatedVariableSuffix(value: Variable, rest: VariableSuffix) extends Table*/
  case class Natural() extends Modifier
  case class Ordering(column: Expr, direction: String)

  sealed trait HowToJoin
  case object Cross extends HowToJoin
  case object Natural extends HowToJoin
  case object Union extends HowToJoin
  case object Inner extends HowToJoin
  case object Outer extends HowToJoin
  case object Left extends HowToJoin
  case object Right extends HowToJoin
  case object Full extends HowToJoin
  case class SetOperator(operator: String, corr: Boolean, all: Boolean)

  // SELECT <DISTINCT> object-item-1 <, object-item-2, ...>
  def select[_: P]: P[Clause] = (W("select") ~ (W("distinct")|W("unique")).!.? ~ objectItem.repComma()) map {
    case (Some(_), cols) => SelectDistinct(cols)
    case (None, cols) => Select(cols)
  }
  private def informatm[_: P] = (W("informat") ~ "=" ~ informat).map(InformatModifier)
  private def formatm[_: P] = (W("format") ~ "=" ~ informat).map(FormatModifier)
  private def labelSingleQuote[_: P] = (W("label") ~ "=" ~ char).map(c => Label(c.s))
  // TODO: this ignores any escaping rules, add those in later.
  private def labelDoubleQuote[_: P] = (W("label") ~ "=" ~ "\"" ~~ CharsWhile(!"\"".contains(_)).! ~~ "\"").map(Label)
  private def doubleQuoteAsLabel[_: P] = doubleQuoted.map(Label)
  private def labelm[_: P] = labelSingleQuote | labelDoubleQuote | doubleQuoteAsLabel
  private def lengthm[_: P] = (W("length") ~ "=" ~ digit.repX.!.map(_.toInt)).map(Length)
  private def transcodem[_: P] = (W("transcode") ~ "=" ~ (W("yes")|W("no")).!.map(_.equals("yes"))).map(Transcode)
  def modifier[_: P] = (informatm | formatm | labelm | lengthm | transcodem )
  def modifiers[_: P]: P[Seq[Modifier]] = (informatm | formatm | labelm | lengthm | transcodem ).rep(1)
  def objectItem[_: P] = (exprm | asterisk | alias | sqlExpr).log
  // TODO: alias modifiers somehow don't want to work yet
  def aliasm[_: P] = (alias ~ modifiers).log.map(AliasModifiers.tupled)
  def exprm[_: P] = (sqlExpr ~ modifiers).log map(ExprModifiers.tupled)
  def asterisk[_: P] = ((identifier ~ ".").? ~ "*").log map(i => Asterisk(i.map(_.name).orNull))
  def alias[_: P] = (sqlExpr ~ W("as") ~ possibleColumn).log map(Alias.tupled)
  def call[_: P] = (token ~~ "(" ~~ (asterisk | sqlExpr).repComma(0) ~~ ")").map(Call.tupled)
  def argu[_: P] = (_case | call | column | constant).log
  def parens[_: P] = ("(" ~ sqlExpr ~ ")").log
  def primary[_: P] = (unaryOf(sqlExpr) | parens | argu).log
  def sqlExpr[_: P]: P[Expr] = binaryOf(primary, Operators.ALL).log
  def columnName[_: P] = name.map(Column).log
  def charn[_:P] = (char ~~ W("n").?).map(_.s)
  def possibleColumn[_:P] = name | charn
  def tableColumn[_: P] = (name ~~ "." ~~ possibleColumn).map(TableColumn.tupled).log
  def column[_: P]: P[Col] = (tableColumn | columnName).log
  def _case[_: P] = (W("case") ~ sqlExpr.? ~ when.rep ~ (W("else") ~ sqlExpr).? ~ W("end")).log.map(Case.tupled)
  def when[_: P] = (W("when") ~ sqlExpr ~ W("then") ~ sqlExpr).map(When.tupled)
  def F[T, _:P](s: String, cc: Unit => T): P[T] = W(s).map(cc)
  def separatedBy[_: P] = W("separated") ~ W("by") ~ char ~ B("notrim") map(x => SeparatedBy(x._1.s, x._2))
  def trimmed[_: P] = F("trimmed", _ => Trimmed())
  def notrim[_: P] = F("notrim", _ => Notrim())
  def macrovsm[_: P]: P[Modifier] = separatedBy | trimmed | notrim
  def macroVarSpec[_: P] = ":" ~~ name ~ macrovsm.? map(IntoVar.tupled)

  // INTO macro-variable-specification-1 <, macro-variable-specification-2, ...>
  def into[_: P] = W("into") ~ macroVarSpec.repComma(1) map Into

  // FROM from-list

  def tableModifier[_:P] = ("(" ~ (modifier | drop | rename | compress).repSpace() ~ ")").?
  def onelevel[_: P] = (name ~ tableModifier).map{case (n, opts) => SimpleName(n, opts.getOrElse(Seq()))}
  def twolevel[_: P] = (name ~~ "." ~~ name ~ tableModifier).map{case (n,m, opts) => TwolevelName(n,m, opts.getOrElse(Seq()))}
  def pathname[_: P] = doubleQuoted map(Pathname)
  def dql[_:P]: P[Table] = queryUnions | normalQuery
  def queryExpression[_: P] = "(" ~ dql ~ ")"
  def tableVariable[_:P] = (variable ~ tableModifier).map{case (n, opts) => TableVariable(n, opts.getOrElse(Seq()))}
  def tableVariableInterpolated[_:P] = (variableInterpolated ~~ CharsWhile(!" ".contains(_)).! ~ tableModifier).map{case (n,m, opts) => TableInterpolatedVariable(n, m.toLowerCase(), opts.getOrElse(Seq()))}
  def twoLevelTableVariableInterpolated[_:P] = (variableInterpolated ~ "." ~ variableInterpolated ~ tableModifier).map{case (n,m, opts) => TwoLevelTableInterpolatedVariable(n, m, opts.getOrElse(Seq()))}
  //def twoLevelTableVariableInterpolatedSuffix[_:P] = (variableInterpolated ~ "." ~ variableInterpolatedSuffix).map(TwoLevelTableInterpolatedVariableSuffix tupled)

  def tableRef[_:P]: P[Table] = ((twoLevelTableVariableInterpolated|tableVariableInterpolated|tableVariable|twolevel|onelevel)).map(x => x)
  def directTable[_: P]: P[Table] = tableRef|pathname|queryExpression
  def aliasedTable[_: P]: P[Table] = (directTable ~ W("as").? ~ name) map(AliasedTable.tupled)
  def table[_: P] = aliasedTable | directTable
  def join[_: P]: P[Join] = {
    def jt(x: String, y: HowToJoin): P[Set[HowToJoin]] = F(x, _ => Set(y))
    def union(pair: Tuple2[Set[HowToJoin], Option[Set[HowToJoin]]]): Set[HowToJoin] = {
      val left = pair._1
      val right = pair._2.getOrElse(Set())
      val result = left.union(right)
      result
    }
    def cnu: P[Set[HowToJoin]] = (jt("cross", Cross) | jt("natural", Natural) | jt("union", Union)).?.map(_.getOrElse(Set()))
    def outerJoinType: P[Set[HowToJoin]] = jt("left", Left) | jt("right", Right) | jt("full", Full)
    def outerJoinSet: P[Set[HowToJoin]] = (outerJoinType ~ jt("outer", Outer).?).map(union)
    def innerOuter: P[Set[HowToJoin]] = jt("inner", Inner) | outerJoinSet
    def joinModifiers: P[Set[HowToJoin]] = (cnu ~ innerOuter.?).map(union)
    joinModifiers ~ W("join") ~ table ~ (W("on") ~ sqlExpr).? map(Join.tupled)
  }

  def assign[_: P] = P(columnName ~ "=" ~ (variable|sqlExpr)).map(Assign.tupled)
  def setClause[_: P] = W("set") ~ assign.rep(sep=",").map(SetClause)
  def from[_: P] = W("from") ~ table.repComma() map From
  def where[_: P] = (W("where") ~ sqlExpr).map(Where)
  def groupBy[_: P] = (W("group") ~ W("by") ~ (integer | sqlExpr).rep(sep=",")).map(GroupBy)
  def having[_: P] = (W("having") ~ sqlExpr).map(Having)
  def ordering[_: P]: P[Ordering] = ((integer | sqlExpr) ~ (W("asc") | W("desc")).!.?.map(_.map(_.toLowerCase).getOrElse("asc"))).map(Ordering.tupled)
  def orderBy[_: P] = (W("order") ~ W("by") ~ ordering.rep(sep=",")).map(OrderBy)
  def normalQuery[_: P] = (select | into | from | join | where | groupBy | having | orderBy).rep(1) map Query
  def querySetOperator[_: P] = {
    def name: P[String] = (W("union") | W("outer") ~ W("union") | W("except") | W("intersect")).!.map(_.toLowerCase)
    def corr = (W("corresponding") | W("corr")).!.?.map(_.isDefined)
    def all = W("all").!.?.map(_.isDefined)
    (name ~ corr ~ all).map(SetOperator.tupled)
  }
  def queryUnions[_: P] = (normalQuery ~ (querySetOperator ~ normalQuery).rep).map {
    case (query, tuples) => climbQueries(query, tuples)
  }
  private def climbQueries(left: Table, rights: Seq[(SetOperator,Table)]): Table =
    rights.headOption match {
      case None => left
      case Some((how, next)) => QueryUnion(left, how, climbQueries(next, rights.tail))
    }

  case class CreateTableAs(name: Table, expr: Table) extends SqlExpr
  def createTable[_: P]: P[CreateTableAs] =
    (W("create") ~ (W("table") | W("view")) ~
      tableRef ~ W("as") ~
      dql).map(CreateTableAs.tupled)

  case class InsertQuery(name: Table, cols: Option[Seq[Col]], expr: Table) extends Clause

  case class Insert(name: Table, cols: Option[Seq[Col]], values: Seq[Seq[Expr]]) extends Clause

  def insertValues[_: P]: P[Insert] =
    (W("insert") ~ W("into") ~
      tableRef ~ ("(" ~ column.repComma() ~ ")").? ~
      (W("values") ~ "(" ~ (sqlExpr | variable).repComma() ~ ")").rep(1)
      ).map(Insert.tupled)

  def fromInsertSet(name: Table, set: Seq[SetClause]): Insert = {
    //SAS supports multiple SET clauses, meaning you might insert more than one row, ordering the columns differently in each row
    //It is necessary to reorder the rows following a unique ordering, so we can convert it to INSERT VALUES.
    //https://documentation.sas.com/doc/en/pgmsascdc/9.4_3.5/sqlproc/n00p1g1wr4q7pzn1e6o5i82n7iml.htm#n1ifxp7r9ec7uon1ns9ilauv6o1u
    val itemsLst = set
      .map(
        _.items
          .map(i => i.column -> i.expr)
      )

    val columns = itemsLst
      .flatMap(_.map(_._1))
      .distinct
      .sortBy(_.n)

    val values: Seq[Seq[Expr]] = for (i <- itemsLst) yield {
      val mapItems = i.toMap
      columns
        .map(c => c -> mapItems.getOrElse(c, Null).asInstanceOf[Expr])
        .sortBy(_._1.n)
        .map(_._2)
    }

    Insert(name, Some(columns), values)
  }

  def insertSet[_: P]: P[Insert] =
    (W("insert") ~ W("into") ~
      directTable ~ ("(" ~ column.repComma() ~ ")").? ~
      setClause.rep(1)
      ).map(i => fromInsertSet(i._1, i._3))

  def insertQuery[_: P]: P[InsertQuery] =
    (W("insert") ~ W("into") ~
      directTable ~ ("(" ~ column.repComma() ~ ")").? ~
      dql
      ).map(InsertQuery.tupled)


  case class Update(table: Table, set: SetClause, where: Option[Where]) extends SqlExpr {
    table match {
      case SQL.Query(_) => throw new ParseException("Update cannot operate on query expressions", 0)
      case _ => // do nothing for all other subclasses of Table, it is supported by update
    }
  }
  def update[_: P]: P[Update] =
    (W("update") ~ table ~
      setClause ~ where.?).map(Update.tupled)

  //  catch all class for unrecognized expressions
  case class UnknownExpr(name: String) extends SqlExpr
  def unknownExpr[_: P]: P[UnknownExpr] =
    (token ~ CharsWhile(_ != ';')).map(UnknownExpr)

}
