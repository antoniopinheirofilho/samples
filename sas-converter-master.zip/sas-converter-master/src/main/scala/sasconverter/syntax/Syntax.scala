package sasconverter.syntax

import java.text.ParseException

import fastparse._
import org.apache.logging.log4j.scala.Logging
import sasconverter.steps.{Passthrough}
import sasconverter.syntax.Macro.MacroExpr
import sasconverter.{Context, Generating}

import scala.collection.mutable

/**
 * Manually transcribed from
 * https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=ds2pg&docsetTarget=p1668x799ckmj5n0zinpf4m7j6fy.htm&locale=en
 */
object Syntax extends Logging {
  import Implicits._
  import Operators._

  def letter[_: P]    = P( lowercase | uppercase )
  private def lowercase[_: P] = P( CharIn("a-z") )
  private def uppercase[_: P] = P( CharIn("A-Z") )
  def digit[_: P]     = P( CharIn("0-9") )

  // TODO: maybe with ~ !(letter | digit | "_") ?...
  def W[_: P](s: String): P[Unit] = IgnoreCase(s)
  def B[_: P](s: String): P[Boolean] = W(s).!.?.map(_.isDefined)

  trait Expr {
    // inline - within F.expr or .where, code - in python
    def sql(context: Context): String
  }
  sealed trait Constant extends Expr
  sealed trait SasNumeric extends Constant

  private def sign[_: P] = P( ("+" | "-").?.! )
  private def n[_: P]    = P( ("n" | "N").? )
  // integerN|n
  def integer[_: P]: P[Integer] = P( sign ~~ digit.rep(1).! ~~ n ) map {
    case (sign, i) => Integer(if (sign.equals("-")) -1 * i.toInt else i.toInt)
  }
  case class Integer(v: Int) extends SasNumeric {
    override def sql(context: Context): String = v.toString
  }

  // E|e[+|-]exponent
  def exponent[_: P]: P[Int] = P( ("E" | "e") ~~ sign ~~ digit.rep.! ) map {
    case (s, i) => if (s.equals("-")) -1 * i.toInt else i.toInt
  }

  // Fractional("",0,0,0) is NULL
  case class Fractional(sign: String, i: Int, f: Int, exponent: Int) extends SasNumeric {
    override def sql(context: Context): String =
      s"$sign$i.$f" + (if (exponent != 0) s"e$exponent" else "")
  }
  def fractional[_: P]: P[Fractional] = P( sign ~~ digit.rep.! ~~
    "."  ~~ n ~~ digit.rep.! ~~ exponent.? ~~ n ) map {
    case (s, i, f, e) => Fractional(
      sign = s,
      i = if (i.equals("")) 0 else i.toInt,
      f = if (f.equals("")) 0 else f.toInt,
      exponent = e.getOrElse(0))
  }

  case class Char(s: String) extends Constant {
    // TODO: escape characters
    override def sql(context: Context): String = s"'$s'"
  }
  def char[_: P]: P[Char] = P( "'" ~ (
    CharsWhile(!"'".contains(_))
      // To have a single quotation mark(') or apostrophe (’) in a string,
      // use an additional quotation mark.
      | "'" ~~ ("'" | "’")
      | !"'"
    ).rep.! ~ "'" ) map {
    case (s) => Char(s
      .replaceAll("''", "'")
      .replaceAll("'’", "’"))
  }

  // TODO: add support for binary constants: b'11100011' | x'FF143E99'

  case class Date(year: Int, month: Int, day: Int) extends Constant {
    override def sql(context: Context): String = s"CAST('$year-$month-$day' AS DATE)"
  }
  // date 'yyyy-mm-dd'
  def date[_: P]: P[Date] = P( "date" ~ "'" ~~
    digit.rep.! ~~ "-" ~~
    digit.rep.! ~~ "-" ~~
    digit.rep.! ~~ "'" ) map {
    case (y,m,d) => Date(y.toInt, m.toInt, d.toInt)
  }

  // TODO: maybe time 'hh:mm:ss.fraction' and timestamp 'yyyy-mm-dd hh:mm:ss'
  // TODO: add support for constant list
  // TODO: add support for constant list iterators: (5* 3 => 3 3 3)

  case class Null() extends Constant {
    override def sql(context: Context): String = "NULL"
  }
  def `null`[_: P] = P( IgnoreCase("null")
    | "._"    // 1 The value ._ (period followed by an underscore)
    | "." ~~ uppercase // or .A–.Z represent a special numeric missing value.
    | "' '"   // blank space between single quotation marks is nonexistent data.
  ) map { case() => Null() }

  private def comaOrSpace[_: P] = P( ("," ~ " ".rep.?) | " ".rep )
  case class ConstantList(cl: Seq[Constant]) extends Constant {
    override def sql(context: Context): String = "(" + cl.map(_.sql(context)).mkString(", ") + ")"
  }
  def constantList[_: P]: P[ConstantList] = P(
    "(" ~ constant.rep(sep=comaOrSpace) ~ ")" ).map(ConstantList)

  def constant[_: P]: P[Constant] = P( `null` | integer | fractional | char | date | constantList )

  // Delimited identifiers are case-sensitive only for identifiers that
  // require double quotation marks, that is, table and schema names.
  // Other delimited identifiers are not case-sensitive.
  // Delimited identifiers allow any character and must be enclosed in
  // double quotation marks. Variable names "Name", "NAME", Name, name,
  // and NaMe all represent the same variable.
  case class Identifier(name: String) extends Expr {
    // TODO: add special char handling
    override def sql(context: Context): String = name
  }

  case class TwoLevelIdentifier(libref: String, name: String) extends Expr {
    override def sql(context: Context): String = libref + "." + name
  }

  case class OneLevelVariable(value: Variable) extends Passthrough
  case class OneLevelInterpolatedVariable(value: Variable, rest: String) extends Passthrough
  case class TwoLevelInterpolatedVariable(value: Variable, rest: Variable) extends Passthrough
  case class TwoLevelInterpolatedVariableSuffix(value: Variable, rest: OneLevelInterpolatedVariable) extends Passthrough


  val sqlKeywords = Set("select", "distinct", "unique", "informat", "format",
    "label", "transcode", "yes", "no", "as", "case", "else", "end",
    "when", "then", "separated", "by", "into", "join", "on", "from", "where",
    "group",  "having", "asc", "desc", "order", "union", "outer", "union",
    "except", "intersect", "corresponding", "corr", "create", "table",
    "view")

  val keywordList = Set(
    "data", "in", "drop", "keep", "rename", "run", "where", "set",
    "curobs", "end", "indsname", "key", "keyreset", "open", "point",
    "unique", "time", "not", "or", "and", "like", "eq", "ne", "of",
    "macro", "mend", "do", "while", "to", "if", "by", "let", "else",
    "then", "case", "when"
  ).union(sqlKeywords)


  def tokenVar[_:P] = (token | variable).map{
    case m:String => m
    case m: Variable => s"{${m.name}}"
  }

  // TODO: somehow CharsWhile(c => isLetter(c) || isDigit(c)) doesn't work as expected...
  def token[_: P]: P[String] = P( (letter|"_") ~~ (letter|digit|"_").repX ).!.map(_.toLowerCase)
  def name[_: P]: P[String] = token
    .filter(!keywordList.contains(_))
    .opaque("name")
    
  def doubleQuoted[_: P]: P[String] = P( "\"" ~ (
    CharsWhile(!"\"".contains(_))
      // Special characters in delimited identifiers must be enclosed
      // in matching double quotation marks
      | "\"" ~~ AnyChar
      | !"\""
    ).rep.! ~ "\"" )

  def identifier[_: P]: P[Identifier] = P( name | doubleQuoted ).log.map(Identifier)
  def twolevelIdentifier[_: P]: P[TwoLevelIdentifier] = P( (name ~~ "." ~~ name) | (doubleQuoted ~~ "." ~~ doubleQuoted) ).log.map(TwoLevelIdentifier.tupled)
  def oneLevelVariable[_:P] = (variable).log.map(OneLevelVariable)
  def oneLevelVariableInterpolated[_:P] = (variableInterpolated ~~ (CharsWhile(!" ".contains(_)) | CharsWhile(!";".contains(_))).!).log.map(OneLevelInterpolatedVariable.tupled)
  def twoLevelVariableInterpolated[_:P] = (variableInterpolated ~ "." ~ variableInterpolated).log.map(TwoLevelInterpolatedVariable.tupled)
  //def twoLevelVariableInterpolatedSuffix[_:P] = (variableInterpolated ~ "." ~ oneLevelVariableInterpolated).map(TwoLevelInterpolatedVariableSuffix tupled)

  trait Vars extends Expr
  case class VariableList(vars: Seq[Identifier]) extends Vars {
    override def sql(context: Context): String = vars.map(_.sql(context)).mkString(", ")
  }

  case class Variable(name: String) extends Vars {
    // TODO: make sure we generate f'''-strings
    override def sql(context: Context): String = s"{$name}"
  }
  def variable[_: P]: P[Variable] = ("&" ~~ name).map(Variable)
  def variableInterpolated[_: P]: P[Variable] = ("&" ~~ name ~~ ".".?).map(Variable)

  private def varRange(vn: String, start: String, end: String, step: Int) =
    VariableList(Range(start.toInt, end.toInt + step, step)
      .map(n => Identifier(s"$vn$n")))

  // Numbered Range Variable Lists - x1-x5 expands to x1 x2 x3 x4 x5
  def varRangeList[_: P] = P( for {
      left <- (letter|"_").rep.! ~~ digit.rep.! ~ "-"
      right <- left._1 ~~ digit.rep.! map {
        case end if end > left._2 => varRange(left._1, left._2, end, 1)
        case end if left._2 > end => varRange(left._1, left._2, end, -1)
      }
    } yield right )

  def varNameList[_: P] = P(identifier.repSpace()).map(VariableList)

  case class VariablePrefixedList(prefix: Identifier) extends Vars {
    override def sql(context: Context): String =
      s"/* TODO: var prefix unsupported. rewrite '$prefix' manually */"
  }
  def varPrefixList[_: P] = P(identifier ~~ ":").map(VariablePrefixedList)

  case class MixedVariablesList(vars: Seq[Vars]) extends Vars {
    def hasPrefixedList: Boolean = vars.exists(_.isInstanceOf[VariablePrefixedList])

    def allIdentifierNames: Seq[String] = vars.flatMap {
      case VariableList(vars) => vars
    } map (_.name)

    override def sql(context: Context): String = vars.map(_.sql(context)).mkString(", ")
  }
  // TODO: named ranges don't work yet: `rep_jan--rep_july`
  // TODO: `u x1-x3 u:` doesn't work yet...
  def variableList[_: P]: P[MixedVariablesList] = P( (varPrefixList | varRangeList | varNameList).repSpace() ).map(MixedVariablesList)


  sealed trait Operator extends Expr
  // TODO: reuse Binary
  case class BinaryOp(left: Expr, op: OperatorSymbol, right: Expr) extends Operator {
    private def wrap(e: Expr, c: Context) = e match {
      case b: BinaryOp => s"(${b.sql(c)})"
      case _ => e.sql(c)
    }

    override def sql(ctx: Context): String = op match {
      case _: Straight          => s"${wrap(left, ctx)} $op ${wrap(right, ctx)}"
      case MinOfTwo             => s"MIN(${wrap(left, ctx)}, ${wrap(right, ctx)})"
      case MaxOfTwo             => s"MAX(${wrap(left, ctx)}, ${wrap(right, ctx)})"
      case Concatenate          => s"CONCAT(${wrap(left, ctx)}, ${wrap(right, ctx)})"
      case StripAndConcatenate  => s"CONCAT(TRIM(${wrap(left, ctx)}), TRIM(${wrap(right, ctx)}))"
      case NotIn                => s"NOT (${wrap(left, ctx)} IN ${wrap(right, ctx)})"
      case _                    => throw new ParseException(s"Unknown binary op: $op", 0)
    }
  }

  // todo: this is not used
  case class UnaryOp(op: String, operand: Expr) extends Operator {
    override def sql(context: Context): String =
      (if (Seq("not", "~", "^") contains  op ) "NOT"
        else op) + operand.sql(context)
  }

  // IN is unary only in cases of a not in ('b','c') ?...
  case class Unary(symbol: OperatorSymbol, right: Expr) extends Expr {
    override def sql(context: Context): String =
      s"${symbol.toString} ${right.sql(context)}"
  }

  def Chain[_: P](p: => P[Expr], op: => P[OperatorSymbol]) = P( p ~ (op ~ p).rep ).map{
    case (lhs, chunks) =>
      chunks.foldLeft(lhs) {
        case (left, (op, right)) => BinaryOp(left, op, right)
      }
  }

  /**
   * Operators and Their Order of Precedence in DS2 Expressions
   *
   * @see https://v8doc.sas.com/sashtml/lrcon/z0780367.htm
   *
   * in the expression 5+a**b*3, (a**b) is calculated first
   * and then multipled by 3, and that result is added to 5.
   *
   * Precedence | Symbol      | Associativity
   * -----------+-------------+--------------
   * 1           ( )           left to right
   * 1           SELECT        left to right
   * 2 (unary)   +, –          right to left
   * 2 (unary)   NOT, ^, ~     left to right
   * 2           **, <>, ><    left to right
   * 3           *, /          left to right
   * 4           +, –          left to right
   * 5           || or !!      left to right
   * 5           ..            left to right
   * 6           IN, LIKE      left to right
   * 7           =, ^= or ~=   right to left
   * 7           >=, <=, >, <  left to right
   * 8           &             left to right
   * 9           | or !        left to right
   * 10          IF            right to left
   * none        :=            none
   * none        _NEW_         none
   * none        Method        none
   */
  def expr[_: P]: P[Expr]               = P( Chain(and, Or.P) )
  private def and[_: P]: P[Expr]        = P( Chain(comparison, And.P) )
  private def comparison[_: P]: P[Expr] = P( Chain(relational, LessThan.P | GreaterThan.P | GreaterEquals.P | LessEquals.P) )
  private def relational[_: P]: P[Expr] = P( Chain(like, Equals.P | NotEquals.P) )
  private def like[_: P]: P[Expr]       = P( Chain(strip, NotIn.P | InList.P | Like.P) )
  private def strip[_: P]: P[Expr]      = P( Chain(merge, StripAndConcatenate.P) )
  private def merge[_: P]: P[Expr]      = P( Chain(subAdd, Concatenate.P) )
  private def subAdd[_: P]: P[Expr]     = P( Chain(multDiv, Add.P | Subtract.P) )
  private def multDiv[_: P]: P[Expr]    = P( Chain(powMinMax, Multiply.P | Divide.P) )
  private def powMinMax[_: P]: P[Expr]  = P( Chain(unary | primary, Power.P | MaxOfTwo.P | MinOfTwo.P) )
  private def unary[_: P]: P[Expr]      = unaryOf(primary)
  private def parens[_: P]              = P( "(".? ~ expr ~ ")".? )
  def primary[_: P]: P[Expr]            = P( call | identifier | constant | parens )

  case class Binary(left: Expr, symbol: OperatorSymbol, right: Expr) extends Expr {
    override def sql(context: Context): String = ""
  }

  private def climb(left: Expr,
                    rights: Seq[(OperatorSymbol,Option[Expr])],
                    prec: Int = 100): Expr = {
    rights.headOption match {
      case None => left
      case Some((sym, next)) =>
        if (sym.precedence < prec) left match {
          case Binary(first, prevSymbol, right) =>
            Binary(first, prevSymbol,
              climb(Binary(right, sym, next.getOrElse(Null())),
                rights.tail, sym.precedence+1))
          case _ => climb(Binary(left, sym, next.getOrElse(Null())),
            rights.tail, sym.precedence+1)
        } else Binary(left, sym,
          climb(next.getOrElse(Null()), rights.tail, sym.precedence+1))
    }
  }

  def unaryOf[_: P](expr: => P[Expr]) = (UnaryNot.P ~ " ".rep
    | UnaryPlus.P | UnaryMinus.P) ~ expr map (Unary.tupled)

  def binaryOf[_: P](a: => P[Expr], b: => P[OperatorSymbol]): P[Expr] = {
    // in SAS when a binary operator is missing the right side is equivalent to comparing with Null
    (a ~ (b ~ a.?).rep).map {
      case (expr, tuples) => climb(expr, tuples)
    }
  }

  case class Call(name: String,
                  args: Seq[Expr] = Seq()) extends Expr {
    override def sql(context: Context): String = {
      context.addUsedFunction(name)
      s"$name(${args.map(_.sql(context)).mkString(", ")})"
    }
  }
  def call[_: P]: P[Call] = P( name ~~ (
    ("(" ~ ")")
      | ("(" ~ (W("of") ~ variableList).repSpace(1) ~ ")")
      | ("(" ~ expr.repComma(0) ~ ")")
  )) map {
      case (n: String, args: Seq[Expr]) => Call(n, args)
      case (n: String, ()) => Call(n)
      case x: Any => throw new ParseException(s"Cannot parse 'call': $x", 0)
  }

  // <$>informat<w>.<d>
  case class Informat(character: Boolean, name: Option[String], width: Int = 0, scaling: Int = 0) extends Passthrough

  private def intOrZero[_: P] = digit.repX(1).!.?.map(_.map(_.toInt).getOrElse(0))
  private def infName[_:P] = letter.repX(1).repX(sep = digit.repX).!.?
    .map(_.filter(!"".equals(_)).map(_.toLowerCase))
  def informat[_: P] = ("$".!.?.map(_.isDefined) ~~ infName ~~ intOrZero ~~ "." ~~ intOrZero).map(Informat.tupled)
}
