package sasconverter.syntax

import java.io.InputStream

import fastparse._
import org.apache.logging.log4j.scala.Logging


object ProjectXML extends Logging {
  import Implicits._

  sealed trait Elem
  private[syntax] case class AnyCode(s: String) extends Elem
  case class TaskCode(s: String) extends Elem

  private def taskCode[_:P]: P[TaskCode] = ("<TaskCode>" ~
      CharsWhile(!"<".contains(_)).rep.! ~
      "</TaskCode>") map { str =>
    TaskCode(str.replace("&amp;", "&"))
  }

  private def anyCode[_:P]: P[AnyCode] = (!"<TaskCode>" ~ AnyChar).rep(1).!.map(AnyCode)
  def parser[_:P]: P[Seq[Elem]] = (anyCode|taskCode).rep ~ End

  def getTasks(is: InputStream): Seq[TaskCode] =
    // TODO: this doesn't currenty work with CP-1252 and ISO-* encodings. fix it later
    parse(is, parser(_), verboseFailures = true) match {
      case Parsed.Success(value, _) =>
        value
          .filter(_.isInstanceOf[TaskCode])
          .map(_.asInstanceOf[TaskCode])
      case failure: Parsed.Failure =>
        logger.error(failure.longMsg)
        Seq()
    }
}
