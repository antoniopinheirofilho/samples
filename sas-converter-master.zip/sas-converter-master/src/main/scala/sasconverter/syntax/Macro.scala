package sasconverter.syntax

import org.apache.logging.log4j.scala.Logging

import scala.collection.mutable
import java.text.ParseException

import sasconverter.Context
import fastparse._

import scala.annotation.tailrec

object Macro extends Logging {
  import Implicits._
  import Operators._
  import Syntax._

  private val global: Scope = Scope()
  private val macros = mutable.Map[String,Callable]()
  private val systemFunctions = mutable.Map[String,Seq[Any] => Any]()
  private val unresolvedRefs = mutable.ArrayBuffer[String]()

  implicit def debugLogger[R](r: R) = new {
    def @@ (implicit ctx: P[_], name: sourcecode.Name): R = {
      if (ctx.logDepth == -1) return r
      val indent = "  " * ctx.logDepth
      val rep = ctx.successValue.toString.replaceAll("ArrayBuffer", "Seq")
      val debug = rep.substring(0, Math.min(rep.length, 128))
      if ("()".equals(debug)) return r
      //ctx.logDepth += 1
      //print(s"$indent@${name.value}: ${debug}\n")
      r
    }

    def tap(l: R => String): R = {
//      println(l(r))
//      logger.trace(l(r))
      r
    }
  }

  sealed trait MacroExpr extends Expr {
    def sql(context: Context): String = ""
  }

  sealed trait Statement {
    def process(scope: Scope): String
  }

  case class Scope(parent: Option[Scope] = None, locals: mutable.Map[String,Expr] = mutable.Map()) {
    // TODO: make locals private to change assignment: https://blogs.sas.com/content/sgf/files/2015/02/macroscope1.png
    // other interesting details on macro scopes: https://v8doc.sas.com/sashtml/macro/z1072111.htm

    /** Create new child scope with empty locals */
    def newChild: Scope = Scope(Some(this), mutable.Map())

    def resolve(expr: Expr): Any = (expr match {
      case Binary(left, sym, right) => (resolve(left), resolve(right)) match {
        case (a: String, b: String) => sym match {
          case Equals => a.equals(b)
          case NotEquals => !a.equals(b)
          case _ => throw new MacroException(s"Unknown operation $left $sym $right", 0)
        }
        case (a: String, null) => sym match {
          case Equals => a == ""
          case NotEquals => a != ""
          case _ => throw new MacroException(s"Unknown operation $left $sym $right", 0)
        }
        // By default, arithmetic evaluation in most macro statements and functions is
        // performed with integer arithmetic. The exception is the %SYSEVALF function.
        case (a: Int, b: Int) => sym match {
          case Add => a + b
          case Subtract => a - b
          case Multiply => a * b
          case Divide => a / b
          case Power => Math.pow(a.toDouble, b.toDouble)
          case Equals => a == b
          case NotEquals => a != b
          case LessThan => a < b
          case LessEquals => a <= b
          case GreaterThan => a > b
          case GreaterEquals => a >= b
          case _ => throw new ParseException(s"Unknown arithmetic symbol: $a $sym $b", 0)
        }
        case (a: Boolean, b: Boolean) => sym match {
          case And => a & b
          case Or => a | b
          case _ => throw new ParseException(s"Unknown boolean symbol: $a $sym $b", 0)
        }
        case (a: Any, b: Any) =>
          throw new MacroException(s"Unknown binary $a $sym $b", 0)
      }
      case Unary(sym, expr) => (sym, resolve(expr)) match {
        case (UnaryNot, b: Boolean) => !b
        case (UnaryPlus, i: Int) => +i
        case (UnaryMinus, i: Int) => -i
        case _ => throw new MacroException(s"Unknown unary $sym $expr", 0)
      }
      case r: Resolvable => r.resolve(this)
      case Variable(n) => resolve(resolveUp(n))
      case TwoLevelVariable(n1, n2) => s"${resolve(n1)}.${resolve(n2)}"
      case OneLevelVariableInterpolated(n1,n2) => s"${resolve(n1)}.${n2}"
      case OneLevelVariableSuffix(n1,n2) => s"${resolve(n1)}${n2}"
      case Identifier(n) => n
      case Integer(n) => n
      case Char(n) => n
      case Null() => null
      case Code(s) => s
      case s: Expr => throw new MacroException(s"Unknown expr $s", 0)
    }) tap { r => s"$expr => $r" }

    private def resolveUp(k: String): Expr = locals
      .get(k).orElse(parent.map(_.resolveUp(k)))
      .getOrElse(Null())

    def resolveInt(expr: Expr): Int = resolve(expr).toString.toInt
    def resolveBool(expr: Expr): Boolean = resolve(expr) match {
      case b: Boolean => b
      case i: Int => i != 0
      case s: String if s.equals("") => false
      case s: String if !s.equals("") => true
    }
  }

  def process(code: String): String = {
    parse(code, main(_)) match {
      case Parsed.Success(block, _) => block.process(global)
      case Parsed.Failure(_, index, extra) =>
        val shortMsg = extra.trace().msg
        val surround = shortMsg.length
        val details = extra.trace(true)
          .longAggregateMsg.split("\\|")
          .map(_.trim).mkString("\n\tor ")
        val reasoning =
          s"""PARSE FAILURE at ${extra.input.prettyIndex(index)}
             |
             |${extra.input.slice(index-surround, index+surround).replace("\t", " ")}
             |${"-" * (surround-1)} ^ $shortMsg
             |
             |Details: $details
             |""".stripMargin
        println(reasoning)
        throw new MacroException(
        extra.trace(true).longAggregateMsg, index)
    }
  }

  case class Block(statements: Seq[Statement] = Seq()) extends Statement {
    override def process(scope: Scope): String = statements.map(_.process(scope)).mkString
  }

  case class Code(text: String) extends Statement with MacroExpr {
    override def process(scope: Scope): String = text + " "
  }

  case class Let(variable: String, value: Expr) extends Statement {
    override def process(scope: Scope): String = {
      scope.locals(variable) = scope.resolve(value) match {
        case s: String => Char(s)
        case i: Int => Integer(i)
        case b: Boolean => Integer(if(b) 1 else 0)
        case a: Any => throw new MacroException(s"Unknown variable type $a", 0)
      }
      ""
    }
  }

  case class Argument(value: Expr, key: Option[String] = None)
  case class Parameter(name: String, value: Option[Expr] = None)

  sealed trait Callable extends MacroExpr {
    def call(scope: Scope, args: Seq[Argument]): Any
  }

  sealed trait Resolvable extends Statement with MacroExpr {
    override def process(scope: Scope): String = resolve(scope).toString
    def resolve(scope: Scope): Any
  }

  case class Definition(name: String,
                        params: Seq[Parameter],
                        block: Block) extends Callable with Statement {
    override def process(scope: Scope): String = {
      macros(name) = this
      ""
    }

    override def call(scope: Scope, args: Seq[Argument]): String = {
      val child = scope.newChild
      // this is only an approximate behavior of &SYSPBUFF
      // better doc here: https://v8doc.sas.com/sashtml/macro/z0206961.htm
      child.locals("syspbuff") = Char(args.map(_.value).map(scope.resolve).mkString(","))
      val pa = positionalArguments(args)
      params.zipWithIndex.foreach {
        case (parameter, i) =>
          child.locals(parameter.name) = pa.get(i) // positional
            .orElse(args // named
              .find(_.key.exists(_ == parameter.name))
              .map(_.value))
            .orElse(parameter.value) // default
            .getOrElse(Null())
      }
      block.process(child)
    }

    private def positionalArguments(args: Seq[Argument]) = {
      var done = false
      var work = args.zipWithIndex
      val posargs = mutable.Map[Int,Expr]()
      while (!done) {
        work.headOption match {
          case Some((argument, index)) =>
            argument.key match {
              case None =>
                posargs(index) = argument.value
                work = work.tail
              case Some(_) => done = true
            }
          case None => done = true
        }
      }
      posargs
    }
  }

  class MacroException(msg: String, offset: Int) extends ParseException(msg, offset)

  // Reference wrapper to register default available macros
  private case class AutoCall(conv: Seq[Any] => Any) extends Callable {
    override def call(scope: Scope, args: Seq[Argument]): Any =
      conv(args.map(_.value).map(scope.resolve))
  }

  private case class QuotedAlias(callable: Callable) extends Callable {
    override def call(scope: Scope, args: Seq[Argument]): Any =
      callable.call(scope, args) match {
        case text: String => quote(text)
        case any: Any => any
      }
  }

  // TODO: if statement with %SYSFUNC(EXIST(table)) should be rewritten to Python, and not be a preprocessor
  systemFunctions("exist") = _ => 1

  // TODO: LEFT returns an argument with leading blanks moved to the end of the value. The argument's length does not change.
  systemFunctions("left") = (a) => a.head.toString.trim

  case class SysFunc(name: String = "sysfunc", func: String,
                     args: Seq[Argument] = Seq(),
                     format: Option[String] = None) extends Resolvable {
    override def resolve(scope: Scope): Any = systemFunctions.get(func)
      .map(_(args.map(_.value).map(scope.resolve)))
      .getOrElse({
        logger.warn(s"Cannot find ${func.toUpperCase} system function")
        unresolvedRefs += name
        ""
      })
  }

  macros("upcase") = AutoCall(_.head.toString.toUpperCase)
  macros("qupcase") = QuotedAlias(macros("upcase"))
  macros("lowcase") = AutoCall(_.head.toString.toLowerCase)
  macros("qlowcase") = QuotedAlias(macros("lowcase"))
  macros("length") = AutoCall(_.head.toString.length)

  // https://v8doc.sas.com/sashtml/macro/z514scan.htm

  private val DELIMITERS = " .<(+&!$*);^-/,%|"
  private val DELIM_WORDS = "AND OR NOT EQ NE LE LT GE GT"
  private val MNEMONICS: Set[String] = DELIM_WORDS.toLowerCase.split(" ").toSet
  private val UNQUOTE_REGEX = "(" + (DELIM_WORDS.split(" ") ++
    MNEMONICS ++ DELIMITERS.split("").map("\\" + _)).mkString("|") + ")"

  // quoting rules: https://v8doc.sas.com/sashtml/macro/z1061345.htm
  private def unquote(text: String) = text.replaceAll("%" + UNQUOTE_REGEX, "$1")
  private def quote(text: String) = text.replaceAll(UNQUOTE_REGEX, "%$1")

  // %input for dbutils.widget.text()
  macros("scan") = AutoCall(args => {
    val pos = args(1).toString.toInt-1
    val delims = args.lastOption.map(_.toString).getOrElse(DELIMITERS)
    val sp = args.head.toString.split(delims.map("\\" + _).mkString)
    if (sp.size > pos) {
      val res = sp(pos)
      unquote(res)
    }
    else ""
  })
  macros("qscan") = QuotedAlias(macros("scan"))

  case class Reference(name: String, args: Seq[Argument] = Seq()) extends Resolvable {
    override def resolve(scope: Scope): Any = macros.get(name)
      .map(callable => callable.call(scope.newChild, args))
      .getOrElse({
        // TODO add Index tracking
        logger.warn(s"Cannot find ${name.toUpperCase()} macro definition")
        unresolvedRefs += name
        ""
      })
  }

  case class Eval(expr: Expr) extends Resolvable {
    override def resolve(scope: Scope): Any = scope.resolve(expr)
  }

  case class Bquote(value: Expr) extends Resolvable {
    override def resolve(scope: Scope): Any = {
      val resolved = scope.resolve(value)
      quote(resolved.toString)
    }
  }

  /**
   * The %STR and %NRSTR functions mask a character string during compilation of
   * a macro or macro language statement. In addition, %NRSTR also masks `&`, `%`
   */
  case class StrMacro(str: Seq[Expr]) extends Resolvable {
    override def resolve(scope: Scope): Any = str.map {
      case r: Resolvable => r.resolve(scope)
      case Char(v) => quote(v)
    } mkString
  }

  case class Variable(name: String) extends MacroExpr with Statement {
    override def process(scope: Scope): String = {
      val value = scope.resolve(this)
      if (value == null) {
        logger.warn(s"Variable $name is not defined")
        ""
      } else value.toString
    }
  }

  // TODO this is a temp fix for supporting table like inputs
  case class TwoLevelVariable(var1: Variable, var2: Variable) extends MacroExpr with Statement {
    override def process(scope: Scope): String = {
      val value1 = scope.resolve(var1)
      val value2 = scope.resolve(var2)
      if (value1 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      } else if (value2 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      }
      else s"$value1.$value2"
    }
  }

  case class OneLevelVariableInterpolated(var1: Variable, value2: String) extends MacroExpr with Statement {
    override def process(scope: Scope): String = {
      val value1 = scope.resolve(var1)
      if (value1 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      } else if (value2 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      }
      else s"$value1.$value2"
    }
  }

  case class OneLevelVariableSuffix(var1: Variable, value2: String) extends MacroExpr with Statement {
    override def process(scope: Scope): String = {
      val value1 = scope.resolve(var1)
      if (value1 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      } else if (value2 == null) {
        logger.warn(s"Variable ${var1.name} is not defined")
        ""
      }
      else s"$value1.$value2"
    }
  }

  case class If(expr: Expr, Then: Statement, Else: Option[Statement]) extends Statement {
    override def process(scope: Scope): String = if (scope.resolveBool(expr))
      Then.process(scope)
    else Else.map(_.process(scope)).getOrElse("")
  }

  case class Do(block: Block) extends Statement {
    override def process(scope: Scope): String = block.process(scope)
  }

  case class DoTo(variable: String, start: Expr, stop: Expr,
                  by: Option[Expr], block: Block) extends Statement {
    override def process(scope: Scope): String = Range(
      scope.resolveInt(start), scope.resolveInt(stop) + 1,
      by.map(scope.resolveInt).getOrElse(1)).map(iteration => {
      val child = scope.newChild
      child.locals(variable) = Integer(iteration)
      block.process(child)
    }).mkString(" ")
  }

  case class DoWhile(cond: Expr, block: Block) extends Statement {
    override def process(scope: Scope): String = {
      var s = Array[String]()
      while (scope.resolveBool(cond)) {
        s +:= block.process(scope)
      }
      s.mkString
    }
  }

  case class Local(vars: VariableList) extends Statement {
    override def process(scope: Scope): String = {
      vars.vars.foreach {
        case Identifier(name) => scope.locals(name) = Null()
      }
      ""
    }
  }

  case class Global(vars: VariableList) extends Statement {
    override def process(scope: Scope): String = {
      vars.vars.foreach {
        case Identifier(name) => global.locals(name) = Null()
      }
      ""
    }
  }

  case class TextExpression(text: String) extends Resolvable {
    @tailrec private def implicitEval(input: String, scope: Scope): String =
      parse(input, textExpression(_)) match {
        case Parsed.Success(value, _) =>
          val intermediate = value.map(scope.resolve).mkString
          if (intermediate.equals(input)) {
            intermediate
          } else implicitEval(intermediate, scope)
        case _: Parsed.Failure =>
          s"DOES NOT COMPUTE: <$input>"
      }

    override def resolve(scope: Scope): Any = unquote(implicitEval(unquote(text), scope)).trim
  }

  // TODO: rename to test, because this really means .log?...
  case class Put(text: String) extends Resolvable {
    override def resolve(scope: Scope): Any = scope.resolve(TextExpression(text)) + "\n"
  }

  case class Comment(text: String) extends Statement {
    // comments are ignored for now.
    override def process(scope: Scope): String = ""
  }

  case class Goto(label: String) extends Statement {
    // TODO: implement it
    override def process(scope: Scope): String = ""
  }

  case class GotoLabel(label: String) extends Statement {
    // TODO: implement it
    override def process(scope: Scope): String = ""
  }

  // todo: %* Here is a macro-type comment.;
  def main[_: P]: P[Block]                   = ((code | definition | let | ref ~ ";".? | variable | comment).rep ~ End).map(Block).log.@@
  def textExpression[_:P]: P[Seq[MacroExpr]] = ((escaped | variable | ref | amp | code).rep ~ End).log.@@

  def statement[_: P]                     = (code | amp | variable | local | globalm | `do` | doTo | doWhile | goto | ref | let | `if` | definition | comment | gotoLabel).log.@@
  def block[_: P]: P[Block]               = statement.rep.map(Block).log.@@
  def goto[_: P]                          = (M("goto") ~ name ~ ";").map(Goto).log.@@
  def gotoLabel[_:P]                      = ("%" ~~ name ~~ ":").map(GotoLabel).log.@@
  def comment[_:P]                        = ("%*" ~ CharsWhile(!";".contains(_)).! ~ ";").map(Comment).log.@@
  def code[_: P]                          = P( CharsWhile(!"%&".contains(_)).! ).map(x => Code(x)).opaque("code").log.@@
  def variable[_: P]                      = P( "&" ~~ token ~~ ".".? ).map(Variable).log.@@
  def twoLevelVariable[_: P]              = P( variable.rep(exactly=2, sep=".")).map(x => TwoLevelVariable(x(0), x(1))).log.@@
  def oneLevelVariableInterpolated[_:P]   = P( variable ~~ "." ~~ name).map(OneLevelVariableInterpolated.tupled).log.@@
  def oneLevelVariableSuffix[_:P]         = P( variable ~~ name).map(OneLevelVariableSuffix.tupled).log.@@
  def globalm[_: P]                       = (M("global") ~ varNameList ~ ";").map(Global).log.@@
  def local[_: P]                         = (M("local") ~ varNameList ~ ";").map(Local).log.@@
  def M[_: P](s: String): P[Unit]         = P("%" ~~ IgnoreCase(s)).log.@@

  def textExpr[_:P]: P[TextExpression]    = CharsWhile(!";".contains(_)).!.map(TextExpression).log.@@
  def let[_: P]: P[Let]                   =  letNull | letNotNull
  def letNotNull[_: P]: P[Let]            = (M("let") ~ name ~ "=" ~ (expr|identifier) ~ ";".?).map(Let.tupled).log.@@
  def letNull[_: P]: P[Let]               = (M("let") ~ name ~ "=" ~ ";").map(x => Let(x, Char("None"))).log.@@
  private def spaceAsNull[_: P]           = " ".repX.!.map(_ => Null()).log.@@
  def param[_: P]: P[Parameter]           = P( token ~ ("=" ~ (constant | unquoted | spaceAsNull) ).? ).map(Parameter.tupled).log.@@ // Changed to token instead of name because macro inputs can be from keyword list
  def paramList[_: P]: P[Seq[Parameter]]  = ("(" ~ param.repComma(0) ~ ")").?.map(_.getOrElse(Seq())).log.@@
  def definition[_: P]: P[Definition]     = P( M("macro") ~ name ~ paramList ~ "/parmbuff".? ~ ";" ~
    block ~ M("mend") ~ CharsWhile(!";".contains(_)).? ~ ";").map(Definition.tupled).log.@@

  private def argument[_: P]        = (((name ~ "=").? ~ argu). map { case (k, expr) => Argument(expr, k) }).log.@@
  def args[_: P]: P[Seq[Argument]]  = ("(" ~ argument.rep(sep=",") ~ ")").log.@@
  def noarg[_: P]                   = ("%" ~~ name ~ ";".?).map(Reference(_, Seq())).log.@@
  def refa[_: P]                    = ("%" ~~ name ~ args ~ ";".?).map(Reference.tupled).log.@@
  def ref[_: P]                     = (funcs | refa | noarg).log.@@
  def Q[_: P](s: String): P[String] = "%" ~~ (IgnoreCase(s) | IgnoreCase("q" + s)).!.log.@@
  private def sysfunc[_: P]         = (Q("sysfunc") ~ "(" ~ name ~ args ~ (name ~~ ".").? ~ ")").map(SysFunc.tupled).log.@@
  def amp[_: P]                     = ("&&".!.map(_ => Code("&"))).log.@@

  // %QSCAN masks the same characters as the %NRBQUOTE function.
  def escaped[_: P]                 = xyz.!.map(Code).log.@@
  private def xyz[_: P]             = ("%" ~~ (quotable | CharIn("&%"))).log.@@
  def mnemonics[_: P]               = (W("and") | W("or") | W("not") | W("ne") | W("eq") | W("le") | W("lt") | W("ge") | W("gt")).log.@@
  def quotable[_:P]                 = (mnemonics | CharIn(".<(+&!$*);^-/,%|")).log.@@
  // TODO: unquoted also going through TextExpression?...
  def charz[_: P]                   = CharsWhile(!" <(+!$);^-,%=|".contains(_)).!.filter(!MNEMONICS.contains(_)).opaque("charz").log.@@
  def unquoted[_: P]                = charz.rep(1).!.map(x => Char(x.trim)).log.@@
  def nrstr[_: P]                   = P(M("nrstr") ~ "(" ~ (CharsWhile(!")".contains(_)) | xyz).rep.! ~ ")").map(str => Code(quote(str))).log.@@
  def str[_: P]: P[StrMacro]        = P(M("str") ~ "(" ~~ (variable | ref | (CharsWhile(!")".contains(_)) | "%" ~~ quotable).rep.!.map(Char)).repX(max=100) ~ ")").map(StrMacro).log.@@
  def eval[_: P]                    = P(M("eval") ~ "(" ~ expr ~ ")").map(x => Eval(x)).log.@@
  def put[_: P]                     = (M("put") ~ CharsWhile(!";".contains(_)).rep.! ~ ";").map(Put).log.@@
  private def bquote[_: P]          = (M("bquote") ~ "(" ~ expr ~ ")").map(Bquote).log.@@
  private def funcs[_: P]           = (bquote | sysfunc | eval | str | nrstr | put).opaque("funcs").log.@@
  private def doubleQuoted[_: P]    = ("\"" ~ CharsWhile(!"\"".contains(_)).! ~ "\"").map(TextExpression) | P("\"\"").map(_ => Null()).log.@@
  def variableRef[_:P]              = (oneLevelVariableInterpolated | twoLevelVariable | oneLevelVariableSuffix | variable )
  private def argu[_: P]            = (variableRef | ref | constant | doubleQuoted | unquoted).log.@@
  def sym[_: P]: P[OperatorSymbol]  = (Power.P | Multiply.P | Divide.P | Add.P |  Subtract.P | LessThan.P | LessEquals.P |
                                       Equals.P | InList.P | NotEquals.P | GreaterThan.P | GreaterEquals.P | And.P | Or.P
                                      ).opaque("operators").log.@@
  private def parens[_: P]          = ("(" ~ expr ~ ")").log.@@
  private def primary[_: P]         = (unaryOf(expr) | argu | parens | ref).log.@@
  def expr[_: P]: P[Expr]           = (binaryOf(primary, sym) | omitCond).log.@@
  private def end[_: P]             = (M("end") ~ ";".?).log.@@
  def `if`[_: P]: P[If]             = P( M("if") ~ expr ~ M("then") ~ statement ~ ";".? ~ (M("else") ~ statement ~ ";".?).? ).map(If.tupled).log.@@
  def `do`[_: P]: P[Do]             = P( M("do") ~ ";" ~ block ~ end ).map(Do).log.@@
  def omitCond[_: P]: P[Expr]       = (("(" ~ primary ~ sym ~ ")").map(x=> Binary(x._1, x._2, Null())) | parens).log.@@
  def doWhile[_: P]: P[DoWhile]     = P( M("do") ~ M("while") ~ omitCond ~ ";" ~ block ~ end ).map(DoWhile.tupled).log.@@
  def doTo[_: P](): P[DoTo]         = P( M("do") ~ name ~ "=" ~ expr ~ M("to") ~ expr ~ (M("by") ~ expr).? ~
                                      ";" ~ block ~ end ).map(DoTo.tupled).log.@@
}
