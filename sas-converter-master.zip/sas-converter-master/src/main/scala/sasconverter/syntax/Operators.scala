package sasconverter.syntax

import fastparse.P
import sasconverter.syntax.Syntax.W

object Operators {
  sealed trait OperatorSymbol {
    def P[_: P]: P[OperatorSymbol] = symbols.map(_ => this).opaque(getClass.getSimpleName)
    def symbols[_: P]: P[Unit]
    def precedence: Int
  }

  sealed trait Straight extends OperatorSymbol
  sealed trait Relational extends Straight

  def ALL[_: P]: P[OperatorSymbol] =
    (Concatenate.P // || vs |
    | Or.P
    | And.P
    | LessThan.P
    | GreaterThan.P
    | GreaterEquals.P
    | LessEquals.P
    | Equals.P
    | NotEquals.P
    | InList.P
    | NotIn.P
    | Like.P
    | Add.P
    | Subtract.P
    | Multiply.P
    | Divide.P
    | Power.P
    | StripAndConcatenate.P
    | MinOfTwo.P
    | MaxOfTwo.P)

  case object Or extends Straight {
    override def symbols[_: P]: P[Unit] = W(toString) ~~ " " | "|"
    override def toString: String = "OR"
    override val precedence: Int = 9
  }

  case object And extends Straight {
    override def symbols[_: P]: P[Unit] = W(toString) ~~ " " | "&"
    override def toString: String = "AND"
    override val precedence: Int = 8
  }

  case object LessThan extends Relational {
    override def symbols[_: P]: P[Unit] = W("lt") ~~ " " | toString
    override def toString: String = "<"
    override val precedence: Int = 7
  }

  case object GreaterThan extends Relational {
    override def symbols[_: P]: P[Unit] = W("gt") ~~ " " | toString
    override def toString: String = ">"
    override val precedence: Int = 7
  }

  case object GreaterEquals extends Relational {
    override def symbols[_: P]: P[Unit] = W("ge") ~~ " " | toString
    override def toString: String = ">="
    override val precedence: Int = 7
  }

  case object LessEquals extends Relational {
    override def symbols[_: P]: P[Unit] = W("le") ~~ " " | toString
    override def toString: String = "<="
    override val precedence: Int = 7
  }

  case object Equals extends Relational {
    override def symbols[_: P]: P[Unit] = W("eq") ~~ " " | toString
    override def toString: String = "="
    override val precedence: Int = 7
  }

  case object NotEquals extends Relational {
    // TODO: omitCond may break :/
    override def symbols[_: P]: P[Unit] = W("ne") | "^=" |"~="
    override def toString: String = "!="
    override val precedence: Int = 7
  }

  case object InList extends Straight {
    override def symbols[_: P]: P[Unit] = W(toString) ~~ " " | "#"
    override def toString: String = "IN"
    override val precedence: Int = 7
  }

  case object NotIn extends OperatorSymbol{
    override def symbols[_: P]: P[Unit] = W(toString)
    override def toString: String = "NOT IN"
    override val precedence: Int = 7
  }

  case object Like extends Straight {
    override def symbols[_: P]: P[Unit] = W(toString)
    override def toString: String = "LIKE"
    override val precedence: Int = 6
  }

  case object Add extends Straight {
    override def symbols[_: P]: P[Unit] = toString
    override def toString: String = "+"
    override val precedence: Int = 4
  }

  case object Subtract extends Straight {
    override def symbols[_: P]: P[Unit] = toString
    override def toString: String = "-"
    override val precedence: Int = 4
  }

  case object Multiply extends Straight {
    override def symbols[_: P]: P[Unit] = toString
    override def toString: String = "*"
    override val precedence: Int = 3
  }

  case object Divide extends Straight {
    override def symbols[_: P]: P[Unit] = toString
    override def toString: String = "/"
    override val precedence: Int = 3
  }

  case object Power extends Straight {
    override def symbols[_: P]: P[Unit] = toString
    override def toString: String = "**"
    override val precedence: Int = 2
  }

  case object StripAndConcatenate extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = ".."
    override val precedence: Int = 5
  }

  case object Concatenate extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = W("||") | "!!"
    override val precedence: Int = 5
  }

  case object MinOfTwo extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = "><"
    override val precedence: Int = 2
  }

  case object MaxOfTwo extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = "<>"
    override val precedence: Int = 2
  }

  case object UnaryNot extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = W("not") | "~" | "^"
    override def precedence: Int = 2
    override def toString: String = "NOT "
  }

  case object UnaryPlus extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = "+"
    override def precedence: Int = 2
    override def toString: String = "+"
  }

  case object UnaryMinus extends OperatorSymbol {
    override def symbols[_: P]: P[Unit] = "-"
    override def precedence: Int = 2
    override def toString: String = "-"
  }
}
