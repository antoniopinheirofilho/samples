package sasconverter.syntax

import java.io.File

import fastparse._
import org.apache.logging.log4j.scala.Logging
import sasconverter.syntax.Macro.M
import sasconverter.syntax.Syntax.name

import scala.io.Source

/**
 * This utility usually helps recursively walking a folder of SAS files
 * to discover all macros in them.
 */
object RoughMacros extends Logging {
  import Implicits._

  sealed trait Elem
  private[syntax] case class AnyCode(s: String) extends Elem
  private[syntax] case class MacroDef(name: String, macroCode: String) extends Elem {
    override def toString: String = s"%MACRO $name$macroCode\n%MEND $name;\n"
  }

  private def mend[_: P] = M("mend")
  private def macr[_: P] = M("macro")
  private def macroDef[_:P] = (macr ~ name ~
    (!mend ~ AnyChar).rep.! ~
    mend ~ CharsWhile(!";".contains(_)).? ~
    ";").map(MacroDef.tupled).log
  private def anyCode[_:P]: P[AnyCode] = (!macr ~ AnyChar).rep(1).!.map(AnyCode).log

  private[syntax] def parser[_:P]: P[Seq[Elem]] = (macroDef|anyCode).rep ~ End

  def discover(folder: String): Seq[MacroDef] =
    listFiles(new File(folder))
      .filter(_.getName.toLowerCase.endsWith(".sas"))
      .flatMap { file =>
        val source = Source.fromFile(file)
        try {
          parse(source.mkString, parser(_),
            verboseFailures = true) match {
            case Parsed.Success(value, _) => value
              .filter(_.isInstanceOf[MacroDef])
              .map(_.asInstanceOf[MacroDef])
            case failure: Parsed.Failure =>
              logger.error(failure.longMsg)
              Seq()
          }
        } catch {
          case e: Throwable =>
            // yes, even the OutOfMemoryError
            logger.error("Oops..", e)
            Seq()
        } finally try source.close catch {
          case e: Throwable =>
            logger.error("Cannot really close file", e)
            Seq()
        }
      }

  private def listFiles(f: File): Array[File] = {
    val items = f.listFiles
    items ++ items.filter(_.isDirectory).flatMap(listFiles)
  }
}