package sasconverter.steps

import java.text.ParseException

import sasconverter.syntax.SQL._
import sasconverter.syntax.Syntax.{Call, Expr, Variable}
import sasconverter.syntax.{SQL, Syntax}
import sasconverter.{Code, syntax}

import scala.collection.mutable

case class ProcSql(opts: Seq[Option], queries: Seq[SqlExpr]) extends Proc(opts) {
  /** What table or view this step defines */
  override def produces: String = ctasTableName(createTableAs.get.name)


  private def ctasTableName(tableName: SQL.Table): String =
    tableName match {
      case SQL.SimpleName(name, opts) =>
        s"work.$name"
      case SQL.TwolevelName(libref, name, opts) =>
        s"$libref.$name"
      case SQL.TableVariable(Variable(name), opts) =>
        s"{$name}"
      case SQL.TableInterpolatedVariable(Variable(name), rest, opts) =>
        s"{$name}.$rest"
      case SQL.TwoLevelTableInterpolatedVariable(Variable(name), Variable(rest), opts) =>
        s"{$name}.{$rest}"
      case _ => throw new ParseException(s"Unknown PROC SQL CTAS table: ${tableName}", 0)
    }

  private def createTableAs = {
    queries
      .filter(_.isInstanceOf[CreateTableAs])
      .map(_.asInstanceOf[CreateTableAs])
      .headOption
  }

  private def tableDepth(t: SQL.Table, deps: mutable.Map[String,Boolean]): Unit = t match {
    case Query(clauses) => clauses.foreach {
      case SQL.From(tables) =>
        tables.foreach { table =>
          tableDepth(table, deps)
        }
      case SQL.Join(_, right, _) =>
        tableDepth(right, deps)
      case _ => // noop
    }
    case SQL.QueryUnion(left, _, right) =>
      tableDepth(left, deps)
      tableDepth(right, deps)
    case SQL.Pathname(path) =>
      deps(path) = true
    case SQL.SimpleName(name, opts) =>
      deps(s"work.$name") = true
    case SQL.TwolevelName(libref, name, opts) =>
      deps(s"$libref.$name") = true
    case SQL.TableVariable(Variable(name), opts) =>
       deps(s"{$name}") = true
    case SQL.TableInterpolatedVariable(Variable(name), rest, opts) =>
      deps(s"{$name}.$rest") = true
    case SQL.TwoLevelTableInterpolatedVariable(Variable(name), Variable(rest), opts) =>
      deps(s"{$name}.{$rest}") = true
    case SQL.AliasedTable(table, _) =>
      tableDepth(table, deps)
    case _ => throw new ParseException(s"Unknown SQL TABLE: $t", 0)
  }

  /** What tables or views this step depends on */
  override def depends: Seq[String] = {
    val deps = mutable.Map[String,Boolean]()
    queries.foreach {
      case table: SQL.Table =>
        tableDepth(table, deps)
      case CreateTableAs(_, expr) =>
        tableDepth(expr, deps)
      case _ => // noop
    }
    deps.keySet.toSeq
  }

  override def generate(cell: Code): String = {
    queries.map {
      case ctas: CreateTableAs =>
        val ds = Dataset(ctasTableName(ctas.name))
        s"(spark.sql(f'''\n" +
          transpileTable(ctas.expr, cell) +
          "\n''')\n" +
          ds.generateOut(cell) + ")"
      case table: SQL.Table =>
        val intoVars = table match {
          case Query(clauses) =>
            clauses flatMap {
              case SQL.Into(seq) =>
                seq map(_.value)
              case _ => Seq()
            }
          case _ => Seq()
        }
        s"result = (spark.sql(f'''\n" +
          transpileTable(table, cell) +
          "\n''').first())\n" + intoVars
          .map(iv => s"$iv = result['$iv']")
          .mkString("\n")
      case iv: Insert =>
        /*
        Note: spark-3.1.0 DBR-8.0 introduced column list support in INSERT statements. The code generated will
        require DBR-8.0 to run.

        https://issues.apache.org/jira/browse/SPARK-32976
        */
        s"(spark.sql(f'''\n" +
          cell.indented(Seq("INSERT INTO " + ctasTableName(iv.name) +
            iv.cols.map(c => " (" + c.map(sqlExpr(_, cell)).mkString(", ") + ")").getOrElse(""),
            "VALUES\n" + cell.indentedComma(iv.values.map(" (" + _.map(sqlExpr(_, cell)).mkString(", ") + ")")) + "\n'''))"))
      case iq: InsertQuery =>
        s"(spark.sql(f'''\n" +
          cell.indented(Seq("INSERT INTO " + ctasTableName(iq.name) +
            iq.cols.map(c => " (" + c.map(sqlExpr(_, cell)).mkString(", ") + ")").getOrElse(""))) + "\n" +
          cell.wrapIndent(transpileTable(iq.expr, cell)) + "\n'''))"
      case update: SQL.Update =>
        val clauses = if (update.where.isDefined)
          Seq(update.set, update.where.get)
        else
          Seq(update.set)

        s"spark.sql(f'''\n" +
          cell.indented(Seq("UPDATE " + transpileTable(update.table, cell))) + "\n" +
          transpileClauses(cell, clauses) +
          "\n''')\n"
      case unknown: UnknownExpr =>
        s"# UNKNOWN PROC SQL ${unknown.name}"
      case sqlExpr: SqlExpr =>
        throw new ParseException(s"Unknown SQL expr: $sqlExpr", 0)
    } .mkString("\n")
  }

  def sqlExpr(expr: Expr, cell: Code): String = {
    expr match {
      case SQL.Asterisk(table) =>
        if (table == null) "*" else s"$table.*"
      case SQL.Column(name) =>
        escapeColumn(name)
      case SQL.Alias(expr2, alias) =>
        cell wrapIndent {
          s"(${sqlExpr(expr2, cell)}) AS ${escapeColumn(alias)}"
        }
      case SQL.TableColumn(table, n) =>
        s"$table.${escapeColumn(n)}"
      case SQL.AliasModifiers(SQL.Alias(expr2, alias), modifiers) =>
        // TODO: make modifiers working...
        cell wrapIndent {
          s"(${sqlExpr(expr2, cell)}) AS ${escapeColumn(alias)}"
        }
      case SQL.ExprModifiers(expr2, modifiers) =>
        // TODO: make modifiers working...
        sqlExpr(expr2, cell)
      case SQL.Case(operand, whens, _else) =>
        "CASE" +
          operand.map(" " + sqlExpr(_, cell) + "\n").getOrElse("") +
          cell.indented(whens.map { when =>
            s"WHEN ${sqlExpr(when.when, cell)} THEN ${sqlExpr(when._then, cell)}"
          }) + "\n" +
          _else.map(e => s"${cell.start}ELSE ${sqlExpr(e, cell)}").getOrElse("") +
          "END"
      case table: SQL.Table =>
        transpileTable(table, cell)
      case Call(name, args) =>
        name + "(" + args.map(e => sqlExpr(e, cell)).mkString(", ") + ")"
      case Syntax.Binary(left, symbol, right) =>
        s"${sqlExpr(left, cell)} ${symbol.toString} ${sqlExpr(right, cell)}"
      case Syntax.Unary(symbol, right) =>
        s"${symbol.toString} ${sqlExpr(right, cell)}"
      case Syntax.Identifier(name) =>
        name
      case constant: Syntax.Constant =>
        constant.sql(cell.context)
      case assign: SQL.Assign =>
        Seq(sqlExpr(assign.column, cell), sqlExpr(assign.expr, cell)).mkString(" = ")
      case variable: Syntax.Variable =>
        variable.sql(cell.context)
      case s: Any =>
        s"-- $s\n"
    }
  }

  private def escapeColumn(alias: String) = {
    if (alias.contains(' ')) s"`$alias`" else alias
  }

  def transpileTable(tableDef: SQL.Table, cell: Code): String = {
    tableDef match {
      case Query(clauses) => transpileClauses(cell, clauses)
      case SQL.QueryUnion(left, how, right) =>
        "(" + transpileTable(left, cell) +
          // TODO: make it proper later
          s") ${how.operator.toUpperCase} (\n" +
          transpileTable(right, cell) + ")"
      case SQL.AliasedTable(table, alias) =>
        s"${transpileTable(table, cell)} AS $alias"
      case SQL.SimpleName(name, opts) =>
        name
      case SQL.TwolevelName(libref, name, opts) =>
        s"$libref.$name"
      case SQL.TwoLevelTableInterpolatedVariable(Variable(name), Variable(rest), opts) =>
        s"{$name}.{$rest}"
      case SQL.Pathname(path) =>
        s"csv.`$path`"
      case TableInterpolatedVariable(Variable(name), rest, opts) =>
        // TODO: mark code as statement containing vars,
        //  so that format string is used
        s"{$name}$rest"
      case TableVariable(Variable(name), opts) =>
        s"{$name}"
    }
  }

  private def transpileClauses(cell: Code, clauses: Seq[SQL.Clause]) = {
    cell.indented(clauses map {
      case SQL.Select(items) =>
        val selectedItems = if (clauses.exists(_.isInstanceOf[SQL.Into])) {
          val intoVars = clauses.flatMap {
            case SQL.Into(vars) =>
              // TODO: this skips modifier arg
              vars.map(_.value)
            case _ => Seq()
          }.zipWithIndex.map {
            case (a, b) => b -> a
          }.toMap
          items.zipWithIndex.map {
            case (sasExpr, i) => sasExpr match {
              case SQL.Alias(a, b) =>
                SQL.Alias(a, intoVars(i))
              case nonAlias: Expr =>
                SQL.Alias(nonAlias, intoVars(i))
            }
          }
        } else items
        "SELECT\n" + cell.indentedComma(selectedItems.map(i => sqlExpr(i, cell)))
      case SQL.SelectDistinct(items) =>
        "SELECT DISTINCT\n" + cell.indentedComma(items.map(i => sqlExpr(i, cell)))
      case SQL.From(tables) =>
        s"FROM ${tables.map(t => transpileTable(t, cell)).mkString(", ")}"
      case SQL.Join(how, table, expr) =>
        // TODO: fix it later...
        val hows = how.map(_.getClass.getSimpleName.toUpperCase).mkString(" ")
        s"$hows JOIN ${transpileTable(table, cell)}" +
          expr.map(e => s" ON ${sqlExpr(e, cell)}").getOrElse("")
      case SQL.Where(expr) =>
        s"WHERE ${sqlExpr(expr, cell)}"
      case SQL.Having(expr) =>
        s"HAVING ${sqlExpr(expr, cell)}"
      case SQL.GroupBy(exprs) =>
        s"GROUP BY ${exprs.map(e => sqlExpr(e, cell)).mkString(", ")}"
      case SQL.OrderBy(items) =>
        s"ORDER BY ${items.map(o => sqlExpr(o.column, cell) + s" ${o.direction}").mkString(", ")}"
      case _: SQL.Into =>
        "" // noop, as it's handled in SELECT. perhaps introduce an optimizer
      case SQL.SetClause(items) =>
        s"SET ${items.map(a => sqlExpr(a, cell)).mkString(", ")}"
    })
  }
}

// https://v8doc.sas.com/sashtml/proc/z11stmt.htm
object ProcSqlParser extends Common[ProcSql] {
  import fastparse._
  import sasconverter.syntax.SQL._
  import syntax.Implicits._
  import syntax.Syntax._


  override def parser[_: P]: P[ProcSql] =
    (W("proc") ~ W("sql") ~
      flag(W("noprint")).rep ~ ";" ~
      ((insertSet|insertValues|insertQuery|update|createTable|dql|unknownExpr) ~ ";").rep ~
      W("quit") ~~ ";").map(ProcSql.tupled)
}
