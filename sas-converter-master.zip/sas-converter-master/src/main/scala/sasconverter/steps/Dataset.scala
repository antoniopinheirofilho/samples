package sasconverter.steps

import sasconverter.Code

// TODO: add dot to name of dataset (database)
case class Dataset(name: String, options: Seq[Option] = Seq()) extends Option {
  def interpolatable(value: String): String = if (value.contains("{"))
      s"f'$value'" else s"'$value'"

  override def generate(cell: Code): String =
    cell.start +
      s"(spark.table(${interpolatable(name)})" +
      (if (options.nonEmpty) cell.wrapIndent({
        "\n" + cell.children(options)
      }) else "") + ")"

  def generateOut(cell: Code): String =
    cell.children(options) + cell.wrapIndent {
      name match {
        case "_null_" => ".first()"
        case _ => s".createOrReplaceTempView(${interpolatable(name)})"
      }
    }

  //TODO: Add code block for save as delta table
  def save(cell: Code)(mode:String): String =
    cell.indented(options.map(_.generate(cell)) ++ Seq(
      ".write",
      ".format('delta')",
      s".mode('$mode')",
      s".save(${interpolatable(name)})"
    ))

}