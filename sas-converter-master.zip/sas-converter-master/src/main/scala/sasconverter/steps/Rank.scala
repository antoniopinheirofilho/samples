package sasconverter.steps

import java.text.ParseException

import fastparse.P
import sasconverter.syntax.Syntax.Char
import sasconverter.{Code, Context, syntax}

case class Rank(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st) {
  // TODO: implement `groups` using Spark `ntile` function
  override def generate(cell: Code): String = {
    val partitionCols = statement[By].map(v => cell.stringList(v.vars.map(_._2))).getOrElse("")
    if (flag("desc")) cell.local("desc") = true
    val rankFunction = keyValue("ties") match {
      case Some(Char("dense")) => "F.dense_rank"
      case None => "F.rank"
      case Some(value) => throw new ParseException(s"Unknown RANK TIES: $value", 0)
    }
    cell.context.importFunctionsAlias()
    cell.context.importWindow()
    val rankCols = statement[_Var].map(_.generate(cell)).getOrElse("")
    cell.start + "(" +
      data("data").generate(cell) + "\n" +
      cell.indentedOptional(statement[Ranks].map(_.vars.map(rankedColName =>
        s".withColumn('$rankedColName', $rankFunction()\n" + cell.wrapIndent {
          cell.indentedSugar(
            s".over(Window.partitionBy($partitionCols)",
            s".orderBy($rankCols)))")
        }
      ))) + ")"
  }

  /** What table or view this step defines */
  override def produces: String = data("data").name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq(produces)
}

case class _Var(vars: Seq[String]) extends Statement {
  override def generate(cell: Code): String = {
    val desc = if (cell.local.contains("desc")) ".desc()" else ""
    cell.context.importFunctionsAlias()
    vars.map(v => s"F.col('$v')$desc").mkString(", ")
  }
}

case class Ranks(vars: Seq[String]) extends Passthrough

object RankParser extends Common[Rank] {
  import syntax.Implicits._
  import syntax.Syntax._

  def _var[_: P]: P[_Var] = (W("var") ~ name.rep ~ ";").map(_Var)

  def ranks[_: P]: P[Ranks] = (W("ranks") ~ token.rep ~ ";").map(Ranks)

  override def parser[_: P]: P[Rank] = (
    W("proc") ~ W("rank") ~
      (keyDataset(W("data")) |
      (W("ties").! ~ "=" ~ (W("high")|W("low")|W("mean")|W("dense")).!.map(Char)).map(KeyValue.tupled) |
        (W("normal").! ~ "=" ~ (W("blom")|W("tukey")|W("vw")).!.map(Char)).map(KeyValue.tupled) |
        (W("groups").! ~ "=" ~ digit.!.map(Char)).map(KeyValue.tupled) |
        flag("fraction") | flag("nplus1") | flag("percent") | flag("savage") |
        W("descending").!.map(_ => Flag("desc"))).rep ~ ";" ~
      (by | _var | ranks | unknownStatement/*| output*/).rep()
    ).map(Rank.tupled)
}