package sasconverter.steps

import sasconverter.{Code, Context, syntax}

case class ProcImport(opts: Seq[Option]) extends Proc(opts) with Passthrough {
  /** What table or view this step defines */
  override def produces: String = data("out").name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()
}

// https://v8doc.sas.com/sashtml/proc/z0308090.htm
object ProcImportParser extends Common[ProcImport] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

  override def parser[_: P]: P[ProcImport] =
    (W("proc") ~ W("import") ~
      (keyDataset(W("out")) | keyValue | flag(W("replace"))).rep ~ ";" ~
      keyValue.rep(0, sep = ";") ~
      run).map(_ => ProcImport(Seq()))
}
