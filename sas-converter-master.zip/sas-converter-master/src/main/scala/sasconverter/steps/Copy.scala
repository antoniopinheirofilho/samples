package sasconverter.steps

import java.text.ParseException

import sasconverter.{syntax, Code, Context}
import sasconverter.syntax.Syntax.Char

case class ProcCopy(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st) {

  // TODO: need to come up with better way of representing this as COPY can produce multiple outputs
  override def produces: String = depends.mkString(" ")

  override def depends: Seq[String] = statement[Select]
    .map(_.tables.vars).getOrElse(Seq()).map(_.name)

  override def generate(cell: Code): String = {

    // IN and OUT are mandatory
    val inLib = keyValue("in") match {
      case Some(Char(v)) => v
      case None => throw new ParseException(s"IN argument is required", 0)
    }
    val outLib = keyValue("out") match {
      case Some(Char(v)) => v
      case None => throw new ParseException(s"OUT argument is required", 0)
    }

    def getSingle(table: String): String = {
      val in = Dataset(s"${inLib}.${table}")
      val out = Dataset(s"${outLib}.${table}")  // Should this be only a table name?
      s"${in.generate(cell)}" + "\n" +
        cell.indented(Seq(out.generateOut(cell)))
    }

    cell.start + depends.map(getSingle).mkString("\n")
  }
}

// https://documentation.sas.com/doc/en/vdmmlcdc/8.1/proc/p04y85z9f13uaan10s1k40ptx6gs.htm
// https://v8doc.sas.com/sashtml/proc/z0085782.htm
object ProcCopyParser extends Common[ProcCopy] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

    override def parser[_: P]: P[ProcCopy] = {

      // For now only SELECT is implemented and it is mandatory, no EXCLUDE implementation
      (W("proc") ~ W("copy") ~ copyOptions.rep ~ ";" ~
        select.rep(exactly=1) ~
        run).map(ProcCopy.tupled)
    }

  def select[_: P] = {
    (W("select") ~ varNameList ~ ";").map(Select)
  }
  def copyOptions[_: P] = {
    keyValue("in") |
      keyValue("out") |
      flag(W("clone")) |
      flag(W("noclone")) |
      flag(W("move")) |
      keyValue("memtype") |
      (W("override").! ~ "=" ~ "(" ~ CharsWhile(!")".contains(_)).! ~ ")").map(KeyString.tupled)
  }
}
