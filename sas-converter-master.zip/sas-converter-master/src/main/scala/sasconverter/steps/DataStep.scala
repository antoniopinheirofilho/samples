package sasconverter.steps


import java.text.ParseException

import sasconverter.syntax.Syntax._
import sasconverter.{Code, Context, Generating, syntax}

import scala.annotation.tailrec

case class DataStep(ds: Dataset, statements: Seq[Statement]) extends Step with Generating {
  /** What table or view this step defines */
  override def produces: String = ds.name

  override def depends: Seq[String] = statements.flatMap {
    case s: Set => s.ds
  } map (_.name)

  override def generate(cell: Code): String =
    cell.start + (if (ds.name == "_null_") "result = "  else "")+ "(" +
      walk(statements.filter(_.isInstanceOf[Set]) ++
        statements.filter(x => (!x.isInstanceOf[Set] & !x.isInstanceOf[CallStatement])), cell) + "\n" +
      cell.wrapIndent(ds.generateOut(cell)) +
      ")" + "\n" +
      statements.filter(_.isInstanceOf[CallStatement]).map(_.generate(cell)).mkString("\n")

  def kv(opts: Seq[Option], key: String) = opts
    .filter(_.isInstanceOf[KeyValue])
    .map(_.asInstanceOf[KeyValue])
    .find(_.key == key)
    .map(_.value)

  private def walk(statements: Seq[Statement], cell: Code): String =
    (statements.headOption match {
      case Some(Set(datasets, options)) => datasets map { ds =>
        cell.local.get("dataset") match {
          case None =>
            cell.local("dataset") = ds.name
            ds.generate(cell)
          case _ => kv(options, "key") match {
            case Some(Char(key)) =>
              s"${cell.start}.join(${ds.generate(cell)}, ['$key'])\n"
            case None =>
              s"${cell.start}.join(${ds.generate(cell)})\n"
            case Some(value) =>
              throw new ParseException(s"Unknown SET dataset type: $value", 0)
          }
        }
      } mkString("\n" + cell.start)
      case Some(Attrib(attribs)) =>
        // attribute definitions are sequential and
        // therefore to be indented separately
        "\n" + cell.indented(attribs.map(_.generate(cell)))
      case Some(simple) =>
        "\n" + cell.indented(Seq(simple.generate(cell)))
      case None => ""
    }) + (if (statements.nonEmpty) walk(statements.tail, cell) else "")

}

case class Set(ds: Seq[Dataset], options: Seq[KeyString]) extends Statement {
  override def generate(cell: Code): String =
    "# TODO: proper rendering of set statement"
}

case class IfDelete(expr: Expr) extends Statement {
  override def generate(cell: Code): String = Where(expr).generate(cell)
}

case class If(expr: Expr) extends Statement {
  override def generate(cell: Code): String = Where(expr).generate(cell)
}

case class CallStatement(opts: Call ) extends Statement {
  override def generate(cell: Code): String = opts.name match {
    case "symput" => opts.args match {
      case Seq(Char(v),Identifier(c)) => cell.wrapIndent(s"${v.toLowerCase} = result['${c}']")
      case _ => ""
    }
    case _ => "" //TODO: enhance as when new call statement is incorporated
  }
}

case class FormatUsage(col: Identifier,fmtName: Informat) extends Statement {
  override def generate(cell: Code): String =
    s""".withColumn('${col.name}', ${fmtName.name.get}_format('${col.name}'))"""
}

case class Merge(datasets: Seq[Dataset],st: Seq[Statement]) extends Proc(datasets,st) with Statement {
  override def generate(cell:Code): String = {
    val cols = statement[By].map(v => cell.stringList(v.vars.map(_._2)))
    val (l,r) = datasets.splitAt(1)
    cell.start + l(0).generate(cell) +
    r.map(ds => {
      cols match {
        case Some(col) => s".join([${col}], 'inner'," + ds.generate(cell)
        case None => s".join(inner," + ds.generate(cell)
      }
    }).mkString("") + ")"
  }

  /** What table or view this step defines */
  override def produces: String = data("data").name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq(produces)
}

case class Assign(column: String, expr: Expr) extends Statement {
  override def generate(cell: Code): String = {
    cell.context.importFunctionsAlias()
    s".withColumn('$column', F.expr('${expr.sql(cell.context)}'))"
  }
}

case class Label(v: String) extends Passthrough

case class Length(v: Int) extends Passthrough

case class KVInformat(key: String, informat: Informat) extends Passthrough

case class AttribDef(key: String,value: Seq[Statement]) extends Statement {
  //TODO: To be enhancement as part of format enhancement to handle various dateformats As Part of Issue # 30
  override def generate(cell: Code): String = (value
      .filter(_.isInstanceOf[Label])
      .map(_.asInstanceOf[Label])
      .headOption match {
        case Some(Label(v)) => s".withColumnRenamed('${v}', F.col('${key}'))"
        case None => ""
        case _ => ""
  })
}

case class Attrib (opts: Seq[AttribDef]) extends Statement {
  override def generate(cell: Code): String = cell.children(opts)
}
private[sasconverter] object DataStepParser extends Common[DataStep] {
  import syntax.Implicits._
  import fastparse._
  import syntax.Syntax._


  def set[_: P] = P(W("set") ~ dataset.repSpace(1) ~ (
    (W("key") | W("open") | W("curobs") | W("end") | W("indsname")
      | W("keyreset") | W("nobs") | W("point")
      | W("unique")).! ~ "=" ~ name).map(KeyString.tupled).rep ~ ";").map(Set.tupled)

  def ifDelete[_:P] = P(W("if") ~ expr ~ "then" ~ "delete" ~ ";").map(IfDelete)
  def if_[_: P]: P[If] = P(W("if") ~ expr ~  ";").map(If)

  def merge[_: P] = P(W("merge") ~  dataset.rep ~ ";" ~ by.rep.? ).log.map{
    case (ds, st) => Merge(ds, st.getOrElse(Seq()))
  }

  def assign[_: P] = P(name ~ "=" ~ expr ~ ";").map(Assign.tupled)


  def format[_: P] = (W("format") ~ identifier ~ informat ~ ";").log.map(FormatUsage.tupled)

  def kvInformat [_: P,W](k: => P[W]):P[KVInformat] =  (k.! ~ "=" ~ informat).log.map(KVInformat.tupled)


  def length[_: P] = (W("length") ~ "=" ~ "$".? ~ digit.repX.!.map(_.toInt)).log.map(Length)

  def labelDoubleQuote[_: P] = (W("label") ~ "=" ~ "\"" ~~ CharsWhile(!"\"".contains(_)).! ~ "\"").log.map(Label)

  def doubleQuoteAsLabel[_: P] = doubleQuoted.log.map(Label)

  // Cannot use char because label might be defined as label ='hello world'
  def labelSingleQuote[_: P] = (W("label") ~ "=" ~ "\'" ~~ CharsWhile(!"\'".contains(_)).! ~ "\'").log.map(Label)

  def label[_: P] = labelSingleQuote | labelDoubleQuote | doubleQuoteAsLabel

  def attribDef[_:P] = (
    token ~ (label | length | kvInformat(W("format")) | kvInformat(W("informat"))).rep
    ).log.map(AttribDef.tupled)

  def attrib[_:P] = P(W("attrib") ~ attribDef.rep ~ ";").log.map(Attrib)

  def call_[_:P]: P[CallStatement] = P(W("call") ~ call ~ ";").log.map(CallStatement)

  def statements[_:P]: P[Statement] = set | format | assign | if_ | attrib | whereProc | renameProc | dropProc | keepProc | call_ | merge | by | unknownStatement

  override def parser[_: P]: P[DataStep] = P(W("data") ~ dataset ~ ";" ~ statements.rep.? ~ run).log.map {
    case (ds, st) => DataStep(ds, st.getOrElse(Seq()))
  }
}