package sasconverter.steps

import sasconverter.{Code, Context, syntax}

case class Sort(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st) {
  private def in: Dataset = data("data")
  private def out: Dataset = datasetOption("out").getOrElse(in)

  override def generate(cell: Code): String =
    cell.start + "(" +
      in.generate(cell) + "\n" +
      cell.indented(Seq(
        s".orderBy(${statement[By].get.generate(cell)})",
        statement[Where] match {
          case Some(x) => x.generate(cell)
          case None => ""
        },
        out.generateOut(cell)
      )) + ")"

  /** What table or view this step defines */
  override def produces: String = out.name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq(in.name)
}

object SortParser extends Common[Sort] {
  import syntax.Implicits._
  import syntax.Syntax._
  import fastparse._

  override def parser[_: P]: P[Sort] = (
    W("proc") ~ W("sort") ~
      sortOptions.rep ~ ";" ~
      (by | key | whereProc | unknownStatement).rep()
      ~ run
    ).log.map(Sort.tupled)

  /** Using same implementation of Key based on By as both can be used similarly for Sort*/
  //TODO: Need to implement Range of variables
  //https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n12jw1r2n7auqqn1urrh8jwezk00.htm&locale=en
  def key[_: P]:P[By] =  (W("key") ~ (W("DESCENDING").!.?.map(_.isDefined) ~ token).rep
    ~ W("NOTSORTED").!.?.map(_.isDefined) ~ ";").map(By.tupled)

  def sortOptions[_: P] = {
    keyDataset(W("data") | W("out")) | flag(W("nodupkey")) |
      flag(W("descending"))
  }
}
