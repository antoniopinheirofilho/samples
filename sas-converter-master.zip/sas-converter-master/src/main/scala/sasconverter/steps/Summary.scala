package sasconverter.steps

import sasconverter.{Code, Context, syntax}
import syntax.Syntax._

case class ProcSummary(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st) {
  def in: Dataset = data("data")

  def out(cell:Code): String = statement[Output].headOption.map(_.generate(cell)).getOrElse("")

  override def generate(cell: Code): String = {
    cell.context.importFunctionsAlias()
    cell.start + "(" + in.generate(cell) + "\n" +
      cell.indented(Seq(statement[_Class].map(_.generate(cell)).getOrElse(""),
        statement[Var].map(_.generate(cell)).getOrElse(""),
        statement[Output].map(_.generate(cell)).getOrElse(""))) + ")"
  }

  /** What table or view this step defines */
  override def produces: String = data("output").name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = ???
}

case class _Class(vars: Seq[String], opts: Seq[Option]) extends Statement {
  override def generate(cell: Code): String = {
    cell.context.importFunctionsAlias()
    s".groupby(" + vars
      .map(v =>  s"""F.col('${v}')""")
      .mkString(", ") + ")"
  }
}

case class Freq(variable: String) extends Statement {
  override def generate(cell: Code): String = ???
}

case class ID(variables: Seq[String]) extends Statement {
  override def generate(cell: Code): String = ???
}

case class Output(dataset: KeyDataset, g: Seq[Statement], f: Seq[Flag]) extends Statement {
  override def generate(cell: Code): String = dataset.dataset.generateOut(cell)
}

case class Var(value: Seq[String]) extends Statement {
  override def generate(cell: Code): String = ".agg(" + value.map(col => s"""F.count(F.col('${col}')).alias(f'${col}_count'),
  F.mean(F.col('${col}')).alias(f'${col}_mean'),
  F.stddev(F.col('${col}')).alias(f'${col}_std'),
  F.min(F.col('${col}')).alias(f'${col}_min'),
  F.max(F.col('${col}')).alias(f'${col}_max'),
  F.expr(f'''percentile(F.col('${col}'), array(0.25))''')[0].alias(f'${col}_25pct'),
  F.expr(f'''percentile(F.col('${col}'), array(0.5))''')[0].alias(f'${col}_50pct'),
  F.expr(f'''percentile(F.col('${col}'), array(0.75))''')[0].alias(f'${col}_75pct')""".stripMargin).mkString(",") + ")"
}


sealed trait OutputGroup extends Passthrough

case class OuputStatistic(stat: String, vars: Seq[String], names: Seq[String]) extends OutputGroup

case class IdGroup(vars: Seq[(String,Seq[String])], flag: String,
                   out: Integer, idVars: Seq[String], names: Seq[String]) extends OutputGroup

case class Maxid(minOrMax: String, v: Seq[(String, Seq[String])], n: Seq[String]) extends OutputGroup

// https://documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.5&docsetId=proc&docsetTarget=n1qnc9bddfvhzqn105kqitnf29cp.htm&locale=en
object ProcSummaryParser extends Common[ProcSummary] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

  // CLASS variable(s) </options>;
  private def _class[_: P] = (W("class") ~ tokenVar.rep ~ ("/" ~ (
    (W("order").! ~ "=" ~ (W("data")|W("formatted")|W("freq")|W("unformatted")).!.map(Char)).map(KeyValue.tupled) |
      (W("ascending")|W("ascend")).!.map(_ => Flag("asc")) |
      (W("descending")|W("descend")).!.map(_ => Flag("desc")) |
      flag(W("exclusive") | W("groupinternal") | W("missing") | W("mlf")|W("preloadfmt"))
    ).rep).?.map(_.getOrElse(Seq()))).log.map(_Class.tupled)
  private def freq[_: P] = (W("freq") ~ name).map(Freq)
  private def id[_: P] = (W("id") ~ name.rep).map(ID)
  private def stat[_: P] = StringInIgnoreCase("CLM", "NMISS", "CSS", "RANGE", "CV", "SKEWNESS", "SKEW",
    "KURTOSIS", "KURT", "STDDEV", "STD", "LCLM", "STDERR", "MAX", "SUM", "MEAN", "SUMWGT", "MIN", "UCLM",
    "MODE", "USS", "N", "VAR", "MEDIAN", "P50", "Q3", "P75", "P1", "P90", "P5", "P95", "P10", "P99", "P20",
    "P30", "P40", "P60", "P70", "P80", "Q1", "P25", "QRANGE", "PROBT", "PRT", "T").!
  private def outputStat[_: P] =
    (stat ~ "(" ~ name.rep ~ ")" ~ "=" ~ name.rep ).map(OuputStatistic.tupled)
  private def idgroup[_: P] = P(W("idgroup") ~
    ((W("min") | W("max")).! ~ name.rep).rep ~
    (W("missing")|W("obs")|W("last")).! ~
    W("out") ~ "[" ~ integer ~ "]" ~ "(" ~ name.rep ~ ")" ~ "=" ~ name.rep).map(IdGroup.tupled)
  private def maxid[_:P] = ((W("maxid")|W("minid")).! ~
    (name ~ ("(" ~ name.rep ~ ")").?.map(_.getOrElse(Seq()))).rep ~
    "=" ~ name.rep ).map(Maxid.tupled)
  private def output[_: P] = (W("output") ~
    keyDataset(W("out")) ~
    (outputStat | idgroup | maxid | unknownStatement).rep.?.map(_.getOrElse(Seq())) ~
    ("/" ~ (W("autolabel")|W("autoname")|W("keeplen")|
      W("levels")|W("noinherit")|W("ways")).?
      .!.map(Flag).rep).?.map(_.getOrElse(Seq()))).map(Output.tupled)

    private def _var[_:P] = (W("var") ~ tokenVar.rep).map(Var)

  override def parser[_: P]: P[ProcSummary] =
    (W("proc") ~ (W("summary") | W("means")) ~
      (keyDataset(W("data")) | keyDataset(W("classdata")) |
        keyValue |
        flag(W("nothreads") | W("notrap") | W("threads") | W("nothreads") |
          W("completetypes") | W("exclusive") | W("missing") | W("nonobs") |
          W("noprint") | W("printalltypes") | W("printidvars") | W("stackodsoutput") |
          W("chartype") | W("descendtypes") | W("idmin") | W("nway") | W("EXCLNPWGT")
        )).rep ~ ";" ~
      (by | _class | _var | freq | id | where | output | unknownStatement).rep(0, sep = ";") ~ ";".? ~
      run
      ).log.map(ProcSummary.tupled)
}