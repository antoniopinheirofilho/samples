package sasconverter.steps

import fastparse.{CharsWhile, P}
import sasconverter.{Code, Context, syntax}

case class ProcS3(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st) with Passthrough {
  /** What table or view this step defines */
  override def produces: String = ""

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()
}

case class S3PutStatement(localPath: String, s3Path: String) extends Passthrough
case class S3GetStatement(s3Path: String, localPath: String) extends Passthrough

/**
 * Dummy class for S3 Statements that are currently not supported.
 */
case class S3DummyStatement() extends Passthrough

object ProcS3Parser extends Common[ProcS3] {
  import syntax.Implicits._
  import syntax.Syntax._

  override def parser[_: P]: P[ProcS3] = (
    W("proc") ~ W("s3") ~ (s3Option).rep ~ ";"
      ~ ((s3Statement.rep(0, sep = ";")) ~ ";").? ~ run
    ).map({
    case (ops, stmts) => ProcS3(ops, stmts.getOrElse(Seq()))
  })

  def s3Option[_: P]: P[KeyString] =
    (token ~ "=" ~ "\"" ~~ CharsWhile(!"\"".contains(_)).! ~~ "\"")
      .map(s => KeyString(s._1, s._2))

  def s3Statement[_: P]: P[Statement] = s3PutStatement | s3GetStatement | s3DummyStatement

  //TODO: Add optional ENCKEY parameter
  def s3PutStatement[_: P]: P[S3PutStatement] = (W("put") ~ "\"" ~~ filePath.! ~~ "\"" ~ "\"" ~~ filePath.! ~~ "\"")
    .map(S3PutStatement.tupled)

  //TODO: Add optional ENCKEY parameter
  def s3GetStatement[_: P]: P[S3GetStatement] = (W("get") ~ "\"" ~~ filePath.! ~~ "\"" ~ "\"" ~~ filePath.! ~~ "\"")
    .map(S3GetStatement.tupled)

  def s3DummyStatement[_: P]: P[S3DummyStatement] = (
    (W("bucket") | W("create") | W("delete") | W("destroy") | W("enckey") | W("getaccel")
      | W("getdir") | W("info") | W("list") | W("mkdir") | W("putdir") | W("rmdir"))
      ~ CharsWhile(!";".contains(_))
    ).map(_ => S3DummyStatement())

  private def filePath[_: P]: P[String] = P( (letter|digit|"_"|"/"|":").rep(1) ).!


}
