package sasconverter.steps

import sasconverter.syntax.Syntax.{token, Constant, VariableList, W}
import sasconverter.syntax.Implicits._
import fastparse._
import sasconverter.{Code, Generating, syntax}

import scala.{Option => Opt}
import reflect.runtime.{universe => ru}

/**
 * Steps may have zero or more options and zero or more statements.
 * Statement may have zero or more options.
 */
trait Step extends Generating {
  /** What table or view this step defines */
  def produces: String
  /** What tables or views this step depends on */
  def depends: Seq[String]

  def hasFlag(opts: Seq[Option],flag:String) = opts.filter(_.isInstanceOf[Flag])
    .map(_.asInstanceOf[Flag])
    .exists(_.name.equals(flag))

  def data(opts: Seq[Option],name: String) : Opt[Dataset] = opts
    .filter(_.isInstanceOf[KeyDataset])
    .map(_.asInstanceOf[KeyDataset])
    .find(_.key == name)
    .map(_.dataset)
}

object StepParser {
  def unknownProc[_:P]: P[UnknownProc] = (W("proc") ~
    token ~ (!W("run") ~ AnyChar).rep ~
    W("run") ~ ";").map(UnknownProc).log

  def parser[_:P]: P[Seq[Step]] = (
    DataStepParser.parser |
    ExportParser.parser |
    FormatParser.parser |
    ProcImportParser.parser |
    ProcAppendParser.parser |
    RankParser.parser |
    ProcS3Parser.parser |
    SortParser.parser |
    ProcSqlParser.parser |
    ProcSummaryParser.parser |
    Other.parser |
    unknownProc
  ).rep ~ End
}

/**
 * Catch-all unknown procedures to continue parsing
 *
 * @param name name of the procedure
 */
case class UnknownProc(name: String) extends Step {
  /** What table or view this step defines */
  override def produces: String = null

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()

  override def generate(cell: Code): String = s"# UNKNOWN PROC $name"
}

abstract class Proc(opts: Seq[Option], st: Seq[Statement] = Seq()) extends Step {
  def datasetOption(name: String): Opt[Dataset] =
    opts
      .filter(_.isInstanceOf[KeyDataset])
      .map(_.asInstanceOf[KeyDataset])
      .find(_.key == name)
      .map(_.dataset)

  def data(name: String): Dataset = datasetOption(name).get

  def statement[T: ru.TypeTag]: Opt[T] =
    st.filter(_.getClass.getName == ru.typeOf[T].typeSymbol.fullName)
      .map(_.asInstanceOf[T])
      .headOption

  def option[T: ru.TypeTag]: Opt[T] =
    opts
      .filter(_.getClass.getName == ru.typeOf[T].typeSymbol.fullName)
      .map(_.asInstanceOf[T])
      .headOption

  def keyValue(key: String): Opt[Constant] =
    opts
    .filter(_.isInstanceOf[KeyValue])
    .map(_.asInstanceOf[KeyValue])
    .filter(_.key == key)
    .map(_.value)
    .headOption

  def flag(name: String): Boolean =
    opts
      .filter(_.isInstanceOf[Flag])
      .map(_.asInstanceOf[Flag])
      .exists(_.name == name)
}

trait Option extends Generating

/**
 * Statement may have zero or more options.
 */
trait Statement extends Generating

/**
 * Option and Statement without that has no generator
 */
trait Passthrough extends Option with Statement {
  override def generate(cell: Code): String = ""
}

/**
 * Statement that has no generator
 */
trait PassthroughStatement extends Statement {
  override def generate(cell: Code): String = ""
}

case class KeyValue(key: String, value: Constant) extends Passthrough
case class KeyString(key: String, value: String) extends Passthrough
case class KeyDataset(key: String, dataset: Dataset) extends Passthrough
case class Flag(name: String) extends Passthrough
case class Select(tables: VariableList) extends PassthroughStatement


