package sasconverter.steps

import java.text.ParseException

import fastparse._
import sasconverter.syntax.Syntax._
import sasconverter.{Code, Context, syntax}

trait Common[E] {
  import syntax.Implicits._
  import syntax.Syntax._

  def parser[_: P]: P[E]

  def run[_: P] = P(W("run") ~ ";")

  def compress[_:P]: P[Compress] = P(W("compress") ~/ "=" ~ (W("yes")|W("no")).!.map(Char)).map(Compress)

  def keepProc[_: P]: P[Keep] = P(W("keep") ~/ "=" ~ variableList ~ ";").map(Keep)

  def keep[_: P]: P[Keep] = P(W("keep") ~/ "=" ~ variableList).map(Keep)

  def dropProc[_: P]: P[Drop] = P(W("drop") ~/ variableList ~ ";").map(Drop)

  def drop[_: P]: P[Drop] = P(W("drop") ~/ "=" ~ variableList).map(Drop)

  def renameProc[_:P]: P[Rename] = P(W("rename") ~ "=" ~ (identifier ~ "=" ~ identifier).!.repSpace(1) ~ ";").map {
    case (m: Seq[String]) => Rename(m.map(_.split("=")).map(x => x(0) -> x(1)).toMap)
  }

  // TODO: fix whitespace in rename option - somehting is wrong with `key = value` pairs with spaces before =
  def rename[_: P]: P[Rename] = P(W("rename") ~ "=" ~ "(" ~
    (identifier ~ "=" ~ identifier).!.repSpace(1) ~ ")") map {
    case (m: Seq[String]) => Rename(m.map(_.split("=")).map(x => x(0) -> x(1)).toMap)
  }

  def in[_: P]: P[In] = P(W("in") ~ "=" ~ identifier.!).map(In)

  def whereProc[_:P]: P[Where] = P(W("where") ~ expr ~ ";").log.map(Where)

  def where[_: P]: P[Where] = P(W("where") ~ "=" ~ "(" ~ expr ~ ")").log.map(Where)

  // BY <DESCENDING> variable-1 <<DESCENDING>variable-2 ...> <NOTSORTED>;
  def by[_: P] = (W("by") ~ (W("DESCENDING").!.?.map(_.isDefined) ~ token).rep
    ~ W("NOTSORTED").!.?.map(_.isDefined) ~ ";").map(By.tupled)


  //TODO: https://github.com/databricks/sas-converter/issues/53 for refactoring as table.
  def dataset[_: P] = P((twoLevelVariableInterpolated|oneLevelVariableInterpolated|oneLevelVariable|twolevelIdentifier|identifier) ~
    ("(" ~ (keep | drop | where | rename | in | compress).repSpace() ~ ")").?).log.map {
    case (n: Identifier, opts) => Dataset(n.name, opts.getOrElse(Seq()))
    case (n: TwoLevelIdentifier, opts) => Dataset(n.libref + "." + n.name, opts.getOrElse(Seq()))
    case (n: OneLevelVariable, opts) => Dataset(n.value.name, opts.getOrElse(Seq()))
    case (n: OneLevelInterpolatedVariable, opts) => Dataset(s"{${n.value.name}}" + "." + n.rest, opts.getOrElse(Seq()))
    case (n: TwoLevelInterpolatedVariable, opts) => Dataset(s"{${n.value.name}}" + "." + s"{${n.rest.name}}", opts.getOrElse(Seq()))
    case (n: TwoLevelInterpolatedVariableSuffix, opts) => Dataset(s"{${n.value.name}}" + "." + s"{${n.rest.value}}${n.rest.rest}", opts.getOrElse(Seq()))
    case any: Any => throw new ParseException(s"Cannot parse dataset: $any", 0)
  }

  def keyDataset[_: P, W](k: => P[W]): P[KeyDataset] = (k.! ~ "=" ~ dataset).map(KeyDataset.tupled)
  def flag[_: P](w: P[_]) = w.!.map(Flag)
  def flags[_: P](w: P[_]) = flag(w).rep.?.map(_.getOrElse(Seq()))

  /** keyValue is a very lazy implementation of primitive key-value pair */
  def keyValue[_: P] = (token ~ "=" ~ (constant|token.map(Char))).map(KeyValue.tupled)

  def keyValue[_: P](key: String, preserveKey: Boolean = false) = (W(key).! ~ "=" ~
    (constant|token.map(Char))).map(kv => KeyValue(if (preserveKey) kv._1 else key, kv._2))

  def unknownStatement[_:P]: P[UnknownStatement] = (token ~ CharsWhile(!";".contains(_)).! ~ ";")
    .map(UnknownStatement.tupled).opaque("unknownStatement").log
}

/**
 * Catch all unknown statements.
 *
 * @param name name of the statement
 * @param text text of the statement
 */
case class UnknownStatement(name: String, text: String) extends Statement {
  override def generate(cell: Code): String = s"# UNKNOWN $name: $text"
}

case class By(vars: Seq[(Boolean, String)], notSorted: Boolean) extends Statement {
  override def generate(cell: Code): String = {
    cell.context.importFunctionsAlias()
    vars
      .map(v => if (v._1) s"""F.col('${v._2}').desc()""" else s"""F.col('${v._2}')""")
      .mkString(", ")
  }
}

case class Compress(value: Char) extends Option {
  override def generate(cell: Code): String = "" //TODO: Implement Compress as part of separate ticket
}

case class Keep(vl: MixedVariablesList) extends Option with Statement{
  override def generate(cell: Code): String =
    (if (!vl.hasPrefixedList) {
      s".select(${cell.stringList(vl.allIdentifierNames)})"
    } else {
      s".transform(lambda df: df.select(*([]" +
        cell.indented(vl.vars map {
          case VariableList(vars) =>
            s"+ [${cell.stringList(vars.map(_.name))}]"
          case VariablePrefixedList(prefix) =>
            s"+ [c for c in df.columns c.startswith('${prefix.name}')]"
        }) +
        ")))"
    })
}

case class Drop(vl: MixedVariablesList) extends Option with Statement{
  override def generate(cell: Code): String =
    cell.stringChildren(vl.vars map {
      case VariableList(vars) =>
        s".drop(${cell.stringList(vars.map(_.name))})"
      case VariablePrefixedList(prefix) =>
        s".transform(lambda df: df.select(*[c for c in df.columns if not c.startswith('${prefix.name}')]))"
    })
}

case class Rename(renames: Map[String, String]) extends Option with Statement{
  override def generate(cell: Code): String =
    cell.stringChildren(renames
      .map(x => s".withColumnRenamed('${x._1}', '${x._2}')"))
}

case class In(in: String) extends Option {
  override def generate(cell: Code): String = {
    cell.context.importFunctionsAlias()
    s".withColumn('${in}',F.lit(1))"
  }
}

case class Where(expr: Expr) extends Option with Statement{
  override def generate(cell: Code): String =
    s""".where("${expr.sql(cell.context)}")"""
}
