package sasconverter.steps

import sasconverter.{Code, Context, syntax}

case class Export(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st)  {
  /** What table or view this step defines */
  override def produces: String = "*"

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq(in.name)

  private def in: Dataset = data("data")

  override def generate(cell: Code): String = {
    val mode = if (flag("replace")) "overwrite" else "append"
    cell.start + "(" +
      in.generate(cell) + "\n" +
      option[Rename].map(rename => cell.wrapIndent {
        cell.start + rename.generate(cell) + "\n"
      }).getOrElse("") +
      datasetOption("outfile")
        .orElse(datasetOption("outtable"))
        .get.save(cell)(mode) +
      ")"
  }
}

object ExportParser extends Common[Export] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

  def label[_: P]: P[Rename] = P(W("label") ~
    (identifier ~ "=" ~ identifier).!.repSpace(1)) map {
    case (m: Seq[String]) => Rename(m.map(_.split("=")).map(x => x(0) -> x(1)).toMap)
  }
//TODO: Flag replace doesn't work need to fix this for now used an alternative.
  override def parser[_: P]: P[Export] = (
    W("proc") ~ W("export") ~
      (
        keyDataset(W("data") | W("outfile") | W("outtable")) |
          (keyValue | (W("replace")).!.map(_ => Flag("replace")) /*flag(W("replace"))*/ | label)
        ).rep ~ ";"
      ~ (keyValue | unknownStatement).rep(0, sep=";")
      ~ (";" | run)
    ).map(Export.tupled)
}
