package sasconverter.steps

import fastparse.{CharsWhile, P}
import sasconverter.syntax.Syntax.{W, letter}
import sasconverter.{Code, Context, syntax}

object Other extends Common[Step] {
  import syntax.Implicits._
  import syntax.Syntax._ // maybe syntax should be a trait?...

  private def libname[_: P] = W("libname") ~ token ~ doubleQuoted ~ ";" ~ run map(Libname.tupled)
  private def filename[_: P] = W("filename") ~ token ~ doubleQuoted ~ ";" ~ run map(Filename.tupled)
  private def options[_: P] = (W("options") ~ CharsWhile(!";".contains(_)) ~ ";" ~ run.?).map(_ => Ignored())

  override def parser[_: P]: P[Step] = libname | filename | options
}

case class Ignored() extends Step with Passthrough {
  /** What table or view this step defines */
  override def produces: String = ""

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()
}

case class Libname(name: String, path: String) extends Step with Passthrough {
  /** What table or view this step defines */
  override def produces: String = ""

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()
}

case class Filename(name: String, path: String) extends Step with Passthrough {
  /** What table or view this step defines */
  override def produces: String = ""

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq()
}