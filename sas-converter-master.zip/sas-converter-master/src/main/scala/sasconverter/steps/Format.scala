package sasconverter.steps

import java.text.ParseException

import sasconverter.syntax.Syntax._
import sasconverter.{Code, syntax}

case class Format(opts: Seq[Option], st: Seq[Statement]) extends Proc(opts, st)  {
  /** What table or view this step defines */
  override def produces: String = ???

  /** What tables or views this step depends on */
  override def depends: Seq[String] = ???

  private def in: Dataset = ???

  override def generate(cell: Code): String = cell.start + (st.map{ st=> cell.start + st.generate(cell)}).mkString("\n")
}

case class FormatConfig(name: FormatName, spec: Seq[FormatDefinition]) extends Statement {
  override def generate(cell: Code): String = cell.start + name.generate(cell) +
    cell.indented(Seq("return " + "(F." + spec.map(x => x.generate(cell)).mkString("\n" + cell.start + cell.start + "."))) + ")"
  //removed \n and cell.start
  // because the code doesn't work if they are in multiline, tested in db workspace.
  //https://demo.cloud.databricks.com/#notebook/9612086/command/9879795
  //so alternatively introduced brackets to handle
}

case class FormatName(character: Boolean,name:String) extends Option with Statement {
  override def generate(cell: Code): String = cell.start +  s"""def ${name}_format(_fmt):""" + "\n"
}

case class FormatDefinition(key: Constant, value: Constant) extends Statement {
  //:TODO: Date formater
  override def generate(cell: Code): String = {

    val exp = (key,value) match {
      case (Integer(k),Char(v)) => s"""when(F.col(_fmt) == F.lit(${k}), F.lit('${v}'))"""
      case(Char(k),Char(v)) => {
        if (k.contains("-<")) {
          k.split("-<") match {
            case Array(x,y) =>
              s"""when((F.col(_fmt) >= F.lit(${x})) & (F.col(_fmt) < F.lit(${y})), F.lit('${v}'))"""
            case _ => //Throw Error
          }
        }else if(k.contains("-")) {
          k.split("-") match {
            case Array(x,"high") => s"""when(F.col(_fmt) >= F.lit(${x}),F.lit('${v}'))"""
            case Array("low",y)  => s"""when(F.col(_fmt) < F.lit(${y}),F.lit('${v}'))"""
          }
        }else if ( k == "other") {
          s"""otherwise(F.lit('${v}'))"""
        }else
          s"""when((F.col(_fmt) == F.lit('${k})'),F.lit('${v}'))""" //This is equal to Char(k) & Char(v)
      }
      case (Integer(k), Integer(v)) => s"""when((F.col(_fmt) == F.lit(${k})),F.lit(${v}))"""
      case _ => throw new ParseException(s"Cannot parse FORMATL: $key $value", 0)
    }
    cell.context.importFunctionsAlias()
    exp.toString
  }

}

case class LibraryName(name: String) extends Option {
  override def generate(cell: Code): String = ???
}

object FormatParser extends Common[Format] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

  def lib[_: P]: P[LibraryName] = (W("lib") ~ "=" ~ identifier.! ~ ";").map(LibraryName)

  def formatConfig[_:P] = (W("value") ~ fmtName ~ formatKeyValue.rep ~ ";").map{
    case (fmtName,fmtDef) => FormatConfig(fmtName, fmtDef)
  }

  def fmtName[_:P]:P[FormatName] =  ("$".!.?.map(_.isDefined) ~~ token).map(FormatName.tupled)

  def valueDoubleQuote[_: P] = ("\"" ~~ CharsWhile(!"\"".contains(_)).! ~~ "\"").map(Char)

  def valueSingleQuote[_: P] = (char)

  def formatParms[_:P] = valueSingleQuote|valueDoubleQuote|constant

  def formatKeyValue[_: P]:P[FormatDefinition] = (formatParms ~ "=" ~ formatParms).map(FormatDefinition.tupled)

  override def parser[_: P]: P[Format] = (
    W("proc") ~ W("format")  ~ (lib | ";").rep ~
      (formatConfig | unknownStatement).rep()
      ~ run
    ).map{
    case (op:Seq[Option],st:Seq[Statement]) => Format(op,st)
  }

}