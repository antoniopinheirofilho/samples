package sasconverter.steps

import sasconverter.{Code, Context, syntax}

case class ProcAppend(opts: Seq[Option]) extends Proc(opts) {
  /** What table or view this step defines */
  override def produces: String = base.name

  /** What tables or views this step depends on */
  override def depends: Seq[String] = Seq(base.name, data.name)

  private def base: Dataset = data("base")
  private def data: Dataset = data("data")

  override def generate(cell: Code): String = {
    val force = if (flag("force"))
      s".select(append_base.columns)"
    else
      ""
    cell.start +
      s"append_base = ${base.generate(cell)}" + "\n" +
      s"append_data = ${data.generate(cell)}" + "\n" +
      "(append_base" + "\n" +
      cell.indented(Seq(
        s".unionByName(append_data$force)",
        base.generateOut(cell)
      )) + ")"
  }
}

// https://v8doc.sas.com/sashtml/proc/z0235213.htm
/** What tables or views this step depends on */
object ProcAppendParser extends Common[ProcAppend] {
  import fastparse._
  import syntax.Implicits._
  import syntax.Syntax._

  override def parser[_: P]: P[ProcAppend] =
    (W("proc") ~ W("append") ~
      appendOptions.rep ~ ";" ~
      run).map(ProcAppend)

  def appendOptions[_: P] = {
    keyDataset(W("base")) | // mandatory argument
      keyDataset(W("data")) | // considered as mandatory for pyspark implementation
      keyValue | // used to catch the "APPENDERVER" optional argument (ignored in pyspark)
      W("force").!.map(_ => Flag("force")) | // if passed, drop excess columns from "data" dataset
      flag(W("getsort")) | // ignored for pyspark
      flag(W("nowarn")) // suppresses warning of force flag. No need to implement
  }
}
