package sasconverter

import fastparse.{Parsed, parse}
import sasconverter.steps.StepParser
import syntax.Macro

import scala.io.Source
import scala.util.control.NonFatal

object Compiler {
  def consumeFile(filename: String): String = {
    var keep: Throwable = null
    val source = Source.fromFile(filename)
    try {
      // this is needed to produce a proper error
      val fileContents = source.getLines.mkString
      val resultingSasCode = Macro.process(fileContents)
      transpile(resultingSasCode)
    } catch {
      case NonFatal(e) =>
        keep = e
        throw e
    } finally if (keep == null) source.close else {
      try source.close catch {
        case NonFatal(other) =>
          keep.addSuppressed(other)
      }
    }
  }

  private[sasconverter] def transpile(resultingSasCode: String): String = {
    val notebookGenerationContext = Context()
    parse(resultingSasCode, StepParser.parser(_), verboseFailures = true) match {
      case Parsed.Success(value, _) =>
        value match {
          case v: Seq[Generating] =>
            val notebookWithoutInit = v.map(sasEtlStep => {
              sasEtlStep.generate(Code(notebookGenerationContext))
            }).mkString("\n\n# COMMAND ----\n\n")
            notebookGenerationContext.init + notebookWithoutInit
        }
      case f: Parsed.Failure =>
        throw new AssertionError(f.trace().longMsg)
    }
  }
}
