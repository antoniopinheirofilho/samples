package sasconverter

import scala.collection.mutable.ArrayBuffer

object Generator {
  //
}

case class Context() {
  var fImported = false
  var windowImported = false
  var datetimeImported = false

  // todo: make private
  var init = ""

  def importFunctionsAlias(): Unit = if (!fImported) {
    init += "import pyspark.sql.functions as F\n"
    fImported = true
  }

  def importWindow(): Unit = if (!windowImported) {
    init += "from pyspark.sql.window import Window\n"
    windowImported = true
  }

  def importDatetime(): Unit = if (!datetimeImported) {
    init += "import datetime\n"
  }

  val functionsUsed = Set[String]()

  def addUsedFunction(name: String) = functionsUsed + name
}

trait Generating {
  def generate(cell: Code): String
}

case class Code(context: Context) {
  private var level = 0;
  val local: collection.mutable.Map[String,Any] = collection.mutable.Map[String,Any]()
  // TODO: possibly make it more mature
  def stringList(sl: Seq[String]) = sl.map(s => s"'$s'").mkString(", ")

  def start: String = "  " * level

  def wrapIndent(str: => String): String = {
    level += 1
    val v = str
    level -= 1
    v
  }

  def indentedOptional(lines: => Option[Seq[String]]): String =
    lines
      .map(x => indented(x))
      .getOrElse("")

  def indented(lines: => Seq[String]): String = {
    level += 1
    val result = start + lines.filter(!_.equals("")).mkString("\n" + start)
    level -= 1
    result
  }

  def indentedComma(lines: => Seq[String]): String = {
    level += 1
    val result = start + lines.filter(!_.equals("")).mkString(",\n" + start)
    level -= 1
    result
  }

  def stringChildren(c: Iterable[String]): String = c.mkString("\n" + start)

  def indentedSugar(lines: String*): String = indented(lines)

  def children(c: => Seq[Generating]): String = c.map(start + _.generate(this)).mkString("\n")
}
