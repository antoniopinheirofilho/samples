package sasconverter.syntax

import sasconverter.syntax.Operators._
import sasconverter.syntax.Syntax._

import scala.collection.mutable.ArrayBuffer

class MacroTest extends ParserSuite {
  import Macro._

  test("%STR(abc)") {
    p(str(_), StrMacro(ArrayBuffer(Char("abc")) ++ ArrayBuffer.fill(99)(Char(""))))
  }

  test("""%STR("abc")""") {
    p(str(_), StrMacro(ArrayBuffer(Char(""""abc"""")) ++ ArrayBuffer.fill(99)(Char(""))))
  }

  test("%STR(  abc)") {
    p(str(_), StrMacro(ArrayBuffer(Char("  abc")) ++ ArrayBuffer.fill(99)(Char(""))))
  }

  test("%STR()") {
    p(str(_), StrMacro(ArrayBuffer(Char("")) ++ ArrayBuffer.fill(99)(Char(""))))
  }

  test("%LENGTH(some text)") {
    p(expr(_), Reference("length",ArrayBuffer(Argument(Char("some text"),None))))
    r(expr(_), 9)
  }

  test("%UPCASE(some text)") {
    p(expr(_), Reference("upcase",ArrayBuffer(Argument(Char("some text"),None))))
    r(expr(_), "SOME TEXT")
  }

  test("%let foo = beer bar;") {
    p(let(_), Let("foo", Char("beer bar")))
  }

  test("%let foo = lt;") {
    p(let(_), Let("foo", Identifier("lt")))
  }

  test("simple macro") {
    parses(
      """%macro abc;
        |   Something
        |%mend abc;
        |""".stripMargin,
      definition(_), Definition("abc", Seq(), Block(Seq(
        Code("Something\n")
      ))))
  }

  test("macro param") {
    parses("a", param(_), Parameter("a"))
    parses("b = ", param(_), Parameter("b", Some(Null())))
    parses("c= d", param(_), Parameter("c", Some(Char("d"))))
  }

  test("(a, b= 2, c=     )") {
    p(paramList(_), Seq(
      Parameter("a", None),
      Parameter("b", Some(Integer(2))),
      Parameter("c", Some(Null())),
    ))
    parses("()", paramList(_), Seq())
  }

  test("param macro") {
    parses(
      """%macro abc(a, b=1,keep=);
        |   Something
        |%mend abc;
        |""".stripMargin,
      definition(_), Definition("abc", Seq(
        Parameter("a"),
        Parameter("b", Some(Integer(1))),
        Parameter("keep",Some(Null()))
      ), Block(Seq(
        Code("Something\n")
      ))))
  }
  test("%bcd") {
    p(ref(_), Reference("bcd"))
  }

  test("%abc;") {
    p(ref(_), Reference("abc"))
  }

  test("%abc();") {
    p(ref(_), Reference("abc"))
  }

  test("%ABC()") {
    p(expr(_), Reference("abc"))
  }

  test("%qupcase(%qsysfunc(dread(id,&i)))") {
    parses("%qupcase(%qsysfunc(dread(id,&i)))", ref(_),
      Reference("qupcase", Seq(
        Argument(SysFunc(
          "qsysfunc",
          "dread",
          Seq(
            Argument(Char("id")),
            Argument(Variable("i"))
          )
        ))
    )))
  }

  test("%abc(D:\\Working Directory\\output.xlxs,s3a://foo.bar/x,  OtherVar)") {
    p(ref(_),
      Reference("abc", Seq(
        Argument(Char("D:\\Working Directory\\output.xlxs")),
        Argument(Char("s3a://foo.bar/x")),
        Argument(Char("OtherVar"))
      )))
  }

  test("variable") {
    parses("&abc", variable(_), Variable("abc"))
    parses("&abc.", variable(_), Variable("abc"))
  }

  test("twoLevelVariable") {
    parses("&abc..&cde", twoLevelVariable(_), TwoLevelVariable(Variable("abc"), Variable("cde")))
  }

  test("oneLevelVariableInterpolated") {
    parses("&abc..cde", oneLevelVariableInterpolated(_), Macro.OneLevelVariableInterpolated(Variable("abc"), "cde"))
  }

  test("oneLevelVariableSuffix") {
    parses("&abc._cde", oneLevelVariableSuffix(_), OneLevelVariableSuffix(Variable("abc"), "_cde"))
  }

  test("blocks") {
    parses(
      """%LET something = happen here;
        |%MACRO names;
        |    Test
        |%MEND names;
        |data %names;
        |""".stripMargin, main(_), Block(Seq(
        Let("something", Char("happen here")),
        Definition("names", Seq(), Block(Seq(
          Code("Test\n")
        ))),
        Code("data "),
        Reference("names")
      )))
  }

  test("hello &something") {
    parses("hello &something", block(_),
      Block(Seq(
        Code("hello "),
        Variable("something")
      )))
  }

  test("simple eval without args") {
    Macro.process(
      """%LET something = world;
        |%MACRO names;
        |    hello &something
        |%MEND names;
        |data %names;
        |""".stripMargin) mustEqual
      "data  hello  world"
  }

  test("iterative do with args") {
    Macro.process(
      """%macro names(name= ,number= );
        |   %do n=1 %to &number;
        |      &name&n
        |   %end;
        |%mend;
        |data %names(name=dsn,number=5);
        |""".stripMargin) mustEqual
      "data  dsn1 dsn2 dsn3 dsn4 dsn5"
  }

  test("data %names(name=dsn,number=5);") {
    p(block(_),
      Block(Seq(
        Code("data "),
        Reference("names", Seq(
          Argument(Char("dsn"), Some("name")),
          Argument(Integer(5), Some("number"))
        ))
      )))
  }

  test("""%let a = ("%QUPCASE(&b)" = "&c" OR %QUPCASE(&d) eq E);""") {
    p(block(_),
      Block(Seq(
        Let("a",
          Binary(
            Binary(
              TextExpression("%QUPCASE(&b)"),
              Equals,
              TextExpression("&c"),
            ),
            Or,
            Binary(
              Reference("qupcase", Seq(
                Argument(Variable("d"))
              )),
              Equals,
              Syntax.Char("E")
            ),
        ))
      )))
  }

//  test("calling system macros") {
//    Macro.process(
//      """%LET b = a;
//        |%LET c = A;
//        |%LET d = evaluating this;
//        |%let a = ("%QUPCASE(&b)" = "&c" OR %QUPCASE(&d) eq E);
//        |&a = %length(&d);
//        |""".stripMargin) mustEqual "1=  15"
//  }

  test("corner cases 001") {
    parses(
      """%macro _a_Abc(AB, C=foo, D= , F=3);
        |Something
        |%mend;
        |""".stripMargin, main(_),
      Block(Seq(
        Definition("_a_abc", Seq(
          Parameter("ab", None),
          Parameter("c", Some(Char("foo"))),
          Parameter("d", Some(Null())),
          Parameter("f", Some(Integer(3))),
        ), Block(Seq(
          Code("Something\n")
        )))
      )))
  }

  test("1 + 2 * 3") {
    p(expr(_),
      Binary(Integer(1),
        Add,
        Binary(
          Integer(2),
          Multiply,
          Integer(3)
        )
      )
    )
  }

  test("1*2+3/4") {
    parses("1*2+3/4", expr(_),
      Binary(Binary(Integer(1), Multiply, Integer(2)),
        Add, Binary(Integer(3), Divide, Integer(4))))
  }

  test("1*(2 + 3)/4") {
    p(expr(_),
      Binary(
        Integer(1),
        Multiply,
        Binary(
          Binary(
            Integer(2),
            Add,
            Integer(3)
          ),
          Divide,
          Integer(4)
        )
      ))
  }

  test("&a+1*2+3/4") {
    parses("&a+1*2+3/4", expr(_),
      Binary(
        Variable("a"),
        Add,
        Binary(
          Binary(
            Integer(1),
            Multiply,
            Integer(2)),
          Add,
          Binary(
            Integer(3),
            Divide,
            Integer(4))
        ),
      )
    )
  }

  test("NOT  %symexist(&x) or &y") {
    parses("NOT  %symexist(&x) or &y", expr(_),
      Unary(
        UnaryNot,
        Binary(
          Reference("symexist", Seq(
            Argument(Variable("x"))
          )),
          Or,
          Variable("y")
        )
      ))
  }

  test("-a") {
    parses("-a", expr(_), Unary(UnaryMinus,Char("a")))
  }

  test("D:\\Working Directory\\output.xlxs") {
    p(expr(_),
      Char("D:\\Working Directory\\output.xlxs"))
  }

  test("D:\\Working Output.xlxs or something") {
    p(expr(_),
      Binary(
        Char("D:\\Working Output.xlxs"),
        Or,
        Char("something")
      )
    )
  }

  test("%let a = %lowcase(&b) eq c or %upcase(&d) = DATETIME;") {
    p(main(_),
      Block(Seq(
        Let("a",
          Binary(
            Binary(
              Reference("lowcase", Seq(
                Argument(
                  Variable("b")
                )
              )),
              Equals,
              Char("c")
            ),
            Or,
            Binary(
              Reference("upcase", Seq(
                Argument(
                  Variable("d")
                )
              )),
              Equals,
              Char("DATETIME")
            )
          ))
      )))
  }

  test("""%let a = "&b" = "";""") {
    p(main(_), Block(Seq(
      Let("a", Binary(TextExpression("&b"), Equals, Null()))
    )))
  }

  test("(&a ne)") {
    p(omitCond(_),
      Binary(
        Variable("a"),
        NotEquals,
        Null()
      )
    )
  }

  test("(&a ne 1)") {
    p(omitCond(_),
      Binary(
        Variable("a"),
        NotEquals,
        Integer(1)
      )
    )
  }

  test("(%scan(&a,&b)^=)") {
    p(omitCond(_),
      Binary(
        Reference("scan", Seq(
          Argument(Variable("a")),
          Argument(Variable("b")),
        )),
        NotEquals,
        Null()
      )
    )
  }

  test("funky resolve") {
    Macro.process(
      """%let x=temp;
        |%let n=3;
        |%let x3=result;
        |%let temp3=result2;
        |%put &x&n;
        |%put &&x&n;
        |%put &&&x&n;
        |""".stripMargin) mustEqual
      """temp3
        |result
        |result2
        |""".stripMargin
  }

  test("scan") {
    // https://v8doc.sas.com/sashtml/macro/z514scan.htm
    Macro.process(
      """%macro a;
        |   aaaaaa
        |%mend a;
        |%macro b;
        |   bbbbbb
        |%mend b;
        |%macro c;
        |   cccccc
        |%mend c;
        |%let x=%nrstr(%a*%b*%c);
        |%put X: &x;
        |%put The third word in X, with SCAN: %scan(&x,3,*);
        |%put The third word in X, with QSCAN: %qscan(&x,3,*);
        |""".stripMargin) mustEqual
      // todo: fix whitespace in macros
      """X: %a*%b*%c
        |The third word in X, with SCAN: cccccc
        |The third word in X, with QSCAN: %c
        |""".stripMargin
  }

  test("%%a%*%%b%*%%c") {
    p(textExpression(_), Seq(
      Code("%%"),
      Code("a"),
      Code("%*"),
      Code("%%"),
      Code("b"),
      Code("%*"),
      Code("%%"),
      Code("c"),
    ))
  }

  test("%nrstr(%a*%b*%c)") {
    p(textExpression(_), Seq(
      Code("%%a%*%%b%*%%c")
    ))
  }

  test("%scan(&x,3,*)") {
    p(textExpression(_), Seq(
      Reference("scan", Seq(
        Argument(
          Variable("x")
        ),
        Argument(
          Integer(3)
        ),
        Argument(
          Char("*")
        )
      ))
    ))
  }

  test("%LET a = %b(c=d);") {
    p(let(_), Let(
        "a",
        Reference(
          "b",
          Seq(
            Argument(Char("d"), Some("c"))
          )
        )
      )
    )
  }

  test("(%bquote(&a) ne '')") {
    p(expr(_),
      Binary(
        Bquote(
          Variable("a")
        ),
        Operators.NotEquals,
        Char("")
      )
    )
  }

  test("(%bquote(&a) ne .)") {
    p(expr(_),
      Binary(
        Bquote(
          Variable("a")
        ),
        Operators.NotEquals,
        Fractional("",0,0,0)
      )
    )
  }

  test("(%bquote(&a) eq )") {
    p(expr(_),
      Binary(
        Bquote(
          Variable("a")
        ),
        Operators.Equals,
        Null()
      )
    )
  }

  test("%if %bquote(&a) eq %then %do; something %end;") {
    p(statement(_),
      If(
        Binary(
          Bquote(
            Variable("a")
          ),
          Operators.Equals,
          Null()
        ),
        Do(
          Block(
            ArrayBuffer(Code("something "))
          )
        ),
        None
      )
    )
  }

  test("%if %bquote(&a..&b) eq %then %do; something %end;") {
    p(statement(_),
      If(
        Binary(
          Bquote(
            TwoLevelVariable(Variable("a"),Variable("b"))
          ),
          Operators.Equals,
          Null()
        ),
        Do(
          Block(
            ArrayBuffer(Code("something "))
          )
        ),
        None
      )
    )
  }

  test("%if %bquote(&a._bcd) eq %then %do; something %end;") {
    p(statement(_),
      If(
        Binary(
          Bquote(
            OneLevelVariableSuffix(Variable("a"),"_bcd")
          ),
          Operators.Equals,
          Null()
        ),
        Do(
          Block(
            ArrayBuffer(Code("something "))
          )
        ),
        None
      )
    )
  }

  test("%SYSFUNC(exist(%SCAN(&SRCLIB1..&SRCLIB2,1,%STR(%())))") {
    p(expr(_),
      SysFunc(
        "SYSFUNC", "exist",
        ArrayBuffer(
          Argument(
            Reference(
              "scan",
              ArrayBuffer(
                Argument(TwoLevelVariable(Variable("srclib1"), Variable("srclib2")), None),
                Argument(Integer(1), None),
                Argument(StrMacro(ArrayBuffer(Char("%(")) ++ ArrayBuffer.fill(99)(Char(""))), None)
              )
            ),
            None
          )
        )
      )
    )
  }

//  test("process current focus") {
//    val source = Source.fromFile(".../current-focus.sas")
//    val fileContents = source.getLines.mkString
//    val resultingSasCode = Macro.process(fileContents)
//    println(resultingSasCode)
//  }
}
