package sasconverter.syntax

class SyntaxTest extends ParserSuite {
  import Operators._
  import Syntax._

  test("W") {
    parses("bOOm", W("boom")(_), ())
  }

  test("integer") {
    parses("123", integer(_), Integer(123))
    parses("-231n", integer(_), Integer(-231))
    parses("+321N", integer(_), Integer(321))
  }

  test("exponent") {
    parses("e-124", exponent(_), -124)
    parses("E125", exponent(_), 125)
  }

  test("fractional") {
    parses("-.33e-2", fractional(_), Fractional("-",0,33,-2))
    parses(".5", fractional(_), Fractional("",0,5,0))
    parses("-57.33n", fractional(_), Fractional("-",57,33,0))
    parses("12345.12N", fractional(_), Fractional("",12345,12,0))
    parses(".", fractional(_), Fractional("",0,0,0))
  }

  test("char") {
    parses("""'H''ello
        | 世界'""".stripMargin, char(_), Char("H'ello\n 世界"))
    parses("'x'", constant(_), Char("x"))
  }

  test("date") {
    parses("date '2020-12-14'", date(_), Date(2020,12,14))
    parses("date '2020-12-14'", constant(_), Date(2020,12,14))
  }

  test("nulls") {
    parses("' '", constant(_), Null())
    parses("._", constant(_), Null())
    parses(".A", constant(_), Null())
  }

  test("constant list") {
    parses("('a', 1, .2)", constantList(_), ConstantList(Seq(
      Char("a"),
      Integer(1),
      Fractional("",0,2,0)
    )))
    parses("(1,(2,3),4)", constant(_), ConstantList(Seq(
      Integer(1),
      ConstantList(Seq(
        Integer(2),
        Integer(3),
      )),
      Integer(4),
    )))
  }

  test("identifier") {
    parses("boom", identifier(_), Identifier("boom"))
    parses("\"世界\"", identifier(_), Identifier("世界"))
  }

  test("x1-x5") {
    parses("x1-x5", varRangeList(_), VariableList(Seq(
      Identifier("x1"),
      Identifier("x2"),
      Identifier("x3"),
      Identifier("x4"),
      Identifier("x5")
    )))
    parses("x5-x1", varRangeList(_), VariableList(Seq(
      Identifier("x5"),
      Identifier("x4"),
      Identifier("x3"),
      Identifier("x2"),
      Identifier("x1")
    )))
  }

  test("var list") {
    parses("a b c", varNameList(_), VariableList(Seq(
      Identifier("a"),
      Identifier("b"),
      Identifier("c"),
    )))
  }

  test("var prefix") {
    parses("sales:", varPrefixList(_),
      VariablePrefixedList(Identifier("sales")))
  }

  test("x1-x3 x7-x9") {
    parses("x1-x3 x7-x9", variableList(_), MixedVariablesList(Seq(
      VariableList(Seq(
        Identifier("x1"),
        Identifier("x2"),
        Identifier("x3"),
      )),
      VariableList(Seq(
        Identifier("x7"),
        Identifier("x8"),
        Identifier("x9"),
      )),
    )))
  }

  test("primary simple") {
    parses("boom", primary(_), Identifier("boom"))
  }

  test("x()") {
    parses("x()", expr(_), Call("x"))
  }

  test("function call") {
    parses("_bar(tx, .5)", expr(_), Call("_bar", Seq(
      Identifier("tx"),
      Fractional("", 0, 5, 0)
    )))
    parses("sum(min(a,  'b'),  max(3,4))", expr(_),
      Call("sum", Seq(
        Call("min", Seq(
          Identifier("a"),
          Char("b")
        )),
        Call("max", Seq(
          Integer(3),
          Integer(4)
        ))
      )))
  }

//  test("call of vars") {
//    parses("sum(OF x1-x3)", expr(_),
//      Call("sum", of=MixedVariablesList(Seq(
//        VariableList(Seq(
//          Identifier("x1"),
//          Identifier("x2"),
//          Identifier("x3"),
//        ))
//      ))))
//  }

  test("a + b") {
    parses("a + b", expr(_), BinaryOp(
      Identifier("a"),
      Add,
      Identifier("b")
    ))
  }

  test("a**c + b") {
    parses("(a ** c) + b", expr(_), BinaryOp(
      BinaryOp(
        Identifier("a"),
        Power,
        Identifier("c"),
      ),
      Add,
      Identifier("b")
    ))
  }

  test("complex") {
    parses("(max('a',min(3,4)) - 2) ** input(.5)", expr(_), BinaryOp(
      BinaryOp(
        Call("max", Seq(
          Char("a"),
          Call("min", Seq(
            Integer(3),
            Integer(4),
          ))
        )),
        Subtract,
        Integer(2)
      ),
      Power,
      Call("input", Seq(
        Fractional("", 0,5,0)
      ))
    ))
  }

  test("1 in (1,2)") {
    parses("1 in (1,2)", expr(_), BinaryOp(
      Integer(1),
      InList,
      ConstantList(Seq(
        Integer(1),
        Integer(2)
      ))))
  }

  test("a not in b") {
    // a not in ('b','c') or (d = 'e' and f ne 'g')
    parses("a not in b", expr(_), BinaryOp(
      Identifier("a"),
      NotIn,
      Identifier("b")
    ))
  }

  test("corner") {
    // a not in ('b','c') or (d = 'e' and f ne 'g')
    parses("a not in ('b','c') or (d = 'e' and f ne 'g')", expr(_),
      BinaryOp(
        BinaryOp(
          Identifier("a"),
          NotIn,
          ConstantList(Seq(
            Char("b"),
            Char("c")
          ))
        ),
        Or,
        BinaryOp(
          BinaryOp(
            Identifier("d"),
            Equals,
            Char("e")
          ),
          And,
          BinaryOp(
            Identifier("f"),
            NotEquals,
            Char("g")
        ))
      ))
  }

  test("$8.") {
    p(informat(_), Informat(character = true, None, 8))
  }

  test("$8.2") {
    p(informat(_), Informat(character = true, None, 8, 2))
  }

  test("$.") {
    p(informat(_), Informat(character = true, None))
  }

  test(".") {
    p(informat(_), Informat(character = false, None))
  }

  test("mdyampmp.") {
    p(informat(_), Informat(character = false, Some("mdyampmp")))
  }

  test("mdyampmp8.") {
    p(informat(_), Informat(character = false, Some("mdyampmp"), 8))
  }

  test("mdyampmp8.2") {
    p(informat(_), Informat(character = false, Some("mdyampmp"), 8, 2))
  }

  test("$N8601E.") {
    p(informat(_), Informat(character = true, Some("n8601e")))
  }

  test("$N8601E2.") {
    p(informat(_), Informat(character = true, Some("n8601e"), 2))
  }

  test("$N8601E2.3") {
    p(informat(_), Informat(character = true, Some("n8601e"), 2, 3))
  }
}
