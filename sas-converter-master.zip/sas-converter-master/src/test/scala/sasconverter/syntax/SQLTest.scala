package sasconverter.syntax

import java.text.ParseException

class SQLTest extends ParserSuite {
  import Operators._
  import SQL._
  import Syntax._

  private def s(res: SqlExpr): Unit = parses(currentTest, select(_), res)
  private def q(res: SqlExpr): Unit = parses(currentTest, dql(_), res)

  test("SELECT *") {
    s(
      Select(Seq(Asterisk())))
  }

  test("SELECT foo.x, bar.XYZ AS 'xx yy'n, foo.'a b'n") {
    s(
      Select(Seq(
        TableColumn("foo","x"),
        Alias(TableColumn("bar", "xyz"), "xx yy"),
        TableColumn("foo","a b")
      )))
  }

  test("SELECT * FROM a, b c, d") {
    q(Query(Seq(
      Select(Seq(Asterisk())),
      From(Seq(
        SimpleName("a", Seq()),
        AliasedTable(SimpleName("b", Seq()),"c"),
        SimpleName("d", Seq()),
      )),
    )))
  }

  test("SELECT * FROM a WHERE foo EQ bar || baz") {
    q(Query(Seq(
      Select(Seq(Asterisk())),
      From(Seq(SimpleName("a", Seq()))),
      Where(Binary(
        Column("foo"),
        Equals,
        Binary(
          Column("bar"),
          Concatenate,
          Column("baz")
        )
      ))
    )))
  }

  test("SELECT * FROM a GROUP BY 1, b, c(d) HAVING x > y") {
    q(Query(Seq(
      Select(Seq(Asterisk())),
      From(Seq(SimpleName("a", Seq()))),
      GroupBy(Seq(
        Integer(1),
        Column("b"),
        Call("c", Seq(
          Column("d")
        ))
      )),
      Having(Binary(
        Column("x"),
        GreaterThan,
        Column("y")
      ))
    )))
  }

  test("SELECT * ORDER BY 1 ASC, b DESC") {
    q(Query(Seq(
      Select(Seq(Asterisk())),
      OrderBy(Seq(
        Ordering(Integer(1), "asc"),
        Ordering(Column("b"), "desc")
      ))
    )))
  }

  test("SELECT * ORDER BY n.'abc a'n, b DESC") {
    q(Query(Seq(
      Select(Seq(Asterisk())),
      OrderBy(Seq(
        Ordering(TableColumn("n","abc a"),"asc"),
        Ordering(Column("b"),"desc")
      ))
    )))
  }

  test("SELECT COUNT()") {
    s(
      Select(Seq(
        Call("count")
      )))
  }

  test("SELECT COUNT(*)") {
    s(
      Select(Seq(
        Call("count", Seq(
          Asterisk()
        ))
      )))
  }

  test("SELECT COUNT(DISTINCT(*))") {
    s(
      Select(Seq(
        Call("count", Seq(
          Call("distinct", Seq(
            Asterisk()
          ))
        ))
      )))
  }

  test("SELECT DISTINCT a, b.*, c.d") {
    s(
      SelectDistinct(Seq(
        Column("a"),
        Asterisk("b"),
        TableColumn("c", "d")
      )))
  }

  test("SELECT CASE a WHEN c THEN d ELSE e END AS f") {
    s(
      Select(Seq(
        Alias(
          Case(
            Some(Column("a")),
            Seq(
              When(Column("c"), Column("d"))
            ),
            Some(Column("e"))
          ),
          "f"
        )
      )))
  }

  test("SELECT CASE WHEN c THEN d END") {
    s(
      Select(Seq(
        Case(  // todo: perhaps separate case class?..
          None,
          Seq(
            When(
              Column("c"),
              Column("d")
            )
          ),
          None
        )
      )))
  }

  test("SELECT a label='b', b \"something here\"") {
    s(
      Select(Seq(
        ExprModifiers(
          Column("a"),
          Seq(
            Label("b")
          )),
        ExprModifiers(
          Column("b"),
          Seq(
            Label("something here")
          )),
      ))
    )
  }

  test("SELECT a + b AS c") {
    s(
      Select(Seq(
        Alias(
          Binary(
            Column("a"),
            Add,
            Column("b")
          ),
          "c"
        )
      ))
    )
  }

  test("SELECT a .. b format=yy00dd2.4") {
    s(
      Select(Seq(
        ExprModifiers(
          Binary(
            Column("a"),
            StripAndConcatenate,
            Column("b")
          ),
          Seq(
            FormatModifier(
              Informat(character = false, Some("yy00dd"), 2, 4)
            )
          )
        )
      ))
    )
  }

  test("SELECT a informat=$2. format=yy00dd2.4, b format=.") {
    s(
      Select(Seq(
        ExprModifiers(
          Column("a"),
          Seq(
            InformatModifier(
              Informat(character = true, None, 2)),
            FormatModifier(
              Informat(character = false, Some("yy00dd"), 2, 4))
          )),
        ExprModifiers(
          Column("b"),
          Seq(
            FormatModifier(Informat(character = false, None))
          )),
      ))
    )
  }

  test("SELECT a length=43 transcode=no, b AS c") {
    s(
      Select(Seq(
        ExprModifiers(
          Column("a"),
          Seq(
            Length(43),
            Transcode(false)
          )
        ),
        Alias(
          Column("b"),
          "c"
        ))))
  }

  test("select p format=16. into :p notrim") {
    q(
      Query(Seq(
        Select(Seq(
          ExprModifiers(
            Column("p"),
            Seq(
              FormatModifier(
                Informat(character = false, None, 16))))
        )),
        Into(Seq(
          IntoVar("p", Some(Notrim()))
        ))
      )))
  }

  test("select * from a") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(SimpleName("a", Seq()))
        )
      ))
    )
  }

  test("select * from db.a") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(TwolevelName("db", "a", Seq()))
        )
      ))
    )
  }

  test("SELECT * FROM a AS b") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(
            AliasedTable(
              SimpleName("a", Seq()),
              "b"
            )
          )
        )
      ))
    )
  }

  test("select * from \"a\"") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(Pathname("a"))
        )
      ))
    )
  }

  test("select * from (select a from b)") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(Query(Seq(
            Select(Seq(
              Column("a")
            )),
            From(
              Seq(SimpleName("b", Seq()))
            )
          )))
        )
      ))
    )
  }

  test("select * from a AS aa cross join b as c right outer join d as x on b.d_id = x.id inner join y") {
    q(
      Query(Seq(
        Select(Seq(Asterisk())),
        From(
          Seq(AliasedTable(
            SimpleName("a", Seq()),
            "aa"
          ))
        ),
        Join(
          Set(Cross),
          AliasedTable(
            SimpleName("b", Seq()),
            "c"
          ),
          None
        ),
        Join(
          Set(Right, Outer),
          AliasedTable(
            SimpleName("d", Seq()),
            "x"
          ),
          Some(
            Binary(
              TableColumn("b", "d_id"),
              Equals,
              TableColumn("x", "id")
            )
          )
        ),
        Join(
          Set(Inner),
          SimpleName("y", Seq()),
          None
        )
      ))
    )
  }

  test("SELECT * FROM WORK.A OUTER UNION CORR SELECT * FROM WORK.B INTERSECT ALL SELECT * FROM WORK.C") {
    q(QueryUnion(
      Query(Seq(
        Select(Seq(Asterisk(null))),
        From(Seq(TwolevelName("work","a", Seq())))
      )),
      SetOperator("outer union", corr = true, all = false),
      QueryUnion(
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(TwolevelName("work","b", Seq())))
        )),
        SetOperator("intersect", corr = false, all = true),
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(TwolevelName("work", "c", Seq())))
        ))
      )
    ))
  }

  test("CREATE TABLE new AS SELECT * FROM A") {
    parses(currentTest, createTable(_),
      CreateTableAs(
        SimpleName("new", Seq()),
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(SimpleName("a", Seq())))))))
  }

  test("CREATE TABLE &FOO AS SELECT * FROM &libref..A") {
    parses(currentTest, createTable(_),
      CreateTableAs(
        TableVariable(
          Variable("foo"), Seq()
        ),
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(
            TableInterpolatedVariable(
              Variable("libref"),
              ".a", Seq())
          ))))))
  }

  test("label=\"anything\"") {
    parses(currentTest, modifiers(_), Seq(
      Label("anything")
    ))
  }

  test("""work.something(label="anything here")""") {
    parses(currentTest, tableRef(_),
      TwolevelName("work","something", Seq(Label("anything here"))))
  }

  test("CREATE TABLE work.something(label=\"anything\") AS SELECT * FROM A") {
    parses(currentTest, createTable(_),
      CreateTableAs(
        TwolevelName("work","something", Seq(Label("anything"))),
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(SimpleName("a", Seq())))
        ))
      )
    )
  }

  test("CREATE TABLE &work..&something AS SELECT * FROM &A") {
    parses(currentTest, createTable(_),
      CreateTableAs(
        TwoLevelTableInterpolatedVariable(Variable("work"), Variable("something"), Seq()),
        Query(Seq(
          Select(Seq(Asterisk(null))),
          From(Seq(TableVariable(Variable("a"), Seq())))
        ))
      )
    )
  }

  test("assign: simple assignment to sql expression") {
    parses("""a = b + c""", assign(_),
      Assign(
        Column("a"),
        Binary(Column("b"), Add, Column("c"))
      )
    )
  }

  test("set: one expression") {
    parses("""SET a = b + c""", setClause(_),
      SetClause(Seq(
        Assign(
          Column("a"),
          Binary(Column("b"), Add, Column("c"))
        )
      ))
    )
  }

  test("set: multiple expressions") {
    parses("""SET a = b + c, a = b + c, a = b + c, a = b + c""", setClause(_),
      SetClause(Seq(
        Assign(
          Column("a"),
          Binary(Column("b"), Add, Column("c"))
        ),
        Assign(
          Column("a"),
          Binary(Column("b"), Add, Column("c"))
        ),
        Assign(
          Column("a"),
          Binary(Column("b"), Add, Column("c"))
        ),
        Assign(
          Column("a"),
          Binary(Column("b"), Add, Column("c"))
        )
      ))
    )
  }

  test("update: table with alias with where clause") {
    parses("""UPDATE something AS toto SET salary=salary+1000,seniority=seniority+1 WHERE targets=1""", update(_),
      Update(
        AliasedTable(SimpleName("something",Seq()), "toto"),
        SetClause(Seq(
          Assign(Column("salary"), Binary(Column("salary"), Add, Integer(1000))),
          Assign(Column("seniority"), Binary(Column("seniority"), Add, Integer(1)))
        )),
        Some(Where(Binary(Column("targets"), Equals, Integer(1))))
      )
    )
  }

  test("update: two level table without where clause") {
    parses("""UPDATE work.something SET salary=salary+1000,seniority=seniority+1""", update(_),
      Update(
        TwolevelName("work","something",Seq()),
        SetClause(Seq(
          Assign(Column("salary"), Binary(Column("salary"), Add, Integer(1000))),
          Assign(Column("seniority"), Binary(Column("seniority"), Add, Integer(1)))
        )),
        None
      )
    )
  }

  test("update: fail with query expression input") {
    assertThrows[ParseException](
      parses("""UPDATE (WHERE a = 2) SET salary=salary+1000,seniority=seniority+1""", update(_), None)
    )
  }

  test("INSERT INTO work.something (pippo, pluto, paperino) values ('pippo','pluto','paperino') values ('pippo','pluto','paperino')") {
    parses(currentTest, insertValues(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("pippo"), Column("pluto"), Column("paperino"))),
        Seq(
          Seq(Char("pippo"), Char("pluto"), Char("paperino")),
          Seq(Char("pippo"), Char("pluto"), Char("paperino"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) SET pippo='pippo', pluto='pluto', paperino='paperino'") {
    parses(currentTest, insertSet(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("paperino"), Column("pippo"), Column("pluto"))),
        Seq(
          Seq(Char("paperino"), Char("pippo"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) SET pippo=a, pluto='pluto', paperino='paperino'") {
    parses(currentTest, insertSet(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("paperino"), Column("pippo"), Column("pluto"))),
        Seq(
          Seq(Char("paperino"), Column("a"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) SET pippo=call(1), pluto='pluto', paperino='paperino'") {
    parses(currentTest, insertSet(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("paperino"), Column("pippo"), Column("pluto"))),
        Seq(
          Seq(Char("paperino"), Call("call", Seq(Integer(1))), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) VALUES (&var1, 'paperino', 'pluto')") {
    parses(currentTest, insertValues(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("pippo"), Column("paperino"), Column("pluto"))),
        Seq(
          Seq(Variable("var1"), Char("paperino"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something VALUES (&var1,'paperino','pluto')") {
    parses(currentTest, insertValues(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        None,
        Seq(
          Seq(Variable("var1"), Char("paperino"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) SET pippo=&var1, pluto='pluto', paperino='paperino'") {
    parses(currentTest, insertSet(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("paperino"), Column("pippo"), Column("pluto"))),
        Seq(
          Seq(Char("paperino"), Variable("var1"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something SET pippo=&var1, pluto='pluto', paperino='paperino'") {
    parses(currentTest, insertSet(_),
      Insert(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("paperino"), Column("pippo"), Column("pluto"))),
        Seq(
          Seq(Char("paperino"), Variable("var1"), Char("pluto"))
        )
      )
    )
  }

  test("INSERT INTO work.something (pippo, paperino, pluto) SELECT * FROM WORK.A OUTER UNION CORR SELECT * FROM WORK.B INTERSECT ALL SELECT * FROM WORK.C") {
    parses(currentTest, insertQuery(_),
      InsertQuery(
        TwolevelName("work", "something", Seq()),
        Some(Seq(Column("pippo"), Column("paperino"), Column("pluto"))),
        QueryUnion(
          Query(Seq(
            Select(Seq(Asterisk(null))),
            From(Seq(TwolevelName("work", "a", Seq())))
          )),
          SetOperator("outer union", corr = true, all = false),
          QueryUnion(
            Query(Seq(
              Select(Seq(Asterisk(null))),
              From(Seq(TwolevelName("work", "b", Seq())))
            )),
            SetOperator("intersect", corr = false, all = true),
            Query(Seq(
              Select(Seq(Asterisk(null))),
              From(Seq(TwolevelName("work", "c", Seq())))
            ))
          )
        )
      )
    )
  }

  test("INSERT INTO work.something SELECT * FROM WORK.A OUTER UNION CORR SELECT * FROM WORK.B INTERSECT ALL SELECT * FROM WORK.C") {
    parses(currentTest, insertQuery(_),
      InsertQuery(
        TwolevelName("work", "something", Seq()),
        None,
        QueryUnion(
          Query(Seq(
            Select(Seq(Asterisk(null))),
            From(Seq(TwolevelName("work", "a", Seq())))
          )),
          SetOperator("outer union", corr = true, all = false),
          QueryUnion(
            Query(Seq(
              Select(Seq(Asterisk(null))),
              From(Seq(TwolevelName("work", "b", Seq())))
            )),
            SetOperator("intersect", corr = false, all = true),
            Query(Seq(
              Select(Seq(Asterisk(null))),
              From(Seq(TwolevelName("work", "c", Seq())))
            ))
          )
        )
      )
    )
  }

}
