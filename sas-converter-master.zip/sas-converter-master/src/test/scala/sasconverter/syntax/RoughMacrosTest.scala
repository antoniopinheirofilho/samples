package sasconverter.syntax

import java.io.File

import sasconverter.syntax.RoughMacros.{AnyCode, MacroDef}

class RoughMacrosTest extends ParserSuite {
  test("thing") {
    parses(
      """...
        |
        |%macro abc;
        |   Something
        |%mend abc;
        |
        |...
        |
        |%macro cde(...);
        |   nothing
        |%mend;
        |""".stripMargin,
      RoughMacros.parser(_), Seq(
        AnyCode("..."),
        MacroDef("abc", ";\n   Something"),
        AnyCode("..."),
        MacroDef("cde", "(...);\n   nothing")
      ))
  }

  test("dicover") {
    val projectPath = new File(".").getCanonicalPath
    println(s"Project path $projectPath")
    val x = RoughMacros.discover(projectPath)
    x.length mustEqual 1
    x.head.name mustEqual "sample_macro"
  }
}
