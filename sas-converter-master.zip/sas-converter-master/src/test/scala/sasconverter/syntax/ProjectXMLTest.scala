package sasconverter.syntax

import sasconverter.syntax.ProjectXML.{AnyCode, TaskCode}

class ProjectXMLTest extends ParserSuite {
  test("sample") {
    parses(
      """abc
        |<TaskCode>one
        |two
        |
        |three</TaskCode>
        |als
        |<TaskCode>four</TaskCode>
        |""".stripMargin, ProjectXML.parser(_), Seq(
        AnyCode("abc"),
        TaskCode("one\ntwo\n\nthree"),
        AnyCode("als"),
        TaskCode("four")
      ))
  }
}
