package sasconverter.syntax

import fastparse.internal.Instrument
import org.scalatest.concurrent.TimeLimitedTests
import org.scalatest.Outcome
import org.scalatest.concurrent.TimeLimits.failAfter
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.must.Matchers
import sasconverter.{Code, Context, Generating}
import org.scalatest.time.SpanSugar._
import sasconverter.syntax.Macro.{Resolvable, Scope}

import scala.collection.mutable

class ParserSuite extends AnyFunSuite with Matchers with TimeLimitedTests{
  import fastparse._

  val timeLimit = 200000 millis

  var currentTest: String = _
  override def withFixture(test: NoArgTest): Outcome = {
    failAfter(timeLimit) {
      this.synchronized {
        currentTest = test.name
        super.withFixture(test)
      }
    }
  }

  def p[T](parser: P[_] => P[T], x: T): Unit = parses(currentTest, parser, x)
  def r[T](parser: P[_] => P[T], x: Any): Unit = resolves(currentTest, parser, x)

  trait InstrumentRun {
    def before(name: String, ctx: ParsingRun[_]): Unit
    def after(name: String, ctx: ParsingRun[_]): Unit
  }

  case class Debugger() extends Instrument {
    private val depthStack = mutable.Stack[(Int,Int)]()

    private var depth = 0

    private def output(str: String) = println(str)

    override def beforeParse(parser: String, index: Int): Unit = {
      val indent = "  " * depth
      output(s"$indent+$parser")
      depth += 1
    }

    override def afterParse(parser: String, index: Int, success: Boolean): Unit = {
      depth -= 1
      val indent = "  " * depth
      output(s"$indent-$parser")
    }
  }

  def parses[T](input: String, parser: P[_] => P[T], result: T): Unit =
    parse(input, parser/*, instrument=Debugger()*/) match {
      case Parsed.Success(value, _) => value mustEqual result
      case Parsed.Failure(_, _, extra) =>
        fail(extra.trace(true).longAggregateMsg)
    }

  def fails[T](input: String, parser: P[_] => P[T], error: String): Unit =
    parse(input, parser) match {
      case Parsed.Success(value, _) => fail(s"Parser succeeded with $value")
      case f: Parsed.Failure => f.msg mustEqual(error)
    }

  def translates[T >: Generating](input: String, parser: P[_] => P[T], code: String): Unit = {
    parse(input, parser, verboseFailures = true) match {
      case Parsed.Success(value, _) =>
        value match {
          case v: Generating =>
            val cell = Code(Context())
            var generated = v.generate(cell)
            generated = cell.context.init + generated
              println(generated)
            generated.trim mustEqual code.trim
        }
      case Parsed.Failure(label, _, extra) =>
        throw new AssertionError(s"$label - ${extra.trace().longAggregateMsg}")
    }
  }

  def resolves[T >: Resolvable](input: String, parser: P[_] => P[T], expected: Any): Unit = {
    parse(input, parser, verboseFailures = true) match {
      case Parsed.Success(value, _) =>
        value match {
          case v: Resolvable =>
            val scope = Scope()
            val resolved = v.resolve(scope)
            resolved mustEqual expected
        }
      case Parsed.Failure(label, _, extra) =>
        throw new AssertionError(s"$label - ${extra.trace().longAggregateMsg}")
    }
  }
}
