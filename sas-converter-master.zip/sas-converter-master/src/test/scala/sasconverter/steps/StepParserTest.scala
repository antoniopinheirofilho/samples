package sasconverter.steps

import sasconverter.syntax.ParserSuite

class StepParserTest extends ParserSuite {
  test("proc x; y; run;") {
    p(StepParser.unknownProc(_), UnknownProc("x"))
  }
}
