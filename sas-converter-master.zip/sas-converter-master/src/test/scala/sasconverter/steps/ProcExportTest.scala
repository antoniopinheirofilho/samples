package sasconverter.steps

import sasconverter.syntax.ParserSuite

class ProcExportTest extends ParserSuite {
  test("proc export with delim and putname") {
    translates(
      """proc export data=town outfile=file09
        |dbms=dlm replace; PUTNAMES=YES;
        |delimiter='&';run""".stripMargin, ExportParser.parser(_),
      """((spark.table('town'))
        |  .write
        |  .format('delta')
        |  .mode('overwrite')
        |  .save('file09'))
        |""".stripMargin
    )
  }

  test("proc export with tab,append and putname no") {
    translates(
      """proc export data=town outfile=file09
        |dbms=tab ; PUTNAMES=NO;run""".stripMargin, ExportParser.parser(_),
      """((spark.table('town'))
        |  .write
        |  .format('delta')
        |  .mode('append')
        |  .save('file09'))
        |""".stripMargin
    )
  }

  test("proc export with csv append") {
    translates(
      """proc export data=town outtable=file09
        |dbms=csv replace label a=abc b=xyz;
        |run ;""".stripMargin, ExportParser.parser(_),
      """((spark.table('town'))
        |  .withColumnRenamed('a', 'abc')
        |  .withColumnRenamed('b', 'xyz')
        |  .write
        |  .format('delta')
        |  .mode('overwrite')
        |  .save('file09'))
        |""".stripMargin
    )
  }
}
