package sasconverter.steps

import sasconverter.syntax.ParserSuite

class RankTest extends ParserSuite {
  test("rank") {
    translates(
      """proc rank data=ds DESCENDING groups=4;
        |var c1 c2;
        |by c3;
        |ranks c1;
        |""".stripMargin, RankParser.parser(_),
      """import pyspark.sql.functions as F
        |from pyspark.sql.window import Window
        |((spark.table('ds'))
        |  .withColumn('c1', F.rank()
        |    .over(Window.partitionBy('c3')
        |    .orderBy(F.col('c1').desc(), F.col('c2').desc()))))
        |""".stripMargin)
  }

  test("dense rank") {
    translates(
      """proc rank data=ds DESCENDING groups=4 ties=dense;
        |var c1 c2;
        |by c3;
        |ranks c1;
        |""".stripMargin, RankParser.parser(_),
      """import pyspark.sql.functions as F
        |from pyspark.sql.window import Window
        |((spark.table('ds'))
        |  .withColumn('c1', F.dense_rank()
        |    .over(Window.partitionBy('c3')
        |    .orderBy(F.col('c1').desc(), F.col('c2').desc()))))
        |""".stripMargin)
  }
}
