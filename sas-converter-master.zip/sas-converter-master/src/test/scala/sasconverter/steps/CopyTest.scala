package sasconverter.steps

import sasconverter.syntax.ParserSuite

class CopyTest extends ParserSuite {

  def expected(table: String) = {
      s"""(spark.table('libref1.${table}'))
      |  .createOrReplaceTempView('libref2.${table}')
      |""".stripMargin
  }

  test("copy without select") {
    intercept[AssertionError] {
      translates(
        """proc copy in=libref1 out=libref2;
          | run;""".stripMargin, ProcCopyParser.parser(_),
        expected("sales"))
    }
  }

  test("copy single") {
    translates(
      """proc copy in=libref1 out=libref2;
        | select sales;
        | run;""".stripMargin, ProcCopyParser.parser(_),
      expected("sales"))
  }

  test("copy multiple") {
    translates(
      """proc copy in=libref1 out=libref2;
        | select sales rates;
        | run;""".stripMargin, ProcCopyParser.parser(_),
      expected("sales") + expected("rates")
    )
  }

  test("copy case insensitive") {
    translates(
      """proc COPY IN=libref1 OUT=libref2;
        | select sales;
        | run;""".stripMargin, ProcCopyParser.parser(_),
      expected("sales")
    )
  }

  test("with options") {
    // TODO: This will likely require more tests, especially options like override - not sure if
    // it's being used the right way here
    translates(
      """proc copy in=libref1 noclone move out=libref2 memtype=ALL override=(ds-option-1=value-1);
        | select sales;
        | run;""".stripMargin, ProcCopyParser.parser(_),
      expected("sales")
    )
  }

}
