package sasconverter.steps

import sasconverter.syntax.ParserSuite

class SumaryTest extends ParserSuite {

  test("proc summary with variable") {
    translates(
      """proc summary data=&dbname..&tblname nway;
        |     class cno cid;
        |     var  cost;
        |  output out=&dbname..&tblname_sum(drop=_TYPE_ rename=(cost_count=cost_freq cost_std=rejected_cost)) sum=;
        |  run;""".stripMargin, ProcSummaryParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table(f'{dbname}.{tblname}'))
        |  .groupby(F.col('cno'), F.col('cid'))
        |  .agg(F.count(F.col('cost')).alias(f'cost_count'),
        |  F.mean(F.col('cost')).alias(f'cost_mean'),
        |  F.stddev(F.col('cost')).alias(f'cost_std'),
        |  F.min(F.col('cost')).alias(f'cost_min'),
        |  F.max(F.col('cost')).alias(f'cost_max'),
        |  F.expr(f'''percentile(F.col('cost'), array(0.25))''')[0].alias(f'cost_25pct'),
        |  F.expr(f'''percentile(F.col('cost'), array(0.5))''')[0].alias(f'cost_50pct'),
        |  F.expr(f'''percentile(F.col('cost'), array(0.75))''')[0].alias(f'cost_75pct'))
        |    .drop('_type_')
        |  .withColumnRenamed('cost_count', 'cost_freq')
        |  .withColumnRenamed('cost_std', 'rejected_cost').createOrReplaceTempView(f'{dbname}.{tblname_sum}'))
        |""".stripMargin
    )
  }


  test("proc summary simple") {
    translates(
      """proc summary data=dbname.tblname ;
        |     class col1 col2 col3;
        |     var  salary arrears;
        |     output out = dbname.tblname_sum
        |  run;""".stripMargin, ProcSummaryParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('dbname.tblname'))
        |  .groupby(F.col('col1'), F.col('col2'), F.col('col3'))
        |  .agg(F.count(F.col('salary')).alias(f'salary_count'),
        |  F.mean(F.col('salary')).alias(f'salary_mean'),
        |  F.stddev(F.col('salary')).alias(f'salary_std'),
        |  F.min(F.col('salary')).alias(f'salary_min'),
        |  F.max(F.col('salary')).alias(f'salary_max'),
        |  F.expr(f'''percentile(F.col('salary'), array(0.25))''')[0].alias(f'salary_25pct'),
        |  F.expr(f'''percentile(F.col('salary'), array(0.5))''')[0].alias(f'salary_50pct'),
        |  F.expr(f'''percentile(F.col('salary'), array(0.75))''')[0].alias(f'salary_75pct'),F.count(F.col('arrears')).alias(f'arrears_count'),
        |  F.mean(F.col('arrears')).alias(f'arrears_mean'),
        |  F.stddev(F.col('arrears')).alias(f'arrears_std'),
        |  F.min(F.col('arrears')).alias(f'arrears_min'),
        |  F.max(F.col('arrears')).alias(f'arrears_max'),
        |  F.expr(f'''percentile(F.col('arrears'), array(0.25))''')[0].alias(f'arrears_25pct'),
        |  F.expr(f'''percentile(F.col('arrears'), array(0.5))''')[0].alias(f'arrears_50pct'),
        |  F.expr(f'''percentile(F.col('arrears'), array(0.75))''')[0].alias(f'arrears_75pct'))
        |  .createOrReplaceTempView('dbname.tblname_sum'))
        |""".stripMargin
    )
  }

}
