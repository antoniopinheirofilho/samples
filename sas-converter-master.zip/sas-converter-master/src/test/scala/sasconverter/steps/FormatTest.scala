package sasconverter.steps

import sasconverter.syntax.ParserSuite
import sasconverter.syntax.Syntax.Informat

class FormatTest extends ParserSuite {

  test("proc format with range with different quote styles") {
    translates(
      """proc format;
        |value $range
        |"40000-high"="High"
        |'26000-< 40000'="Medium"
        |'other' ='Low';
        |run;
        |""".stripMargin, FormatParser.parser(_),
      """import pyspark.sql.functions as F
        |def range_format(_fmt):
        |  return (F.when(F.col(_fmt) >= F.lit(40000),F.lit('High'))
        |    .when((F.col(_fmt) >= F.lit(26000)) & (F.col(_fmt) < F.lit( 40000)), F.lit('Medium'))
        |    .otherwise(F.lit('Low')))
        |""".stripMargin
    )
  }

  test("proc format ") {
    translates(
      """proc format ;
        |value $city
        |1="New_York            "
        |2="Massachusetts_General"
        |3="Los_Angeles"
        |4="Mary_Fletcher";
        |run;
        |""".stripMargin, FormatParser.parser(_),
      """import pyspark.sql.functions as F
        |def city_format(_fmt):
        |  return (F.when(F.col(_fmt) == F.lit(1), F.lit('New_York            '))
        |    .when(F.col(_fmt) == F.lit(2), F.lit('Massachusetts_General'))
        |    .when(F.col(_fmt) == F.lit(3), F.lit('Los_Angeles'))
        |    .when(F.col(_fmt) == F.lit(4), F.lit('Mary_Fletcher')))
        |""".stripMargin
    )
  }

  test("proc format multiple") {
    translates(
      """proc format ;
        |value $city
        |1='New_York            '
        |2='Massachusetts_General'
        |3='Los_Angeles'
        |4='Mary_Fletcher';
        |value $range
        |'40000-high'='High'
        |'26000-< 40000'='Medium'
        |'other' ='Low';
        |run;
        |""".stripMargin, FormatParser.parser(_),
      """import pyspark.sql.functions as F
        |def city_format(_fmt):
        |  return (F.when(F.col(_fmt) == F.lit(1), F.lit('New_York            '))
        |    .when(F.col(_fmt) == F.lit(2), F.lit('Massachusetts_General'))
        |    .when(F.col(_fmt) == F.lit(3), F.lit('Los_Angeles'))
        |    .when(F.col(_fmt) == F.lit(4), F.lit('Mary_Fletcher')))
        |def range_format(_fmt):
        |  return (F.when(F.col(_fmt) >= F.lit(40000),F.lit('High'))
        |    .when((F.col(_fmt) >= F.lit(26000)) & (F.col(_fmt) < F.lit( 40000)), F.lit('Medium'))
        |    .otherwise(F.lit('Low')))
        |""".stripMargin
    )
  }

}