package sasconverter.steps

import fastparse.P
import sasconverter.steps.DataStepParser._
import sasconverter.syntax.ParserSuite
import sasconverter.syntax.Syntax.Integer

class DataStepTest extends ParserSuite with Common[DataStep] {

  test("drop") {
    translates("drop = abs ncs wlek", drop(_),
      ".drop('abs', 'ncs', 'wlek')\n")
  }

  test("drop complex") {
    translates("drop=x1-x3 sales:", drop(_),
      """.drop('x1', 'x2', 'x3')
        |.transform(lambda df: df.select(*[c for c in df.columns if not c.startswith('sales')]))
        |""".stripMargin)
  }

  test("keep") {
    translates("keep = abs ncs wlek", keep(_),
      ".select('abs', 'ncs', 'wlek')\n")
  }

  test("rename") {
    translates("rename = (tinker=A tweede=B)", rename(_),
      """.withColumnRenamed('tinker', 'A')
        |.withColumnRenamed('tweede', 'B')
        |""".stripMargin)
  }

  test("in") {
    parses("in=abs", in(_), In("abs"))
  }

  test("foo al sl=34 sld=23;") {
    p(unknownStatement(_), UnknownStatement("foo", "al sl=34 sld=23"))
  }

  test("unknowns") {
    parses(
      """data x;
        |   beep boop;
        |   x = 1;
        |   baap buup;
        |run;
        |""".stripMargin,
      DataStepParser.parser(_), DataStep(
        Dataset("x",List()),
        Seq(
          UnknownStatement("beep", "boop"),
          Assign("x", Integer(1)),
          UnknownStatement("baap", "buup")
        )
      )
    )
  }

  test("unknowns translate well") {
    translates(
      """data x;
        |   set y;
        |   beep boop;
        |   x = 1;
        |   baap buup;
        |run;
        |""".stripMargin,
      DataStepParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('y'))
        |  # UNKNOWN beep: boop
        |  .withColumn('x', F.expr('1'))
        |  # UNKNOWN baap: buup
        |.createOrReplaceTempView('x'))
        |""".stripMargin)
  }

  test("where") {
    translates("where=(a not in ('b','c') or f ne 'g')", where(_),
      """.where("(NOT (a IN ('b', 'c'))) OR (f != 'g')")
        |""".stripMargin)
  }

  test("where without brackets") {
    translates("where a in (6) and c = 'd' ;", whereProc(_),
      """.where("(a IN (6)) AND (c = 'd')")
        |""".stripMargin)
  }

  test("call") {
    translates("""call symput('A', c);""".stripMargin, call_(_),
      """a = result['c']""".stripMargin)
  }

  test("dataset") {
    translates("incoming(" +
      "rename=(tinker=A tweede=B) " +
      "keep=first second " +
      //"in = abs " + // whitespace?..
      "drop=third fourth)", dataset(_),
      """(spark.table('incoming')
        |  .withColumnRenamed('tinker', 'A')
        |  .withColumnRenamed('tweede', 'B')
        |  .select('first', 'second')
        |  .drop('third', 'fourth'))
        |""".stripMargin)
  }

  test("dataset just name") {
    parses("incoming", dataset(_),
      Dataset("incoming"))
  }

  test("data") {
    parses("data tx; run;", DataStepParser.parser(_),
      DataStep(
        Dataset("tx"),
        Seq()
      ))
  }

  test("data variable") {
    parses(
      """data &tx..&tb;
        |run;""".stripMargin, DataStepParser.parser(_),
      DataStep(
        Dataset("{tx}.{tb}"),
        Seq()
      ))
  }

  test("format usage statement"){
    translates(
      """format salary $range.;""".stripMargin,format(_),
      """.withColumn('salary', range_format('salary'))"""
    )
  }

  test("Attrib unit test"){
    translates(
      """ATTRIB var001 label = 'X1 desc' format = ddmmyy10. informat = ddmmyy10. length=$5;""".stripMargin,attrib(_),
      """.withColumnRenamed('X1 desc', F.col('var001'))"""
    )
  }

  test("Attrib unit test 2"){
    translates(
      """ATTRIB var001 label = 'X1';""".stripMargin,attrib(_),
      """.withColumnRenamed('X1', F.col('var001'))"""
    )
  }


  test("data _null_"){
    translates(
      """data _null_;
        |      set dbname.table_name(where=(upper(bt_nm) = 'ABC') drop=bt_ts up_ts);
        |    run;
        |""".stripMargin,
      DataStepParser.parser(_),
      """result = ((spark.table('dbname.table_name')
        |  .where("upper(bt_nm) = 'ABC'")
        |  .drop('bt_ts', 'up_ts'))
        |.first())
        |""".stripMargin)
  }

  test("data _null_ with symput"){
    translates(
      """data _null_;
        |  set dbname.tablename;
        |  where a = 'xyz';
        |  call symput('B',d);
        |run;""".stripMargin,
      DataStepParser.parser(_),
      """result = ((spark.table('dbname.tablename'))
        |  .where("a = 'xyz'")
        |.first())
        |b = result['d']
        |""".stripMargin)
  }



  test("data merge with by"){
    translates(
      """data dbname.final(compress=yes);
        | merge dbname.t1(in=a) dbname.t2(in=b);
        | by a b c;
        |  run;
        |""".stripMargin,
      DataStepParser.parser(_),
      """import pyspark.sql.functions as F
        |(
        |      (spark.table('dbname.t1')
        |    .withColumn('a',F.lit(1))).join(['a', 'b', 'c'], 'inner',  (spark.table('dbname.t2')
        |    .withColumn('b',F.lit(1))))
        |  .createOrReplaceTempView('dbname.final'))
        |""".stripMargin)
  }


  test("data merge without by"){
    translates(
      """data dbname.final(compress=yes);
        | merge dbname.t1(in=a) dbname.t2(in=b);
        |run;""".stripMargin,
      DataStepParser.parser(_),
      """import pyspark.sql.functions as F
        |(
        |      (spark.table('dbname.t1')
        |    .withColumn('a',F.lit(1))).join(inner,  (spark.table('dbname.t2')
        |    .withColumn('b',F.lit(1))))
        |  .createOrReplaceTempView('dbname.final'))
        |""".stripMargin)
  }

  test("data statements") {
    translates(
      """data tx(keep=id name rename=(a=b) where=(foo > bar));
        | ATTRIB var003 label = "X3" format = ddmmyy10. informat = ddmmyy10.;
        | set x(drop=y rename=(DESCRIPTION=SAMPLE));
        | turnover = id * 100 / ratio(name);
        | format salary $range.;
        | ATTRIB var001 label = 'X1' format = ddmmyy10. informat = ddmmyy10.;
        | ATTRIB var002 label = 'X2' format = ddmmyy10. informat = ddmmyy10.;
        | run;""".stripMargin, DataStepParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('x')
        |  .drop('y')
        |  .withColumnRenamed('DESCRIPTION', 'SAMPLE'))
        |  .withColumnRenamed('X3', F.col('var003'))
        |  .withColumn('turnover', F.expr('(id * 100) / ratio(name)'))
        |  .withColumn('salary', range_format('salary'))
        |  .withColumnRenamed('X1', F.col('var001'))
        |  .withColumnRenamed('X2', F.col('var002'))
        |  .select('id', 'name')
        |  .withColumnRenamed('a', 'b')
        |  .where("foo > bar").createOrReplaceTempView('tx'))
        |""".stripMargin)
  }

  override def parser[_: P]: P[DataStep] = DataStepParser.parser
}
