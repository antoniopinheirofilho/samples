package sasconverter.steps

import sasconverter.syntax.ParserSuite

class SqlTest extends ParserSuite {
  test( "simple proc") {
    translates(
      """PROC SQL;
        |  CREATE TABLE WORK.OUTPUT AS
        |  SELECT * FROM WORK.ABC
        |  OUTER UNION CORR
        |  SELECT * FROM WORK.BCD
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |(  SELECT
        |    *
        |  FROM work.abc) OUTER UNION (
        |  SELECT
        |    *
        |  FROM work.bcd)
        |''')
        |.createOrReplaceTempView('work.output'))
        |""".stripMargin
    )
  }

  test( "simple proc with column names") {
    translates(
      """PROC SQL;
        |  CREATE TABLE WORK.OUTPUT AS
        |  SELECT a1,b1,c1 FROM WORK.ABC
        |  OUTER UNION CORR
        |  SELECT a1,b1,c1 FROM WORK.BCD
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |(  SELECT
        |    a1,
        |    b1,
        |    c1
        |  FROM work.abc) OUTER UNION (
        |  SELECT
        |    a1,
        |    b1,
        |    c1
        |  FROM work.bcd)
        |''')
        |.createOrReplaceTempView('work.output'))
        |""".stripMargin
    )
  }

  test( "select into") {
    translates(
      """PROC SQL;
        |  SELECT COUNT(*) INTO :THING FROM WORK.THINGS;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """result = (spark.sql(f'''
        |  SELECT
        |    (count(*)) AS thing
        |  FROM work.things
        |''').first())
        |thing = result['thing']""".stripMargin
    )
  }

  test("insert values") {
    translates(
      """PROC SQL;
        |  INSERT INTO something (pippo,pluto,paperino)
        |  VALUES
        |     ('pippo', 'pluto', 'paperino');
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (pippo, pluto, paperino)
        |  VALUES
        |     ('pippo', 'pluto', 'paperino')
        |'''))""".stripMargin
    )
  }

  test("insert select") {
    translates(
      """PROC SQL;
        |  INSERT INTO something (pippo, pluto, paperino)
        |  SELECT a, b, c FROM table1;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (pippo, pluto, paperino)
        |    SELECT
        |      a,
        |      b,
        |      c
        |    FROM table1
        |'''))""".stripMargin
    )
  }

  test("insert select without cols") {
    translates(
      """PROC SQL;
        |  INSERT INTO something
        |  SELECT a, b, c FROM table1;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something
        |    SELECT
        |      a,
        |      b,
        |      c
        |    FROM table1
        |'''))""".stripMargin
    )
  }

  test("insert set") {
    translates(
      """PROC SQL;
        |  INSERT INTO something (pippo, paperino, pluto)
        |  SET pippo='pippo', pluto='pluto', paperino='paperino';
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (paperino, pippo, pluto)
        |  VALUES
        |     ('paperino', 'pippo', 'pluto')
        |'''))""".stripMargin
    )
  }

  test("insert set without columns") {
    translates(
      """PROC SQL;
        |  INSERT INTO something
        |  SET pippo='pippo',pluto='pluto',paperino='paperino';
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (paperino, pippo, pluto)
        |  VALUES
        |     ('paperino', 'pippo', 'pluto')
        |'''))""".stripMargin
    )
  }

  test("insert set with variables") {
    translates(
      """PROC SQL;
        |  INSERT INTO something
        |  SET pippo=&pippovar, pluto='pluto', paperino='paperino';
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (paperino, pippo, pluto)
        |  VALUES
        |     ('paperino', {pippovar}, 'pluto')
        |'''))""".stripMargin
    )
  }

  test("insert set with function call") {
    translates(
      """PROC SQL;
        |  INSERT INTO something
        |  SET pippo=CURRENT_TIMESTAMP(), pluto='pluto', paperino='paperino';
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (paperino, pippo, pluto)
        |  VALUES
        |     ('paperino', current_timestamp(), 'pluto')
        |'''))""".stripMargin
    )
  }

  test("insert multiple values") {
    translates(
      """PROC SQL;
        |  INSERT INTO something (pippo,pluto,paperino)
        |  VALUES ('pippo', 'pluto', 'paperino')
        |  VALUES ('pippo', 'pluto', 'paperino');
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something (pippo, pluto, paperino)
        |  VALUES
        |     ('pippo', 'pluto', 'paperino'),
        |     ('pippo', 'pluto', 'paperino')
        |'''))""".stripMargin
    )
  }

  test("insert multiple values without cols") {
    translates(
      """PROC SQL;
        |  INSERT INTO something
        |  VALUES ('pippo', 'pluto', 'paperino')
        |  VALUES ('pippo', 'pluto', 'paperino');
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """(spark.sql(f'''
        |  INSERT INTO work.something
        |  VALUES
        |     ('pippo', 'pluto', 'paperino'),
        |     ('pippo', 'pluto', 'paperino')
        |'''))""".stripMargin
    )
  }

  test("variable conversion") {
    translates(
      """proc sql noprint;
        |CREATE TABLE &work..&something AS SELECT * FROM &A..&B;
        |quit;
        |""".stripMargin,ProcSqlParser.parser(_),
        """(spark.sql(f'''
        |  SELECT
        |    *
        |  FROM {a}.{b}
        |''')
        |.createOrReplaceTempView(f'{work}.{something}'))""".stripMargin)
  }

  test( "update with simple set and without where") {
    translates(
      """PROC SQL;
        |  UPDATE WORK.EMPLOYEES
        |     SET salary=salary + 1000
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """spark.sql(f'''
        |  UPDATE work.employees
        |  SET salary = salary + 1000
        |''')
        |""".stripMargin
    )
  }

  test( "update with multiple set and where") {
    translates(
      """PROC SQL;
        |  UPDATE WORK.EMPLOYEES
        |     SET salary=salary + 1000, seniority=seniority + 1
        |  WHERE targets=1
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """spark.sql(f'''
        |  UPDATE work.employees
        |  SET salary = salary + 1000, seniority = seniority + 1
        |  WHERE targets = 1
        |''')
        |""".stripMargin
    )
  }

  test( "update with multiple set and where with variable") {
    translates(
      """PROC SQL;
        |  UPDATE &WORK..EMPLOYEES
        |     SET salary=salary + 1000, seniority=seniority + 1
        |  WHERE targets=1
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """spark.sql(f'''
        |  UPDATE {work}.employees
        |
        |  SET salary = salary + 1000, seniority = seniority + 1
        |  WHERE targets = 1
        |''')
        |""".stripMargin
    )
  }

  test( "unknown sql") {
    translates(
      """PROC SQL;
        |  SOME_UNKNOWN_SQL_COMMAND WORK.EMPLOYEES
        |     SET salary=salary + 1000, seniority=seniority + 1
        |  WHERE targets=1
        |  ;
        |QUIT;
        |""".stripMargin,
      ProcSqlParser.parser(_),
      """# UNKNOWN PROC SQL some_unknown_sql_command""".stripMargin
    )
  }

}


