package sasconverter.steps

import sasconverter.syntax.ParserSuite

class AppendTest extends ParserSuite {
  test("append") {
    translates(
      """proc append base=ds data=db2.ds2;
        | run;""".stripMargin, ProcAppendParser.parser(_),
      """append_base = (spark.table('ds'))
        |append_data = (spark.table('db2.ds2'))
        |(append_base
        |  .unionByName(append_data)
        |  .createOrReplaceTempView('ds'))
        |""".stripMargin)
  }

  test("append with force") {
    translates(
      """proc append base=ds data=db2.ds2 force;
        | run;""".stripMargin, ProcAppendParser.parser(_),
      """append_base = (spark.table('ds'))
        |append_data = (spark.table('db2.ds2'))
        |(append_base
        |  .unionByName(append_data.select(append_base.columns))
        |  .createOrReplaceTempView('ds'))
        |""".stripMargin)
  }
}
