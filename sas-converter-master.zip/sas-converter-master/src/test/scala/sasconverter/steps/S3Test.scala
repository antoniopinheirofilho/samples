package sasconverter.steps

import sasconverter.syntax.ParserSuite

class S3Test extends ParserSuite {
  test("Empty proc s3") {
    parses(
      """proc s3;
        |run;
        |""".stripMargin, ProcS3Parser.parser(_), ProcS3(Seq(),
        Seq()
      )
    )
  }

  test("Empty proc s3 with options") {
    parses(
      """proc s3 profile="myprofile" region="us-east1";
        |run;
        |""".stripMargin, ProcS3Parser.parser(_),
      ProcS3(Seq(
        KeyString("profile", "myprofile"),
        KeyString("region", "us-east1")
      ), Seq())
    )
  }

  test("proc s3 with options") {
    parses(
      """proc s3 profile="myprofile" region="us-east1";
        |put "/local/path" "s3:/bucket/path";
        |run;
        |""".stripMargin, ProcS3Parser.parser(_),
      ProcS3(Seq(
        KeyString("profile", "myprofile"),
        KeyString("region", "us-east1")
      ), Seq(S3PutStatement("/local/path", "s3:/bucket/path")))
    )
  }

  test("proc s3 put") {
    parses(
      """proc s3;
        |put "/local/path" "s3:/mybucket/path" ;
        |run;
        |""".stripMargin, ProcS3Parser.parser(_), ProcS3(Seq(), Seq(S3PutStatement("/local/path", "s3:/mybucket/path")))
    )
  }

  test("proc s3 get") {
    parses(
      """proc s3;
        |get "s3:/mybucket/path/" "/local/path/" ;
        |run;
        |""".stripMargin, ProcS3Parser.parser(_), ProcS3(Seq(),
        Seq(S3GetStatement("s3:/mybucket/path/", "/local/path/")))
    )
  }

  test("proc s3 dummy + put + get") {
    parses(
      """proc s3;
        |info "s3:/somebucket/some/path";
        |get "s3:/mybucket/path" "/local/path/" ;
        |put "/local/path" "s3:/mybucket/path2/" ;
        |run;
        |""".stripMargin, ProcS3Parser.parser(_), ProcS3(Seq(),
        Seq(S3DummyStatement(),
          S3GetStatement("s3:/mybucket/path", "/local/path/"),
          S3PutStatement("/local/path", "s3:/mybucket/path2/")
        ))
    )
  }

  test("proc s3 other dummy statements") {
    parses(
      """proc s3;
        |bucket "my-bucket";
        |create "my-bucket";
        |delete "s3:/some-bucket/some-path/";
        |destroy "some-bucket";
        |enckey add name="keyname" id="key-id";
        |getaccel "some-bucket";
        |getdir "s3:/mybucket/dir/" "/path/to/dir/";
        |info "s3:/myotherbucket/";
        |list "s3:/anotherbucket/";
        |mkdir "s3:/anotherbucket/newdir/";
        |putdir "/local/path/to/dir/" "s3:/mybucket/target/dir/";
        |rmdir "s3:/anotherbucket/remove/dir/";
        |run;
        |""".stripMargin, ProcS3Parser.parser(_), ProcS3(Seq(),
        Seq.fill(12)(S3DummyStatement()))
    )
  }
}
