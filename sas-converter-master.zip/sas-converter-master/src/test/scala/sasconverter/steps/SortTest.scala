package sasconverter.steps

import sasconverter.syntax.ParserSuite

class SortTest extends ParserSuite {
  test( "Sort Scenario 1 with out") {
    translates(
      """proc sort data=account out=bytown;
        | by descending town company;
        | run;""".stripMargin,
      SortParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('account'))
        |  .orderBy(F.col('town').desc(), F.col('company'))
        |  .createOrReplaceTempView('bytown'))
        |""".stripMargin
    )
  }

  test( "Sort Scenario 2 without out") {
    translates(
      """proc sort data=titanic;
        |by descending passengerid;
        |run;""".stripMargin,
      SortParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('titanic'))
        |  .orderBy(F.col('passengerid').desc())
        |  .createOrReplaceTempView('titanic'))
        |""".stripMargin
    )
  }


  test( "Sort Scenario 3 with out and options") {
    translates(
      """proc sort data=titanic(keep=passengerid passengername passengerage passengercmts)
        |out=wrecked(drop=passengercmts where=(passengerage > 10));
        |key passengerid;
        |run;""".stripMargin,
      SortParser.parser(_),
      """import pyspark.sql.functions as F
        |((spark.table('titanic')
        |  .select('passengerid', 'passengername', 'passengerage', 'passengercmts'))
        |  .orderBy(F.col('passengerid'))
        |    .drop('passengercmts')
        |  .where("passengerage > 10").createOrReplaceTempView('wrecked'))
        |""".stripMargin
    )
  }
}
