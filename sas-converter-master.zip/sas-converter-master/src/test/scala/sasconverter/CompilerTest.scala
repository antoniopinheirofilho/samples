package sasconverter

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.must.Matchers

class CompilerTest extends AnyFunSuite with Matchers {
  test("transpile unknowns") {
    Compiler.transpile(
      """DATA y;
        |  SET x;
        |  a = 1;
        |RUN;
        |
        |PROC BREAKFAST OUT=happy;
        |  PREPARE eggs;
        |  AND bacon;
        |RUN;
        |
        |PROC SORT data=y;
        | BY DESCENDING a;
        |RUN;
        |""".stripMargin) mustEqual
      """import pyspark.sql.functions as F
        |((spark.table('x'))
        |  .withColumn('a', F.expr('1'))
        |.createOrReplaceTempView('y'))
        |
        |
        |# COMMAND ----
        |
        |# UNKNOWN PROC breakfast
        |
        |# COMMAND ----
        |
        |((spark.table('y'))
        |  .orderBy(F.col('a').desc())
        |  .createOrReplaceTempView('y'))""".stripMargin
  }

  test("sample") {
    val result = Compiler.consumeFile("example/sample.sas")
    print(result)
  }
}
