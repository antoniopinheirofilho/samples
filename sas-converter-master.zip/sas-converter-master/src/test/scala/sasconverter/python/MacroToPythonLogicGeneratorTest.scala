package sasconverter.python

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.must.Matchers
import sasconverter.Context

class MacroToPythonLogicGeneratorTest extends AnyFunSuite with Matchers {



  test("sample") {
    val context = Context()
    val res = MacroToPythonLogicGenerator.translate(
      """%macro x(a);
        |  %if %foo(a) EQ 1 %then %do;
        |    %if b eq '' %then %do;
        |      %let c=3;
        |      %let f=5;
        |    %end;
        |    %let g=9;
        |  %end;
        |  %else %do;
        |    %global e;
        |    %let e=4;
        |    %let c=9;
        |    %let h=8;
        |  %end;
        |%mend;
        |""".stripMargin, context)
    print(res)
    res mustEqual
      """def x(a):
        |  if foo('a') == 1:
        |    if 'b' == '':
        |      c = 3
        |      f = 5
        |    g = 9
        |  else:
        |    global e
        |    e = 4
        |    c = 9
        |    h = 8""".stripMargin
  }
}
