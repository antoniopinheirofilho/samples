import pyspark.sql.functions as F
def cityfmt_format(_fmt):
  return (F.when(F.col(_fmt) == F.lit(1), F.lit('New_York            '))
          .when(F.col(_fmt) == F.lit(2), F.lit('Massachusetts_General'))
          .when(F.col(_fmt) == F.lit(3), F.lit(' Los_Angeles '))
          .when(F.col(_fmt) == F.lit(4), F.lit('Mary_Fletcher')))
# COMMAND ----

((spark.table('loadedfromothersource')
  .withColumnRenamed('DESCRIPTION', 'SAMPLE'))
  .withColumnRenamed('X3', F.col('var003'))
  .withColumnRenamed('X1', F.col('var001'))
  .withColumnRenamed('X2', F.col('var002'))
  .withColumn('city', cityfmt_format('city'))
  .withColumn('thisid', F.expr('customer_identifier(sample)'))
  .withColumn('population', F.expr('compute_population(this_id)'))
  .withColumn('promoted_number', F.expr('999'))
  .withColumn('c1', F.expr('1'))
  .withColumn('c2', F.expr('3'))
  .withColumn('c3', F.expr('4'))
.createOrReplaceTempView('requirements'))


# COMMAND ----

((spark.table('requirements'))
  .orderBy(F.col('promoted_number').desc())
  .createOrReplaceTempView('requirements'))

# COMMAND ----

(spark.sql('''
  SELECT DISTINCT
    t1.this_id
    t2.amount
    t2.country
    t2.percentage_1
    t2.percentage_2
    t2.percentage_3
    t2.percentage_4
    t2.percentage_5
    t2.percentage_6
    t2.percentage_7
    t2.percentage_8
    t2.percentage_9
    t2.percentage_10
    t2.percentage_11
    t2.percentage_12
    t2.percentage_13
    t2.percentage_14
    t2.percentage_15
    t2.percentage_16
  FROM work.requirements AS t1, work.flow_0003 AS t2
  WHERE t1.this_id = t2.this_id AND t1.population = t2.population AND t1.this_id != t2.promoted_number
  GROUP BY t1.this_id, t2.amount, t2.country
  ORDER BY t1.this_id asc
''')
.createOrReplaceTempView('work.append_0001'))

# COMMAND ----

(spark.sql('''
  SELECT DISTINCT
    f1.this_id
    f1.processing_time
  FROM work.append_0001 AS f1
  ORDER BY f1.that_id asc
''')
.createOrReplaceTempView('work.flow_0001'))

# COMMAND ----

((spark.table('flow_0001'))
  .write
  .format('delta')
  .mode('overwrite')
  .save('new_destination'))

# COMMAND ----

spark.sql('''
  UPDATE work.employees
  SET salary = salary + 1000, seniority = seniority + 1
  WHERE targets = 1 AND dept = 10
''')